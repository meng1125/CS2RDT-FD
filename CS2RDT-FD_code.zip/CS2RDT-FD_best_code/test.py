# test.py
# -*- coding: utf-8 -*-

"""
测试脚本：
1. 加载模型 checkpoint
2. 加载测试集
3. 分别评估：
   - sim_test
   - real_test_all5
4. 保存：
   - accuracy / per-class accuracy / confusion matrix
   - confusion matrix 图
   - t-SNE 图
   - prototype distance 分析结果
"""

import os
import argparse
from typing import Dict, Any, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

import torch

from dataset import IDX_TO_CLASS, CLASS_TO_IDX
from metrics import (
    summarize_classification_metrics,
    save_confusion_matrix_figure,
)
from physics_fusion import apply_segment_opf_itsc_refinement, physics_informed_postprocess
from utils import (
    load_config,
    ensure_dir,
    setup_logger,
    set_random_seed,
    get_device,
    build_model,
    build_dataloader,
    load_model_weights,
    get_or_create_split_records,
    build_stage_datasets_from_splits,
    load_scaler,
    save_json,
    move_batch_to_device,
)


def parse_args():
    parser = argparse.ArgumentParser(description="模型测试脚本")
    parser.add_argument("--config", type=str, default="config.yaml", help="配置文件路径")
    parser.add_argument("--ckpt", type=str, required=True, help="待测试 checkpoint 路径")
    parser.add_argument("--scaler", type=str, default=None, help="scaler json 路径；若不传则尝试自动推断")
    parser.add_argument("--disable_physics", action="store_true", help="Disable physics-informed postprocessing")
    parser.add_argument("--output_dir", type=str, default=None, help="Evaluation output directory")
    parser.add_argument("--log_filename", type=str, default=None, help="Test log filename")
    return parser.parse_args()


@torch.no_grad()
def evaluate_loader(
    model: torch.nn.Module,
    loader,
    device: torch.device,
    num_classes: int
) -> Dict[str, Any]:
    """
    在单个 DataLoader 上评估，并收集：
    - y_true / y_pred
    - features(z_fault)
    - 域标签
    - 原型距离
    - meta 信息
    """
    model.eval()

    all_y_true = []
    all_y_pred = []
    all_features = []
    all_domains = []
    all_distances = []
    all_probs = []
    all_logits = []
    all_logits_time = []
    all_logits_freq = []
    all_x_raw = []
    all_probs_time = []
    all_probs_freq = []
    all_pred_time = []
    all_pred_freq = []
    all_speed_rpm = []
    all_load = []
    all_electrical_frequency_hz = []
    all_logit_margin = []
    all_predictive_entropy = []
    all_prototype_min_distance = []
    all_prototype_distance_margin = []
    all_reliability_score = []
    all_time_freq_agreement = []
    freq_order_k = None
    fusion_alpha = None
    all_freq_order_centers_hz = []
    all_meta = []

    for batch in loader:
        batch = move_batch_to_device(batch, device)

        outputs = model(
            x=batch["x"],
            x_raw=batch.get("x_raw", None),
            speed_rpm=batch.get("speed", None),
            class_condition=batch["y"],
            grl_lambda_domain=0.0,
            grl_lambda_domain_global=0.0,
        )

        logits = outputs["logits"]
        z_fault = outputs["z_fault"]
        pred = torch.argmax(logits, dim=1)

        probs = torch.softmax(logits, dim=1)
        distances = model.prototype_classifier.compute_distances(z_fault)

        all_y_true.append(batch["y"].detach().cpu().numpy())
        all_y_pred.append(pred.detach().cpu().numpy())
        all_features.append(z_fault.detach().cpu().numpy())
        all_domains.append(batch["domain"].detach().cpu().numpy())
        all_distances.append(distances.detach().cpu().numpy())
        all_probs.append(probs.detach().cpu().numpy())
        all_logits.append(logits.detach().cpu().numpy())
        all_x_raw.append(batch["x_raw"].detach().cpu().numpy())

        logits_time = outputs.get("logits_time", logits)
        logits_freq = outputs.get("logits_freq", torch.zeros_like(logits))
        probs_time = torch.softmax(logits_time, dim=1)
        probs_freq = torch.softmax(logits_freq, dim=1)
        all_logits_time.append(logits_time.detach().cpu().numpy())
        all_logits_freq.append(logits_freq.detach().cpu().numpy())
        all_probs_time.append(probs_time.detach().cpu().numpy())
        all_probs_freq.append(probs_freq.detach().cpu().numpy())
        all_pred_time.append(torch.argmax(probs_time, dim=1).detach().cpu().numpy())
        all_pred_freq.append(torch.argmax(probs_freq, dim=1).detach().cpu().numpy())
        all_speed_rpm.append(batch["speed"].detach().cpu().numpy())
        all_load.append(batch["load"].detach().cpu().numpy())

        def _append_output(name: str, target: List[np.ndarray], default: torch.Tensor) -> None:
            value = outputs.get(name, default)
            if value is None:
                value = default
            target.append(value.detach().cpu().numpy())

        _append_output("electrical_frequency_hz", all_electrical_frequency_hz, torch.full_like(batch["speed"], np.nan))
        _append_output("logit_margin", all_logit_margin, torch.zeros_like(batch["speed"]))
        _append_output("predictive_entropy", all_predictive_entropy, torch.zeros_like(batch["speed"]))
        _append_output("prototype_min_distance", all_prototype_min_distance, torch.zeros_like(batch["speed"]))
        _append_output("prototype_distance_margin", all_prototype_distance_margin, torch.zeros_like(batch["speed"]))
        _append_output("reliability_score", all_reliability_score, torch.zeros_like(batch["speed"]))
        _append_output("time_freq_prediction_agreement", all_time_freq_agreement, torch.ones_like(batch["speed"]))

        if outputs.get("alpha") is not None:
            fusion_alpha = outputs["alpha"].detach().cpu().numpy()
        if outputs.get("freq_order_k") is not None:
            freq_order_k = outputs["freq_order_k"].detach().cpu().numpy()
        if outputs.get("freq_order_centers_hz") is not None:
            all_freq_order_centers_hz.append(outputs["freq_order_centers_hz"].detach().cpu().numpy())

        all_meta.extend(batch["meta"])

    if len(all_y_true) == 0:
        empty_vec = np.array([], dtype=np.float32)
        return {
            "y_true": np.array([], dtype=np.int64),
            "y_pred": np.array([], dtype=np.int64),
            "features": np.zeros((0, model.prototype_classifier.feat_dim), dtype=np.float32),
            "domains": np.array([], dtype=np.int64),
            "distances": np.zeros((0, num_classes), dtype=np.float32),
            "probs": np.zeros((0, num_classes), dtype=np.float32),
            "logits": np.zeros((0, num_classes), dtype=np.float32),
            "logits_time": np.zeros((0, num_classes), dtype=np.float32),
            "logits_freq": np.zeros((0, num_classes), dtype=np.float32),
            "x_raw": np.zeros((0, 0, 0), dtype=np.float32),
            "probs_time": np.zeros((0, num_classes), dtype=np.float32),
            "probs_freq": np.zeros((0, num_classes), dtype=np.float32),
            "pred_time": np.array([], dtype=np.int64),
            "pred_freq": np.array([], dtype=np.int64),
            "speed_rpm": empty_vec,
            "load": empty_vec,
            "electrical_frequency_hz": empty_vec,
            "logit_margin": empty_vec,
            "predictive_entropy": empty_vec,
            "prototype_min_distance": empty_vec,
            "prototype_distance_margin": empty_vec,
            "reliability_score": empty_vec,
            "time_freq_prediction_agreement": empty_vec,
            "freq_order_k": None,
            "freq_order_centers_hz": np.zeros((0, 0), dtype=np.float32),
            "fusion_alpha": None,
            "meta": [],
        }

    result = {
        "y_true": np.concatenate(all_y_true, axis=0),
        "y_pred": np.concatenate(all_y_pred, axis=0),
        "features": np.concatenate(all_features, axis=0),
        "domains": np.concatenate(all_domains, axis=0),
        "distances": np.concatenate(all_distances, axis=0),
        "probs": np.concatenate(all_probs, axis=0),
        "logits": np.concatenate(all_logits, axis=0),
        "logits_time": np.concatenate(all_logits_time, axis=0),
        "logits_freq": np.concatenate(all_logits_freq, axis=0),
        "x_raw": np.concatenate(all_x_raw, axis=0),
        "probs_time": np.concatenate(all_probs_time, axis=0),
        "probs_freq": np.concatenate(all_probs_freq, axis=0),
        "pred_time": np.concatenate(all_pred_time, axis=0),
        "pred_freq": np.concatenate(all_pred_freq, axis=0),
        "speed_rpm": np.concatenate(all_speed_rpm, axis=0),
        "load": np.concatenate(all_load, axis=0),
        "electrical_frequency_hz": np.concatenate(all_electrical_frequency_hz, axis=0),
        "logit_margin": np.concatenate(all_logit_margin, axis=0),
        "predictive_entropy": np.concatenate(all_predictive_entropy, axis=0),
        "prototype_min_distance": np.concatenate(all_prototype_min_distance, axis=0),
        "prototype_distance_margin": np.concatenate(all_prototype_distance_margin, axis=0),
        "reliability_score": np.concatenate(all_reliability_score, axis=0),
        "time_freq_prediction_agreement": np.concatenate(all_time_freq_agreement, axis=0),
        "freq_order_k": freq_order_k,
        "freq_order_centers_hz": np.concatenate(all_freq_order_centers_hz, axis=0) if all_freq_order_centers_hz else np.zeros((0, 0), dtype=np.float32),
        "fusion_alpha": fusion_alpha,
        "meta": all_meta,
    }
    return result


def save_tsne_plots(
    features: np.ndarray,
    labels: np.ndarray,
    domains: np.ndarray,
    save_dir: str,
    perplexity: int = 30,
    random_state: int = 3407,
    max_samples: int = 4000
) -> None:
    """
    保存 t-SNE 可视化结果：
    1. 按类别着色
    2. 按域着色

    说明：
    - 若样本过多，则随机下采样到 max_samples
    """
    ensure_dir(save_dir)

    if features.shape[0] <= 1:
        return

    rng = np.random.RandomState(random_state)
    n = features.shape[0]
    if n > max_samples:
        indices = rng.choice(n, size=max_samples, replace=False)
        features = features[indices]
        labels = labels[indices]
        domains = domains[indices]

    tsne = TSNE(
        n_components=2,
        perplexity=min(perplexity, max(5, features.shape[0] - 1)),
        random_state=random_state,
        init="pca",
        learning_rate="auto"
    )
    emb = tsne.fit_transform(features)

    # 1) 按类别着色
    plt.figure(figsize=(8, 6))
    for cls_idx, cls_name in IDX_TO_CLASS.items():
        mask = (labels == cls_idx)
        if mask.sum() == 0:
            continue
        plt.scatter(
            emb[mask, 0],
            emb[mask, 1],
            s=10,
            alpha=0.7,
            label=cls_name
        )
    plt.title("t-SNE by Class")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "tsne_by_class.png"), dpi=200, bbox_inches="tight")
    plt.close()

    # 2) 按域着色
    plt.figure(figsize=(8, 6))
    domain_name_map = {0: "sim", 1: "real"}
    for domain_idx, domain_name in domain_name_map.items():
        mask = (domains == domain_idx)
        if mask.sum() == 0:
            continue
        plt.scatter(
            emb[mask, 0],
            emb[mask, 1],
            s=10,
            alpha=0.7,
            label=domain_name
        )
    plt.title("t-SNE by Domain")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "tsne_by_domain.png"), dpi=200, bbox_inches="tight")
    plt.close()


def save_prototype_distance_analysis(
    result_dict: Dict[str, Any],
    save_dir: str,
    split_name: str = "real_test_all5"
) -> None:
    """
    保存原型距离分析结果。

    输出：
    1. sample_level CSV：每个样本到各类原型的距离
    2. tuici 子集 CSV：真实未知退磁样本的 softmax / 原型距离
    3. summary JSON：关注真实域未知/扩展故障类的原型距离表现
    """
    ensure_dir(save_dir)

    y_true = result_dict["y_true"]
    y_pred = result_dict["y_pred"]
    distances = result_dict["distances"]
    probs = result_dict.get("probs", None)
    meta = result_dict["meta"]

    safe_split_name = str(split_name).replace(os.sep, "_").replace("/", "_")

    rows: List[Dict[str, Any]] = []
    for i in range(len(y_true)):
        row = {
            "filename": meta[i].get("filename", ""),
            "file_path": meta[i].get("file_path", ""),
            "window_start": meta[i].get("window_start", -1),
            "window_end": meta[i].get("window_end", -1),
            "true_label_idx": int(y_true[i]),
            "true_label_name": IDX_TO_CLASS[int(y_true[i])],
            "pred_label_idx": int(y_pred[i]),
            "pred_label_name": IDX_TO_CLASS[int(y_pred[i])],
        }
        for cls_idx in range(distances.shape[1]):
            cls_name = IDX_TO_CLASS[cls_idx]
            row[f"prob_{cls_name}"] = None if probs is None else float(probs[i, cls_idx])
            row[f"dist_to_{cls_name}"] = float(distances[i, cls_idx])
        rows.append(row)

    df = pd.DataFrame(rows)
    csv_path = os.path.join(save_dir, f"prototype_distances_{safe_split_name}.csv")
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    if "tuici" in CLASS_TO_IDX:
        tuici_idx = CLASS_TO_IDX["tuici"]
        tuici_df = df[df["true_label_idx"] == tuici_idx].copy()
        tuici_csv_path = os.path.join(save_dir, f"{safe_split_name}_tuici_softmax_and_prototype_distances.csv")
        tuici_df.to_csv(tuici_csv_path, index=False, encoding="utf-8-sig")

        # 兼容旧文件名：仅在综合 real_test_all5_final 上额外保存一份旧名称，避免下游脚本找不到。
        if safe_split_name == "real_test_all5_final":
            legacy_tuici_csv_path = os.path.join(save_dir, "real_tuici_softmax_and_prototype_distances.csv")
            tuici_df.to_csv(legacy_tuici_csv_path, index=False, encoding="utf-8-sig")

    # 当前五分类任务中，真实域已知三类之外的未知类为 ITSC / tuici
    summary = {}
    focus_classes = [cls_name for cls_name in ["tuici"] if cls_name in CLASS_TO_IDX]
    for cls_name in focus_classes:
        cls_idx = CLASS_TO_IDX[cls_name]
        mask = (y_true == cls_idx)
        if mask.sum() == 0:
            summary[cls_name] = {
                "num_samples": 0,
                "nearest_correct_rate": None,
                "nearest_prototype_correct_rate": None,
                "prediction_correct_rate": None,
                "nearest_prediction_distribution": {},
                "nearest_prototype_distribution": {},
            }
            continue

        selected_pred = y_pred[mask]
        selected_distances = distances[mask]
        nearest_proto = np.argmin(selected_distances, axis=1)
        prediction_correct_rate = float((selected_pred == cls_idx).mean())
        nearest_prototype_correct_rate = float((nearest_proto == cls_idx).mean())

        pred_distribution = {}
        nearest_proto_distribution = {}
        for pred_cls_idx in range(distances.shape[1]):
            cls_label = IDX_TO_CLASS[pred_cls_idx]
            pred_distribution[cls_label] = int((selected_pred == pred_cls_idx).sum())
            nearest_proto_distribution[cls_label] = int((nearest_proto == pred_cls_idx).sum())

        summary[cls_name] = {
            "num_samples": int(mask.sum()),
            "nearest_correct_rate": nearest_prototype_correct_rate,
            "nearest_prototype_correct_rate": nearest_prototype_correct_rate,
            "prediction_correct_rate": prediction_correct_rate,
            "nearest_prediction_distribution": pred_distribution,
            "nearest_prototype_distribution": nearest_proto_distribution,
        }

    json_path = os.path.join(save_dir, f"prototype_distance_summary_{safe_split_name}.json")
    save_json(summary, json_path)


def get_target_eval_split_names(test_datasets: Dict[str, Any]) -> List[str]:
    """测试阶段评估仿真五类测试集和真实五类综合测试集。"""
    required = ["sim_test", "real_test_known3", "real_test_unknown2", "real_test_all5"]
    if "real_test_all5" not in test_datasets and "real_test_all5_final" in test_datasets:
        required = ["sim_test", "real_test_known3", "real_test_unknown2", "real_test_all5_final"]
    missing = [name for name in required if name not in test_datasets]
    if missing:
        raise KeyError(f"缺少必要测试集: {missing}")
    for optional_name in (
        "operational_boundary_excluded_real_test_unknown2",
        "operational_boundary_excluded_real_test_all5",
    ):
        if optional_name in test_datasets:
            required.append(optional_name)
    return required


def apply_physics_postprocess_to_eval(
    result_dict: Dict[str, Any],
    config: Dict[str, Any],
    idx_to_class: Dict[int, str],
) -> Dict[str, Any]:
    """Run physics-informed posterior correction and keep per-window audit rows."""
    y_pred = result_dict["y_pred"]
    probs = result_dict["probs"]
    logits = result_dict["logits"]
    probs_time = result_dict.get("probs_time", None)
    probs_freq = result_dict.get("probs_freq", None)
    logits_time = result_dict.get("logits_time", None)
    logits_freq = result_dict.get("logits_freq", None)
    pred_time = result_dict.get("pred_time", None)
    pred_freq = result_dict.get("pred_freq", None)
    time_freq_agreement = result_dict.get("time_freq_prediction_agreement", None)
    reliability = result_dict.get("reliability_score", None)
    logit_margin = result_dict.get("logit_margin", None)
    predictive_entropy = result_dict.get("predictive_entropy", None)
    fusion_alpha = result_dict.get("fusion_alpha", None)
    x_raw = result_dict["x_raw"]
    speed_rpm = result_dict["speed_rpm"]
    meta = result_dict["meta"]
    physics_pred: List[int] = []
    physics_rows: List[Dict[str, Any]] = []
    changed_rows: List[Dict[str, Any]] = []

    for i in range(len(y_pred)):
        domain_name = str(meta[i].get("domain_name", ""))
        if not domain_name:
            domain_name = "real" if int(result_dict["domains"][i]) == 1 else "sim"
        out = physics_informed_postprocess(
            pred=int(y_pred[i]),
            prob=probs[i],
            logits=logits[i],
            x_raw=x_raw[i],
            speed=float(speed_rpm[i]),
            load=float(result_dict["load"][i]),
            domain=domain_name,
            config=config,
            prob_time=None if probs_time is None else probs_time[i],
            prob_freq=None if probs_freq is None else probs_freq[i],
            logits_time=None if logits_time is None else logits_time[i],
            logits_freq=None if logits_freq is None else logits_freq[i],
            pred_time=None if pred_time is None else int(pred_time[i]),
            pred_freq=None if pred_freq is None else int(pred_freq[i]),
            time_freq_prediction_agreement=None if time_freq_agreement is None else float(time_freq_agreement[i]),
            fusion_alpha=fusion_alpha,
            reliability_score=None if reliability is None else float(reliability[i]),
            logit_margin=None if logit_margin is None else float(logit_margin[i]),
            predictive_entropy=None if predictive_entropy is None else float(predictive_entropy[i]),
        )
        final_pred = int(out["final_pred"])
        base_pred = int(out["base_pred"])
        physics_pred.append(final_pred)
        row = {
            "sample_index": int(i),
            "filename": meta[i].get("filename", ""),
            "file_path": meta[i].get("file_path", ""),
            "window_idx": meta[i].get("window_idx", -1),
            "window_start": meta[i].get("window_start", -1),
            "window_end": meta[i].get("window_end", -1),
            "domain_name": domain_name,
            "true_label_idx": int(result_dict["y_true"][i]),
            "true_label_name": idx_to_class[int(result_dict["y_true"][i])],
            "base_pred_idx": base_pred,
            "base_pred_name": idx_to_class[base_pred],
            "physics_pred_idx": final_pred,
            "physics_pred_name": idx_to_class[final_pred],
            "changed": int(base_pred != final_pred),
            "applied_rules": "|".join(out["applied_rules"]),
            "known_expert_pred": out["known_expert"].get("known_expert_pred_name", ""),
            "known_expert_conf": out["known_expert"].get("known_expert_conf", np.nan),
            "known_expert_margin": out["known_expert"].get("known_expert_margin", np.nan),
        }
        for key, value in out["scores"].items():
            row[key] = value
        physics_rows.append(row)
        if base_pred != final_pred:
            changed_rows.append(row)

    physics_rows = apply_segment_opf_itsc_refinement(physics_rows, config=config)
    physics_pred = [int(row["physics_pred_idx"]) for row in physics_rows]
    changed_rows = [row for row in physics_rows if int(row.get("base_pred_idx", -1)) != int(row.get("physics_pred_idx", -1))]

    result_dict["base_y_pred"] = np.asarray(y_pred, dtype=np.int64)
    result_dict["physics_y_pred"] = np.asarray(physics_pred, dtype=np.int64)
    result_dict["physics_rows"] = physics_rows
    result_dict["changed_rows"] = changed_rows
    return result_dict


def save_physics_outputs(
    result_dict: Dict[str, Any],
    output_dir: str,
    split_name: str,
    idx_to_class: Dict[int, str],
    num_classes: int,
) -> Dict[str, Any]:
    """Save base/physics metrics and physics score audit CSV files."""
    base_metrics = summarize_classification_metrics(
        y_true=result_dict["y_true"],
        y_pred=result_dict["base_y_pred"],
        num_classes=num_classes,
        idx_to_class=idx_to_class,
    )
    physics_metrics = summarize_classification_metrics(
        y_true=result_dict["y_true"],
        y_pred=result_dict["physics_y_pred"],
        num_classes=num_classes,
        idx_to_class=idx_to_class,
    )
    save_json(base_metrics, os.path.join(output_dir, f"{split_name}_base_metrics.json"))
    save_json(physics_metrics, os.path.join(output_dir, f"{split_name}_physics_metrics.json"))
    pd.DataFrame(result_dict.get("physics_rows", [])).to_csv(
        os.path.join(output_dir, f"{split_name}_physics_scores_all.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    changed_columns = [
        "sample_index",
        "filename",
        "file_path",
        "window_idx",
        "window_start",
        "window_end",
        "domain_name",
        "true_label_idx",
        "true_label_name",
        "base_pred_idx",
        "base_pred_name",
        "physics_pred_idx",
        "physics_pred_name",
        "changed",
        "applied_rules",
        "known_expert_pred",
        "known_expert_conf",
        "known_expert_margin",
    ]
    changed_df = pd.DataFrame(result_dict.get("changed_rows", []))
    if changed_df.empty:
        changed_df = pd.DataFrame(columns=changed_columns)
    changed_df.to_csv(
        os.path.join(output_dir, f"{split_name}_changed_cases.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    return {"base": base_metrics, "physics": physics_metrics}


def _metrics_for_output(result_dict: Dict[str, Any], num_classes: int, idx_to_class: Dict[int, str]) -> Dict[str, Any]:
    pred = result_dict.get("physics_y_pred", result_dict["y_pred"])
    return summarize_classification_metrics(
        y_true=result_dict["y_true"],
        y_pred=pred,
        num_classes=num_classes,
        idx_to_class=idx_to_class,
    )


def save_operational_boundary_outputs(
    all_eval_outputs: Dict[str, Dict[str, Any]],
    dataset_pack: Dict[str, Any],
    output_dir: str,
    num_classes: int,
    idx_to_class: Dict[int, str],
) -> None:
    unknown_key = "operational_boundary_excluded_real_test_unknown2"
    all5_key = "operational_boundary_excluded_real_test_all5"
    if unknown_key not in all_eval_outputs or all5_key not in all_eval_outputs:
        return

    audits = dataset_pack.get("test_split_audits", {})
    sampling_audit = dict(audits.get("operational_boundary_excluded_test", {}))
    leakage_audit = sampling_audit.get("leakage_audit", {
        "forbidden_real_unknown_used": False,
        "real_unknown_used_for_training": False,
        "real_unknown_used_for_scaler": False,
        "real_unknown_used_for_reference": False,
        "real_unknown_used_for_threshold": False,
        "real_unknown_used_for_model_selection": False,
    })
    sampling_audit["leakage_audit"] = leakage_audit
    save_json(sampling_audit, os.path.join(output_dir, "operational_boundary_excluded_sampling_audit.json"))

    unknown_metrics = _metrics_for_output(all_eval_outputs[unknown_key], num_classes, idx_to_class)
    all5_metrics = _metrics_for_output(all_eval_outputs[all5_key], num_classes, idx_to_class)
    known_metrics = _metrics_for_output(all_eval_outputs["real_test_known3"], num_classes, idx_to_class)

    metrics_out = {
        "real_test_unknown2": unknown_metrics,
        "real_test_all5": all5_metrics,
        "real_known3": known_metrics,
        "leakage_audit": leakage_audit,
    }
    save_json(leakage_audit, os.path.join(output_dir, "leakage_audit.json"))
    save_json(metrics_out, os.path.join(output_dir, "operational_boundary_excluded_metrics.json"))

    class_names = [idx_to_class[i] for i in range(num_classes)]
    cm = np.asarray(all5_metrics["confusion_matrix"], dtype=np.int64)
    pd.DataFrame(cm, index=class_names, columns=class_names).to_csv(
        os.path.join(output_dir, "operational_boundary_excluded_confusion_matrix.csv"),
        encoding="utf-8-sig",
    )

    rows = all_eval_outputs[all5_key].get("physics_rows", [])
    if not rows:
        rows = build_diagnosis_confidence_rows(all_eval_outputs[all5_key], idx_to_class)
    remaining_errors = []
    for row in rows:
        true_name = str(row.get("true_label_name", ""))
        pred_name = str(row.get("physics_pred_name", row.get("pred_label_name", row.get("base_pred_name", ""))))
        if true_name == pred_name:
            continue
        remaining_errors.append({
            "sample_index": row.get("sample_index", ""),
            "filename": row.get("filename", ""),
            "file_path": row.get("file_path", ""),
            "window_idx": row.get("window_idx", ""),
            "window_start": row.get("window_start", ""),
            "window_end": row.get("window_end", ""),
            "domain_name": row.get("domain_name", ""),
            "true_label_name": true_name,
            "base_pred_name": row.get("base_pred_name", ""),
            "pred_label_name": row.get("pred_label_name", ""),
            "physics_pred_name": pred_name,
            "speed": row.get("speed", row.get("speed_rpm", "")),
            "load": row.get("load", ""),
            "applied_rules": row.get("applied_rules", ""),
        })
    pd.DataFrame(remaining_errors).to_csv(
        os.path.join(output_dir, "operational_boundary_excluded_remaining_errors.csv"),
        index=False,
        encoding="utf-8-sig",
    )

    condition_summary: Dict[str, int] = {}
    for row in remaining_errors:
        key = f"{row['true_label_name']}->{row['physics_pred_name']}|{row['load']}Nm|{row['speed']}rpm|{row['filename']}"
        condition_summary[key] = condition_summary.get(key, 0) + 1

    summary = {
        "real_test_unknown2_accuracy": float(unknown_metrics["overall_accuracy"]),
        "real_test_all5_accuracy": float(all5_metrics["overall_accuracy"]),
        "real_known3_accuracy": float(known_metrics["overall_accuracy"]),
        "ITSC_recall": all5_metrics["per_class_accuracy"].get("ITSC"),
        "tuici_recall": all5_metrics["per_class_accuracy"].get("tuici"),
        "OPF_recall": all5_metrics["per_class_accuracy"].get("OPF"),
        "health_recall": all5_metrics["per_class_accuracy"].get("health"),
        "confusion_matrix": all5_metrics["confusion_matrix"],
        "remaining_error_condition_summary": condition_summary,
        "sampling_audit_path": "operational_boundary_excluded_sampling_audit.json",
        "metrics_path": "operational_boundary_excluded_metrics.json",
        "confusion_matrix_path": "operational_boundary_excluded_confusion_matrix.csv",
        "remaining_errors_path": "operational_boundary_excluded_remaining_errors.csv",
        "leakage_audit": leakage_audit,
    }
    save_json(summary, os.path.join(output_dir, "operational_boundary_excluded_test_summary.json"))


def build_diagnosis_confidence_rows(
    result_dict: Dict[str, Any],
    idx_to_class: Dict[int, str]
) -> List[Dict[str, Any]]:
    """构建真实五类测试集逐窗口诊断结果与置信度行。"""
    y_true = result_dict["y_true"]
    y_pred = result_dict["y_pred"]
    probs = result_dict["probs"]
    meta = result_dict["meta"]

    probs_time = result_dict.get("probs_time", None)
    probs_freq = result_dict.get("probs_freq", None)
    pred_time = result_dict.get("pred_time", None)
    pred_freq = result_dict.get("pred_freq", None)
    speed_rpm = result_dict.get("speed_rpm", None)
    electrical_frequency_hz = result_dict.get("electrical_frequency_hz", None)
    reliability_score = result_dict.get("reliability_score", None)
    logit_margin = result_dict.get("logit_margin", None)
    predictive_entropy = result_dict.get("predictive_entropy", None)
    prototype_min_distance = result_dict.get("prototype_min_distance", None)
    prototype_distance_margin = result_dict.get("prototype_distance_margin", None)
    time_freq_agreement = result_dict.get("time_freq_prediction_agreement", None)
    fusion_alpha = result_dict.get("fusion_alpha", None)

    rows: List[Dict[str, Any]] = []
    for i in range(len(y_true)):
        true_idx = int(y_true[i])
        pred_idx = int(y_pred[i])
        sample_probs = probs[i]
        row = {
            "sample_index": int(i),
            "filename": meta[i].get("filename", ""),
            "file_path": meta[i].get("file_path", ""),
            "window_idx": meta[i].get("window_idx", -1),
            "window_start": meta[i].get("window_start", -1),
            "window_end": meta[i].get("window_end", -1),
            "true_label_idx": true_idx,
            "true_label_name": idx_to_class[true_idx],
            "pred_label_idx": pred_idx,
            "pred_label_name": idx_to_class[pred_idx],
            "confidence": float(sample_probs[pred_idx]),
            "correct": int(true_idx == pred_idx),
        }
        if speed_rpm is not None:
            row["speed_rpm"] = float(speed_rpm[i])
        if electrical_frequency_hz is not None:
            row["electrical_frequency_hz"] = float(electrical_frequency_hz[i])
        if pred_time is not None:
            row["pred_time_label_name"] = idx_to_class[int(pred_time[i])]
        if pred_freq is not None:
            row["pred_freq_label_name"] = idx_to_class[int(pred_freq[i])]
        if time_freq_agreement is not None:
            row["time_freq_prediction_agreement"] = float(time_freq_agreement[i])
        if reliability_score is not None:
            row["reliability_score"] = float(reliability_score[i])
        if logit_margin is not None:
            row["logit_margin"] = float(logit_margin[i])
        if predictive_entropy is not None:
            row["predictive_entropy"] = float(predictive_entropy[i])
        if prototype_min_distance is not None:
            row["prototype_min_distance"] = float(prototype_min_distance[i])
        if prototype_distance_margin is not None:
            row["prototype_distance_margin"] = float(prototype_distance_margin[i])
        if fusion_alpha is not None:
            for cls_idx, cls_name in idx_to_class.items():
                row[f"alpha_{cls_name}"] = float(fusion_alpha[int(cls_idx)])
        for cls_idx, cls_name in idx_to_class.items():
            cls_idx_int = int(cls_idx)
            row[f"prob_{cls_name}"] = float(sample_probs[cls_idx_int])
            if probs_time is not None:
                row[f"prob_time_{cls_name}"] = float(probs_time[i, cls_idx_int])
            if probs_freq is not None:
                row[f"prob_freq_{cls_name}"] = float(probs_freq[i, cls_idx_int])
        rows.append(row)
    return rows


def save_diagnosis_confidence_csv(
    result_dict: Dict[str, Any],
    save_path: str,
    idx_to_class: Dict[int, str]
) -> None:
    """保存真实域五类测试集的诊断结果和 softmax 置信度。"""
    rows = build_diagnosis_confidence_rows(result_dict, idx_to_class)
    df = pd.DataFrame(rows)
    df.to_csv(save_path, index=False, encoding="utf-8-sig")



def save_frequency_interpretability_plots(
    result_dict: Dict[str, Any],
    save_dir: str,
    split_name: str,
    idx_to_class: Dict[int, str]
) -> None:
    """保存频域分支和可靠性相关的直观分析图。"""
    ensure_dir(save_dir)
    y_true = result_dict["y_true"]
    y_pred = result_dict["y_pred"]
    if len(y_true) == 0:
        return

    safe_split_name = str(split_name).replace(os.sep, "_").replace("/", "_")
    correct = (y_true == y_pred)
    reliability = result_dict.get("reliability_score", None)
    entropy = result_dict.get("predictive_entropy", None)
    proto_min = result_dict.get("prototype_min_distance", None)

    if reliability is not None and entropy is not None and proto_min is not None:
        plt.figure(figsize=(8, 5))
        data = [reliability[correct], reliability[~correct]]
        labels = ["correct", "wrong"]
        plt.boxplot(data, labels=labels, showmeans=True)
        plt.ylabel("Reliability score")
        plt.title(f"{split_name} Reliability: Correct vs Wrong")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{safe_split_name}_reliability_correct_vs_wrong.png"), dpi=200, bbox_inches="tight")
        plt.close()

        plt.figure(figsize=(7, 5))
        plt.scatter(entropy[correct], proto_min[correct], s=12, alpha=0.65, label="correct")
        plt.scatter(entropy[~correct], proto_min[~correct], s=12, alpha=0.65, label="wrong")
        plt.xlabel("Predictive entropy")
        plt.ylabel("Prototype min distance")
        plt.title(f"{split_name} Reliability Components")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{safe_split_name}_entropy_vs_proto_distance.png"), dpi=200, bbox_inches="tight")
        plt.close()

    pred_time = result_dict.get("pred_time", None)
    pred_freq = result_dict.get("pred_freq", None)
    if pred_time is not None and pred_freq is not None:
        num_classes = len(idx_to_class)
        heatmap = np.zeros((num_classes, num_classes), dtype=np.int64)
        for t, f in zip(pred_time, pred_freq):
            heatmap[int(t), int(f)] += 1
        plt.figure(figsize=(7, 6))
        plt.imshow(heatmap, cmap="Blues")
        plt.colorbar(label="count")
        class_names = [idx_to_class[i] for i in range(num_classes)]
        plt.xticks(np.arange(num_classes), class_names, rotation=45, ha="right")
        plt.yticks(np.arange(num_classes), class_names)
        plt.xlabel("Frequency branch prediction")
        plt.ylabel("Time branch prediction")
        plt.title(f"{split_name} Time-Frequency Agreement")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{safe_split_name}_fusion_branch_agreement_heatmap.png"), dpi=200, bbox_inches="tight")
        plt.close()

    centers = result_dict.get("freq_order_centers_hz", None)
    speed_rpm = result_dict.get("speed_rpm", None)
    if centers is not None and getattr(centers, "size", 0) > 0 and speed_rpm is not None:
        order = np.argsort(speed_rpm)
        sorted_speed = speed_rpm[order]
        sorted_centers = centers[order]
        plt.figure(figsize=(8, 5))
        for j in range(sorted_centers.shape[1]):
            plt.plot(sorted_speed, sorted_centers[:, j], marker=".", linestyle="none", alpha=0.6, label=f"center {j + 1}")
        plt.xlabel("Speed (rpm)")
        plt.ylabel("Learned center frequency (Hz)")
        plt.title(f"{split_name} Electrical-Frequency Centers")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{safe_split_name}_freq_centers_by_speed.png"), dpi=200, bbox_inches="tight")
        plt.close()


def save_fusion_alpha_summary(
    result_dict: Dict[str, Any],
    save_path: str,
    idx_to_class: Dict[int, str]
) -> None:
    fusion_alpha = result_dict.get("fusion_alpha", None)
    if fusion_alpha is None:
        return
    summary = {
        idx_to_class[int(i)]: float(fusion_alpha[int(i)])
        for i in range(len(fusion_alpha))
    }
    save_json(summary, save_path)


def infer_scaler_path(ckpt_path: str, checkpoint_dir: str) -> str:
    """
    根据 ckpt 文件名推断 scaler 路径
    """
    name = os.path.basename(ckpt_path).lower()
    if "stage1" in name:
        return os.path.join(checkpoint_dir, "scaler_stage1.json")
    if "stage2" in name:
        return os.path.join(checkpoint_dir, "scaler_stage2.json")
    if "stage3" in name:
        return os.path.join(checkpoint_dir, "scaler_stage3.json")
    # 默认退化为 stage3
    return os.path.join(checkpoint_dir, "scaler_stage3.json")


def main():
    args = parse_args()
    config = load_config(args.config)

    paths_cfg = config["paths"]
    ckpt_path = args.ckpt
    output_dir = args.output_dir or paths_cfg["output_dir"]
    physics_enabled = bool(config.get("physics_fusion", {}).get("enabled", False)) and not bool(args.disable_physics)

    ensure_dir(output_dir)
    ensure_dir(paths_cfg["log_dir"])
    ensure_dir(os.path.join(output_dir, "confusion_matrices"))
    ensure_dir(os.path.join(output_dir, "tsne"))
    ensure_dir(os.path.join(output_dir, "prototype_analysis"))
    ensure_dir(os.path.join(output_dir, "frequency_analysis"))

    logger = setup_logger(
        name="test",
        log_dir=paths_cfg["log_dir"],
        log_filename=args.log_filename or "test.log",
        level=config["logging"]["level"]
    )

    set_random_seed(int(config["random_seed"]))
    device = get_device(config)
    logger.info("========== 开始测试 ==========")
    logger.info(f"使用设备: {device}")

    if args.scaler is not None:
        scaler_path = args.scaler
    else:
        scaler_path = infer_scaler_path(ckpt_path, paths_cfg["checkpoint_dir"])

    if not os.path.exists(scaler_path):
        raise FileNotFoundError(f"未找到 scaler 文件: {scaler_path}")

    scaler = load_scaler(scaler_path)
    logger.info(f"已加载 scaler: {scaler_path}")

    # 按与训练相同的 split 方式构造 test 集
    split_pack = get_or_create_split_records(config=config, logger=logger)
    split_records = split_pack["split_records"]

    dataset_pack = build_stage_datasets_from_splits(
        config=config,
        split_records=split_records,
        stage_name="test",
        logger=logger,
        scaler=scaler,
        fit_scaler=False,
    )

    test_datasets = dataset_pack["test_datasets"]
    data_cfg = config["data"]

    target_eval_splits = get_target_eval_split_names(test_datasets)
    test_loaders = {
        name: build_dataloader(
            dataset=test_datasets[name],
            batch_size=int(data_cfg["batch_size"]),
            num_workers=int(data_cfg["num_workers"]),
            pin_memory=bool(data_cfg["pin_memory"]),
            shuffle=False,
            drop_last=False,
        )
        for name in target_eval_splits
    }

    # 模型
    model = build_model(config).to(device)
    load_model_weights(model, ckpt_path, map_location="cpu", strict=True)
    model.eval()
    logger.info(f"已加载测试 checkpoint: {ckpt_path}")

    num_classes = int(config["model"]["num_classes"])
    class_names = [IDX_TO_CLASS[i] for i in range(num_classes)]

    all_eval_outputs = {}

    for split_name, loader in test_loaders.items():
        logger.info(f"开始评估: {split_name}")
        eval_out = evaluate_loader(
            model=model,
            loader=loader,
            device=device,
            num_classes=num_classes
        )
        if physics_enabled:
            eval_out = apply_physics_postprocess_to_eval(
                result_dict=eval_out,
                config=config,
                idx_to_class=IDX_TO_CLASS,
            )
        all_eval_outputs[split_name] = eval_out

        metrics = summarize_classification_metrics(
            y_true=eval_out["y_true"],
            y_pred=eval_out["y_pred"],
            num_classes=num_classes,
            idx_to_class=IDX_TO_CLASS
        )

        # 保存 json
        json_path = os.path.join(output_dir, f"{split_name}_metrics.json")
        save_json(metrics, json_path)
        if physics_enabled:
            physics_metrics = save_physics_outputs(
                result_dict=eval_out,
                output_dir=output_dir,
                split_name=split_name,
                idx_to_class=IDX_TO_CLASS,
                num_classes=num_classes,
            )
            logger.info(
                "%s physics_overall_accuracy=%.4f",
                split_name,
                physics_metrics["physics"]["overall_accuracy"],
            )

        # 保存 confusion matrix figure
        if bool(config["evaluation"].get("save_confusion_matrix", False)):
            cm = np.asarray(metrics["confusion_matrix"], dtype=np.int64)
            fig_path = os.path.join(output_dir, "confusion_matrices", f"{split_name}_cm.png")
            save_confusion_matrix_figure(
                confusion_matrix=cm,
                class_names=class_names,
                save_path=fig_path,
                normalize=False,
                title=f"{split_name} Confusion Matrix"
            )

        logger.info(f"{split_name} overall_accuracy={metrics['overall_accuracy']:.4f}")
        logger.info(f"{split_name} per_class_accuracy={metrics['per_class_accuracy']}")

        if bool(config["evaluation"].get("save_frequency_interpretability", False)):
            save_frequency_interpretability_plots(
                result_dict=eval_out,
                save_dir=os.path.join(output_dir, "frequency_analysis"),
                split_name=split_name,
                idx_to_class=IDX_TO_CLASS,
            )

    save_operational_boundary_outputs(
        all_eval_outputs=all_eval_outputs,
        dataset_pack=dataset_pack,
        output_dir=output_dir,
        num_classes=num_classes,
        idx_to_class=IDX_TO_CLASS,
    )

    # 真实域五类测试集逐窗口诊断结果与置信度
    real_all_key = "real_test_all5" if "real_test_all5" in all_eval_outputs else "real_test_all5_final"
    save_diagnosis_confidence_csv(
        result_dict=all_eval_outputs[real_all_key],
        save_path=os.path.join(output_dir, f"{real_all_key}_diagnosis_confidence.csv"),
        idx_to_class=IDX_TO_CLASS,
    )
    save_fusion_alpha_summary(
        result_dict=all_eval_outputs[real_all_key],
        save_path=os.path.join(output_dir, f"{real_all_key}_fusion_alpha_summary.json"),
        idx_to_class=IDX_TO_CLASS,
    )
    logger.info("融合 alpha summary JSON 已保存")

    # t-SNE：使用 sim_test + 真实全5类综合测试集共同可视化
    if bool(config["evaluation"]["save_tsne"]):
        sim_out = all_eval_outputs["sim_test"]
        real_out = all_eval_outputs[real_all_key]

        features = np.concatenate([sim_out["features"], real_out["features"]], axis=0)
        labels = np.concatenate([sim_out["y_true"], real_out["y_true"]], axis=0)
        domains = np.concatenate([sim_out["domains"], real_out["domains"]], axis=0)

        save_tsne_plots(
            features=features,
            labels=labels,
            domains=domains,
            save_dir=os.path.join(output_dir, "tsne"),
            perplexity=int(config["evaluation"]["tsne_perplexity"]),
            random_state=int(config["evaluation"]["tsne_random_state"]),
            max_samples=int(config["evaluation"]["max_tsne_samples"]),
        )
        logger.info("t-SNE 图已保存")

    logger.info("========== 测试完成 ==========")


if __name__ == "__main__":
    main()
