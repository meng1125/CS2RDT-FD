# losses.py
# -*- coding: utf-8 -*-

"""
五分类跨域故障诊断损失函数：
- 仿真域五类分类损失
- 真实域可见已知类分类损失
- 原型约束损失
- 条件域对齐损失
- 全局域对齐损失
- teacher-student 蒸馏损失
"""

from typing import Dict, Optional, Sequence, Any

import torch
import torch.nn.functional as F

from local_mapping import estimate_shift


CLASS_NAME_TO_IDX = {
    "health": 0,
    "OPF": 1,
    "ITSC": 2,
    "Sensor": 3,
    "tuici": 4,
}


def _zero_like_reference(outputs: Dict[str, torch.Tensor]) -> torch.Tensor:
    """
    返回一个与当前计算图设备一致的 0 标量
    """
    for v in outputs.values():
        if isinstance(v, torch.Tensor):
            return v.new_tensor(0.0)
    return torch.tensor(0.0, dtype=torch.float32)


def _build_known_class_mask(
    y: torch.Tensor,
    known_real_class_indices: Sequence[int]
) -> torch.Tensor:
    """
    构造 y 是否属于已知真实类的 mask
    """
    mask = torch.zeros_like(y, dtype=torch.bool)
    for cls_idx in known_real_class_indices:
        mask |= (y == int(cls_idx))
    return mask


def _parse_class_index(key: Any) -> int:
    if isinstance(key, str):
        key = key.strip()
        if key in CLASS_NAME_TO_IDX:
            return int(CLASS_NAME_TO_IDX[key])
        if key.isdigit() or (key.startswith("-") and key[1:].isdigit()):
            return int(key)
        raise ValueError(f"unknown class key in distill_class_weights: {key}")
    return int(key)


def _build_distill_sample_weights(
    y: torch.Tensor,
    class_weights: Optional[Any],
    protected_class_indices: Sequence[int],
    protected_weight: float,
) -> torch.Tensor:
    weight = torch.ones_like(y, dtype=torch.float32, device=y.device)

    if class_weights is None:
        for cls_idx in protected_class_indices:
            weight = torch.where(
                y == int(cls_idx),
                torch.full_like(weight, float(protected_weight)),
                weight,
            )
        return weight

    if isinstance(class_weights, dict):
        for key, value in class_weights.items():
            cls_idx = _parse_class_index(key)
            weight = torch.where(
                y == cls_idx,
                torch.full_like(weight, float(value)),
                weight,
            )
        return weight

    values = list(class_weights)
    if len(values) <= 0:
        return weight
    class_weight_tensor = torch.tensor(values, dtype=torch.float32, device=y.device)
    if y.max().item() >= class_weight_tensor.numel() or y.min().item() < 0:
        raise ValueError(
            f"distill_class_weights length={class_weight_tensor.numel()} "
            f"does not cover labels range [{int(y.min().item())}, {int(y.max().item())}]"
        )
    return class_weight_tensor[y]


def _masked_cross_entropy(
    logits: torch.Tensor,
    targets: torch.Tensor,
    mask: torch.Tensor,
    label_smoothing: float = 0.0
) -> torch.Tensor:
    """
    带 mask 的交叉熵
    """
    if mask.sum().item() <= 0:
        return logits.new_tensor(0.0)

    logits_sel = logits[mask]
    targets_sel = targets[mask]
    return F.cross_entropy(
        logits_sel,
        targets_sel,
        reduction="mean",
        label_smoothing=label_smoothing
    )


def _masked_mse_ignore_nan(
    pred: torch.Tensor,
    target: torch.Tensor
) -> torch.Tensor:
    """
    对回归目标做带 NaN 忽略的 MSE

    输入:
        pred:   [B, D]
        target: [B, D]

    说明：
    - 如果某一维目标缺失（NaN），则该位置不参与损失
    - 若整批都没有有效工况标签，则返回 0
    """
    valid_mask = ~torch.isnan(target)
    if valid_mask.sum().item() <= 0:
        return pred.new_tensor(0.0)

    diff2 = (pred - target) ** 2
    diff2 = diff2[valid_mask]
    return diff2.mean()


def sim_classification_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    label_smoothing: float = 0.0,
    logit_key: str = "logits",
) -> torch.Tensor:
    """
    仿真分类损失
    """
    logits = outputs[logit_key]
    y = batch["y"]
    domain = batch["domain"]

    sim_mask = (domain == 0)
    return _masked_cross_entropy(
        logits=logits,
        targets=y,
        mask=sim_mask,
        label_smoothing=label_smoothing
    )


def real_classification_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    label_smoothing: float = 0.0,
    logit_key: str = "logits",
) -> torch.Tensor:
    """
    真实三类监督分类损失。
    仅对真实域中 trainable_in_real == 1 的样本计算。
    """
    logits = outputs[logit_key]
    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]

    real_known_mask = (domain == 1) & (trainable_in_real == 1)
    return _masked_cross_entropy(
        logits=logits,
        targets=y,
        mask=real_known_mask,
        label_smoothing=label_smoothing
    )


def alpha_prior_loss(outputs: Dict[str, torch.Tensor]) -> torch.Tensor:
    alpha = outputs.get("alpha", None)
    alpha_prior = outputs.get("alpha_prior", None)
    if alpha is None or alpha_prior is None:
        ref = outputs["logits"]
        return ref.new_tensor(0.0)
    alpha_prior = alpha_prior.to(device=alpha.device, dtype=alpha.dtype)
    return F.mse_loss(alpha, alpha_prior)


def prototype_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    prototypes: torch.Tensor,
    proto_margin: float = 1.0,
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    metric: str = "cosine"
) -> Dict[str, torch.Tensor]:
    """
    原型相关损失，包含三部分：
    1. 类内紧致：样本接近本类原型
    2. 同类仿真-真实靠近：仅针对真实可见 4 类
    3. 不同类分离：不同类原型之间保持间隔

    返回:
        {
          "total": ...,
          "compact": ...,
          "cross_domain_pull": ...,
          "inter_separation": ...
        }

    说明：
    - 这里假设 z_fault 已在模型中做过归一化（前面的 models.py 中是这样的）
    - 对原型也做归一化，便于使用统一距离度量
    """
    z_fault = outputs["z_fault"]                       # [B, D]
    y = batch["y"]                                    # [B]
    domain = batch["domain"]                          # [B]
    trainable_in_real = batch["trainable_in_real"]    # [B]

    ref_zero = z_fault.new_tensor(0.0)

    z_norm = F.normalize(z_fault, dim=1)
    p_norm = F.normalize(prototypes, dim=1)

    # 1) 类内紧致：每个样本要靠近其所属类别原型
    own_proto = p_norm[y]                             # [B, D]
    if metric == "cosine":
        compact = 1.0 - F.cosine_similarity(z_norm, own_proto, dim=1)
        compact = compact.mean()
    else:
        compact = ((z_norm - own_proto) ** 2).sum(dim=1).mean()

    # 2) 同类仿真-真实靠近（只针对真实可见 4 类）
    cross_domain_terms = []
    for cls_idx in known_real_class_indices:
        sim_mask = (domain == 0) & (y == int(cls_idx))
        real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx))

        if sim_mask.sum().item() > 0 and real_mask.sum().item() > 0:
            sim_center = F.normalize(z_fault[sim_mask].mean(dim=0, keepdim=True), dim=1)
            real_center = F.normalize(z_fault[real_mask].mean(dim=0, keepdim=True), dim=1)

            if metric == "cosine":
                term = 1.0 - F.cosine_similarity(sim_center, real_center, dim=1).mean()
            else:
                term = ((sim_center - real_center) ** 2).mean()
            cross_domain_terms.append(term)

    if len(cross_domain_terms) > 0:
        cross_domain_pull = torch.stack(cross_domain_terms).mean()
    else:
        cross_domain_pull = ref_zero

    # 3) 不同类分离：类原型两两之间距离至少大于 margin
    # 这里统一使用归一化原型后的欧氏距离
    pairwise_dist = torch.cdist(p_norm, p_norm, p=2)  # [K, K]
    num_classes = pairwise_dist.size(0)
    eye_mask = torch.eye(num_classes, dtype=torch.bool, device=pairwise_dist.device)
    off_diag_dist = pairwise_dist[~eye_mask]

    if off_diag_dist.numel() > 0:
        inter_separation = F.relu(proto_margin - off_diag_dist).mean()
    else:
        inter_separation = ref_zero

    total = compact + cross_domain_pull + inter_separation

    return {
        "total": total,
        "compact": compact,
        "cross_domain_pull": cross_domain_pull,
        "inter_separation": inter_separation,
    }


def global_domain_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    known_real_class_indices: Sequence[int] = (0, 1, 3)
) -> torch.Tensor:
    """
    全局域对齐损失：
    - 仿真域：仅真实已知类参与，不包含真实未知候选类
    - 真实域：仅真实已知类参与

    这样避免真实未知类缺少目标域监督时，仿真未知候选类被全局域对齐强行拉入已知类真实域流形。
    """
    global_domain_logits = outputs["global_domain_logits"]
    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]

    known_mask = _build_known_class_mask(y, known_real_class_indices)

    sim_known_mask = (domain == 0) & known_mask
    real_known_mask = (domain == 1) & (trainable_in_real == 1) & known_mask
    align_mask = sim_known_mask | real_known_mask

    if align_mask.sum().item() <= 0:
        return global_domain_logits.new_tensor(0.0)

    selected_domains = domain[align_mask]
    unique_domains = torch.unique(selected_domains)
    if unique_domains.numel() < 2:
        return global_domain_logits.new_tensor(0.0)

    return F.cross_entropy(global_domain_logits[align_mask], domain[align_mask])

def _covariance_matrix(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """
    x: [N, D]
    return: [D, D]
    """
    n = x.size(0)
    if n <= 1:
        return x.new_zeros((x.size(1), x.size(1)))

    x = x - x.mean(dim=0, keepdim=True)
    cov = x.t().matmul(x) / float(n - 1)
    cov = cov + eps * torch.eye(x.size(1), device=x.device, dtype=x.dtype)
    return cov


def _get_freq_feature(
    outputs: Dict[str, torch.Tensor],
    feature_key: str = "freq_order_features",
) -> Optional[torch.Tensor]:
    value = outputs.get(feature_key)
    if value is None:
        return None
    if not isinstance(value, torch.Tensor):
        return None
    value = value.float()
    if feature_key == "freq_order_features":
        if value.dim() != 3:
            return None
        return value.flatten(start_dim=1)
    if feature_key == "freq_vec":
        if value.dim() != 2:
            return None
        return value
    if value.dim() > 2:
        return value.flatten(start_dim=1)
    return value


def classwise_coral_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    mean_weight: float = 1.0,
    cov_weight: float = 1.0,
) -> torch.Tensor:
    """
    只对真实已知类做 class-wise CORAL：
    health / OPF / Sensor 的 sim 和 real 分别按类对齐。
    不使用 real ITSC / tuici。
    """
    z = outputs["z_fault"]
    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]

    losses = []

    for cls_idx in known_real_class_indices:
        sim_mask = (domain == 0) & (y == int(cls_idx))
        real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx))

        if sim_mask.sum().item() <= 1 or real_mask.sum().item() <= 1:
            continue

        z_sim = z[sim_mask]
        z_real = z[real_mask]

        mean_loss = F.mse_loss(
            z_sim.mean(dim=0),
            z_real.mean(dim=0),
        )

        cov_sim = _covariance_matrix(z_sim)
        cov_real = _covariance_matrix(z_real)
        cov_loss = F.mse_loss(cov_sim, cov_real)

        losses.append(mean_weight * mean_loss + cov_weight * cov_loss)

    if len(losses) == 0:
        return z.new_tensor(0.0)

    return torch.stack(losses).mean()


def _condition_values_for_frequency(
    batch: Dict[str, Any],
    reference: torch.Tensor,
    use_load_in_condition: bool = True,
) -> tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    if "speed" not in batch:
        return None, None
    speed = batch["speed"].to(device=reference.device, dtype=reference.dtype).view(-1)
    load = batch.get("load", None)
    if load is not None:
        load = load.to(device=reference.device, dtype=reference.dtype).view(-1)

    use_load = bool(use_load_in_condition) and load is not None
    if use_load:
        cond = torch.stack([speed, load], dim=1)
        cond_valid = ~torch.isnan(cond).any(dim=1)
    else:
        cond = speed.view(-1, 1)
        cond_valid = ~torch.isnan(speed)
    return cond, cond_valid


def _frequency_condition_bins(
    batch: Dict[str, Any],
    reference: torch.Tensor,
    speed_bin_size: float,
    load_bin_size: float,
    use_load_in_condition: bool,
    eps: float = 1e-8,
) -> tuple[Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor], bool]:
    if "speed" not in batch:
        return None, None, None, False
    speed = batch["speed"].to(device=reference.device, dtype=reference.dtype).view(-1)
    load = batch.get("load", None)
    if load is not None:
        load = load.to(device=reference.device, dtype=reference.dtype).view(-1)

    use_load = bool(use_load_in_condition) and load is not None
    speed_bin = torch.round(speed / max(float(speed_bin_size), eps)) * float(speed_bin_size)
    if use_load:
        load_bin = torch.round(load / max(float(load_bin_size), eps)) * float(load_bin_size)
    else:
        load_bin = None
    return speed, speed_bin, load_bin, use_load


def _make_bin_key(
    idx: int,
    speed_bin: torch.Tensor,
    load_bin: Optional[torch.Tensor],
    use_load: bool,
) -> tuple[float, ...]:
    if use_load and load_bin is not None:
        return (
            float(speed_bin[idx].detach().cpu().item()),
            float(load_bin[idx].detach().cpu().item()),
        )
    return (float(speed_bin[idx].detach().cpu().item()),)


def classwise_frequency_coral_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    feature_key: str = "freq_order_features",
    mean_weight: float = 1.0,
    cov_weight: float = 0.5,
    condition_wise: bool = False,
    speed_bin_size: float = 100.0,
    load_bin_size: float = 0.5,
    min_samples_per_bin: int = 2,
    use_load_in_condition: bool = True,
) -> Dict[str, torch.Tensor]:
    feat = _get_freq_feature(outputs, feature_key=feature_key)
    ref_zero = _zero_like_reference(outputs)
    if feat is None:
        return {"total": ref_zero, "mean": ref_zero, "cov": ref_zero, "num_groups": ref_zero}

    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]
    mean_losses = []
    cov_losses = []

    if not condition_wise:
        for cls_idx in known_real_class_indices:
            sim_mask = (domain == 0) & (y == int(cls_idx))
            real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx))
            if (
                sim_mask.sum().item() < int(min_samples_per_bin)
                or real_mask.sum().item() < int(min_samples_per_bin)
            ):
                continue
            f_sim = feat[sim_mask]
            f_real = feat[real_mask]
            mean_losses.append(F.mse_loss(f_sim.mean(dim=0), f_real.mean(dim=0)))
            cov_losses.append(F.mse_loss(_covariance_matrix(f_sim), _covariance_matrix(f_real)))
    else:
        cond, cond_valid = _condition_values_for_frequency(
            batch=batch,
            reference=feat,
            use_load_in_condition=use_load_in_condition,
        )
        speed, speed_bin, load_bin, use_load = _frequency_condition_bins(
            batch=batch,
            reference=feat,
            speed_bin_size=speed_bin_size,
            load_bin_size=load_bin_size,
            use_load_in_condition=use_load_in_condition,
        )
        if cond is not None and cond_valid is not None and speed_bin is not None:
            for cls_idx in known_real_class_indices:
                sim_mask = (domain == 0) & (y == int(cls_idx)) & cond_valid
                real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx)) & cond_valid
                sim_bins = {}
                real_bins = {}
                for idx in torch.nonzero(sim_mask, as_tuple=False).view(-1).detach().cpu().tolist():
                    sim_bins.setdefault(_make_bin_key(int(idx), speed_bin, load_bin, use_load), []).append(int(idx))
                for idx in torch.nonzero(real_mask, as_tuple=False).view(-1).detach().cpu().tolist():
                    real_bins.setdefault(_make_bin_key(int(idx), speed_bin, load_bin, use_load), []).append(int(idx))

                for key in sorted(set(sim_bins).intersection(real_bins)):
                    sim_indices = sim_bins[key]
                    real_indices = real_bins[key]
                    if (
                        len(sim_indices) < int(min_samples_per_bin)
                        or len(real_indices) < int(min_samples_per_bin)
                    ):
                        continue
                    sim_idx_tensor = torch.as_tensor(sim_indices, dtype=torch.long, device=feat.device)
                    real_idx_tensor = torch.as_tensor(real_indices, dtype=torch.long, device=feat.device)
                    f_sim = feat.index_select(0, sim_idx_tensor)
                    f_real = feat.index_select(0, real_idx_tensor)
                    mean_losses.append(F.mse_loss(f_sim.mean(dim=0), f_real.mean(dim=0)))
                    cov_losses.append(F.mse_loss(_covariance_matrix(f_sim), _covariance_matrix(f_real)))

    if len(mean_losses) == 0:
        return {"total": ref_zero, "mean": ref_zero, "cov": ref_zero, "num_groups": ref_zero}

    mean_loss = torch.stack(mean_losses).mean()
    cov_loss = torch.stack(cov_losses).mean()
    total = float(mean_weight) * mean_loss + float(cov_weight) * cov_loss
    return {
        "total": total,
        "mean": mean_loss,
        "cov": cov_loss,
        "num_groups": feat.new_tensor(float(len(mean_losses))),
    }


def frequency_unknown_shift_transfer_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    model: torch.nn.Module,
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    anomaly_class_indices: Sequence[int] = (2, 4),
    class_weights: Optional[Any] = None,
    feature_key: str = "freq_vec",
    delta_scale: float = 0.5,
    speed_bin_size: float = 100.0,
    load_bin_size: float = 0.5,
    min_samples_per_bin: int = 2,
    delta_bank_temperature: float = 1.0,
    use_load_in_condition: bool = True,
    label_smoothing: float = 0.0,
    margin: float = 0.25,
    logit_weight: float = 1.0,
    boundary_weight: float = 1.0,
    compact_weight: float = 0.1,
    detach_delta: bool = True,
    eps: float = 1e-8,
    lambda_map: Optional[float] = None,
    mapping_audit_path: Optional[str] = None,
) -> Dict[str, torch.Tensor]:
    feat = _get_freq_feature(outputs, feature_key=feature_key)
    ref_zero = _zero_like_reference(outputs)
    zero_dict = {
        "total": ref_zero,
        "ce": ref_zero,
        "boundary": ref_zero,
        "compact": ref_zero,
        "delta_norm": ref_zero,
        "raw_delta_norm": ref_zero,
        "scaled_delta_norm": ref_zero,
        "delta_bank_size": ref_zero,
        "delta_bank_fallback": ref_zero,
        "weight_mean": ref_zero,
    }
    if feat is None or getattr(model, "freq_classifier", None) is None:
        return zero_dict

    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]
    anomaly_mask = (domain == 0) & _build_known_class_mask(y, anomaly_class_indices)
    if anomaly_mask.sum().item() <= 0:
        return zero_dict

    if lambda_map is not None and anomaly_mask.any().item():
        selected_feat = feat[anomaly_mask]
        per_sample_delta, delta_bank_size = estimate_shift(
            feat, batch, anomaly_mask, branch="frequency", lambda_map=lambda_map,
            speed_bin_size=speed_bin_size, load_bin_size=load_bin_size,
            min_samples_per_bin=min_samples_per_bin, use_load=use_load_in_condition,
            known_labels=known_real_class_indices, target_labels=anomaly_class_indices,
            detach_delta=detach_delta, temperature=delta_bank_temperature,
            eps=eps, audit_path=mapping_audit_path,
        )
        delta_bank_fallback = ref_zero
        selected_labels = y[anomaly_mask]
    else:
        deltas = []
        for cls_idx in known_real_class_indices:
            sim_mask = (domain == 0) & (y == int(cls_idx))
            real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx))
            if sim_mask.sum().item() > 0 and real_mask.sum().item() > 0:
                deltas.append(feat[real_mask].mean(dim=0) - feat[sim_mask].mean(dim=0))
        if len(deltas) <= 0:
            return zero_dict

        global_delta_bank = torch.stack(deltas, dim=0)
        global_delta = global_delta_bank.mean(dim=0, keepdim=True)
        selected_feat = feat[anomaly_mask]
        selected_labels = y[anomaly_mask]
        delta_bank_size = ref_zero
        delta_bank_fallback = ref_zero
        per_sample_delta = None

        cond, cond_valid = _condition_values_for_frequency(
            batch=batch,
            reference=feat,
            use_load_in_condition=use_load_in_condition,
        )
        speed, speed_bin, load_bin, use_load = _frequency_condition_bins(
            batch=batch,
            reference=feat,
            speed_bin_size=speed_bin_size,
            load_bin_size=load_bin_size,
            use_load_in_condition=use_load_in_condition,
        )
        if cond is not None and cond_valid is not None and speed_bin is not None:
            bank_deltas = []
            bank_centers = []
            for cls_idx in known_real_class_indices:
                sim_mask = (domain == 0) & (y == int(cls_idx)) & cond_valid
                real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx)) & cond_valid
                sim_bins = {}
                real_bins = {}
                for idx in torch.nonzero(sim_mask, as_tuple=False).view(-1).detach().cpu().tolist():
                    sim_bins.setdefault(_make_bin_key(int(idx), speed_bin, load_bin, use_load), []).append(int(idx))
                for idx in torch.nonzero(real_mask, as_tuple=False).view(-1).detach().cpu().tolist():
                    real_bins.setdefault(_make_bin_key(int(idx), speed_bin, load_bin, use_load), []).append(int(idx))
                for key in sorted(set(sim_bins).intersection(real_bins)):
                    sim_indices = sim_bins[key]
                    real_indices = real_bins[key]
                    if (
                        len(sim_indices) < int(min_samples_per_bin)
                        or len(real_indices) < int(min_samples_per_bin)
                    ):
                        continue
                    sim_idx_tensor = torch.as_tensor(sim_indices, dtype=torch.long, device=feat.device)
                    real_idx_tensor = torch.as_tensor(real_indices, dtype=torch.long, device=feat.device)
                    bank_deltas.append(
                        feat.index_select(0, real_idx_tensor).mean(dim=0)
                        - feat.index_select(0, sim_idx_tensor).mean(dim=0)
                    )
                    bank_centers.append(
                        0.5
                        * (
                            cond.index_select(0, sim_idx_tensor).mean(dim=0)
                            + cond.index_select(0, real_idx_tensor).mean(dim=0)
                        )
                    )

            if len(bank_deltas) > 0:
                delta_tensor = torch.stack(bank_deltas, dim=0)
                cond_tensor = torch.stack(bank_centers, dim=0)
                delta_bank_size = feat.new_tensor(float(len(bank_deltas)))
                selected_cond = cond[anomaly_mask]
                valid_selected = cond_valid[anomaly_mask]
                if valid_selected.sum().item() > 0:
                    norm_source = torch.cat([cond_tensor, selected_cond[valid_selected]], dim=0)
                    cond_mean = norm_source.mean(dim=0, keepdim=True)
                    cond_std = norm_source.std(dim=0, keepdim=True, unbiased=False).clamp_min(eps)
                    bank_norm = (cond_tensor - cond_mean) / cond_std
                    safe_selected_cond = torch.where(
                        valid_selected.view(-1, 1),
                        selected_cond,
                        cond_mean.expand_as(selected_cond),
                    )
                    selected_norm = (safe_selected_cond - cond_mean) / cond_std
                    dist_sq = torch.cdist(selected_norm, bank_norm, p=2).pow(2)
                    weights = torch.softmax(-dist_sq / max(float(delta_bank_temperature), eps), dim=1)
                    per_sample_delta = torch.matmul(weights, delta_tensor)
                    per_sample_delta = torch.where(
                        valid_selected.view(-1, 1),
                        per_sample_delta,
                        global_delta.expand_as(per_sample_delta),
                    )
                    if (~valid_selected).any().item():
                        delta_bank_fallback = feat.new_tensor(1.0)
                else:
                    delta_bank_fallback = feat.new_tensor(1.0)
            else:
                delta_bank_fallback = feat.new_tensor(1.0)

        if per_sample_delta is None:
            per_sample_delta = global_delta.expand(selected_feat.size(0), -1)
            delta_bank_fallback = feat.new_tensor(1.0)

    raw_delta_norm = per_sample_delta.norm(dim=1).mean()
    per_sample_delta = float(delta_scale) * per_sample_delta
    scaled_delta_norm = per_sample_delta.norm(dim=1).mean()
    if detach_delta:
        per_sample_delta = per_sample_delta.detach()

    shifted_feat = selected_feat + per_sample_delta
    logits_shifted = model.freq_classifier(shifted_feat)
    sample_weight = _build_distill_sample_weights(
        y=selected_labels,
        class_weights=class_weights,
        protected_class_indices=anomaly_class_indices,
        protected_weight=1.0,
    ).to(device=feat.device, dtype=feat.dtype)
    weight_denom = sample_weight.sum().clamp_min(eps)

    ce_per_sample = F.cross_entropy(
        logits_shifted,
        selected_labels,
        reduction="none",
        label_smoothing=float(label_smoothing),
    )
    ce_loss = (ce_per_sample * sample_weight).sum() / weight_denom

    known_centers = []
    for cls_idx in known_real_class_indices:
        center_mask = ((domain == 0) | ((domain == 1) & (trainable_in_real == 1))) & (y == int(cls_idx))
        if center_mask.sum().item() > 0:
            known_centers.append(feat[center_mask].mean(dim=0))
    if len(known_centers) <= 0:
        return zero_dict

    own_centers = {}
    for cls_idx in anomaly_class_indices:
        own_mask = (domain == 0) & (y == int(cls_idx))
        if own_mask.sum().item() > 0:
            own_centers[int(cls_idx)] = feat[own_mask].mean(dim=0)
    if len(own_centers) <= 0:
        return zero_dict

    shifted_norm = F.normalize(shifted_feat, dim=1)
    known_center_tensor = torch.stack(known_centers, dim=0).to(device=feat.device, dtype=feat.dtype)
    known_norm = F.normalize(known_center_tensor, dim=1)
    known_distance = 1.0 - torch.matmul(shifted_norm, known_norm.t())
    nearest_known_distance = known_distance.min(dim=1).values

    own_center_rows = []
    valid_rows = []
    for i, label in enumerate(selected_labels.detach().cpu().tolist()):
        label = int(label)
        if label in own_centers:
            own_center_rows.append(own_centers[label])
            valid_rows.append(i)
    if len(valid_rows) <= 0:
        return zero_dict

    valid_idx = torch.as_tensor(valid_rows, dtype=torch.long, device=feat.device)
    own_center_tensor = torch.stack(own_center_rows, dim=0).to(device=feat.device, dtype=feat.dtype)
    own_norm = F.normalize(own_center_tensor, dim=1)
    valid_shifted_norm = shifted_norm.index_select(0, valid_idx)
    own_distance = 1.0 - F.cosine_similarity(valid_shifted_norm, own_norm, dim=1)
    selected_nearest_known = nearest_known_distance.index_select(0, valid_idx)
    valid_weight = sample_weight.index_select(0, valid_idx)
    valid_weight_denom = valid_weight.sum().clamp_min(eps)
    boundary_per_sample = F.relu(own_distance - selected_nearest_known + float(margin))
    boundary_loss = (boundary_per_sample * valid_weight).sum() / valid_weight_denom
    compact_loss = (own_distance * valid_weight).sum() / valid_weight_denom
    total = (
        float(logit_weight) * ce_loss
        + float(boundary_weight) * boundary_loss
        + float(compact_weight) * compact_loss
    )

    return {
        "total": total,
        "ce": ce_loss,
        "boundary": boundary_loss,
        "compact": compact_loss,
        "delta_norm": scaled_delta_norm,
        "raw_delta_norm": raw_delta_norm,
        "scaled_delta_norm": scaled_delta_norm,
        "delta_bank_size": delta_bank_size,
        "delta_bank_fallback": delta_bank_fallback,
        "weight_mean": sample_weight.mean(),
    }

def conditional_domain_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    known_real_class_indices: Sequence[int] = (0, 1, 3)
) -> torch.Tensor:
    """
    条件域对齐损失：
    只对“真实训练可见已知类”对应的仿真样本和真实样本进行域对齐，
    避免把未知真实类硬拉入对齐导致边界塌缩。

    对齐样本选择规则：
    - 仿真域中：label ∈ 已知真实类
    - 真实域中：trainable_in_real == 1 且 label ∈ 已知真实类
    """
    domain_logits = outputs["domain_logits"]          # [B, 2]
    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]

    known_mask = _build_known_class_mask(y, known_real_class_indices)

    sim_align_mask = (domain == 0) & known_mask
    real_align_mask = (domain == 1) & (trainable_in_real == 1) & known_mask
    align_mask = sim_align_mask | real_align_mask

    if align_mask.sum().item() <= 0:
        return domain_logits.new_tensor(0.0)

    # 若这一批次只有一个域，也不计算域对齐
    selected_domains = domain[align_mask]
    unique_domains = torch.unique(selected_domains)
    if unique_domains.numel() < 2:
        return domain_logits.new_tensor(0.0)

    return F.cross_entropy(domain_logits[align_mask], domain[align_mask])


def anomaly_boundary_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    prototypes: torch.Tensor,
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    anomaly_class_indices: Sequence[int] = (2, 4),
    class_weights: Optional[Any] = None,
    known_margin: float = 0.2,
    proto_margin: float = 0.2,
    eps: float = 1e-8,
) -> Dict[str, torch.Tensor]:
    """
    异常边界学习：只约束仿真域中的真实未知候选类，例如 ITSC / tuici。

    目标：
    1. 降低未知候选类样本落入真实已知类的最大概率。
    2. 让样本自身未知类 logit 高于最强已知类 logit 一个 margin。
    3. 让未知候选类特征到自身原型的距离小于到最近已知类原型的距离一个 margin。
    """
    logits = outputs["logits"]
    z_fault = outputs["z_fault"]
    y = batch["y"]
    domain = batch["domain"]

    ref_zero = logits.new_tensor(0.0)
    anomaly_indices = [int(i) for i in anomaly_class_indices]
    anomaly_mask = (domain == 0) & _build_known_class_mask(y, anomaly_indices)
    if anomaly_mask.sum().item() <= 0:
        return {
            "total": ref_zero,
            "open_space": ref_zero,
            "logit_margin": ref_zero,
            "proto_margin": ref_zero,
            "weight_mean": ref_zero,
        }

    known_indices = torch.as_tensor(
        [int(i) for i in known_real_class_indices],
        dtype=torch.long,
        device=logits.device,
    )

    selected_logits = logits[anomaly_mask]
    selected_features = z_fault[anomaly_mask]
    selected_labels = y[anomaly_mask]
    sample_weight = _build_distill_sample_weights(
        y=selected_labels,
        class_weights=class_weights,
        protected_class_indices=anomaly_class_indices,
        protected_weight=1.0,
    ).to(device=logits.device, dtype=logits.dtype)
    weight_denom = sample_weight.sum().clamp_min(eps)

    probs = F.softmax(selected_logits, dim=1)
    known_max_prob = probs.index_select(dim=1, index=known_indices).max(dim=1).values
    open_space_per_sample = -torch.log(1.0 - known_max_prob.clamp(max=1.0 - eps) + eps)
    open_space = (open_space_per_sample * sample_weight).sum() / weight_denom

    known_max_logit = selected_logits.index_select(dim=1, index=known_indices).max(dim=1).values
    own_anomaly_logits = selected_logits.gather(1, selected_labels.view(-1, 1)).squeeze(1)
    logit_margin_per_sample = F.relu(known_max_logit - own_anomaly_logits + float(known_margin))
    logit_margin_loss = (logit_margin_per_sample * sample_weight).sum() / weight_denom

    z_norm = F.normalize(selected_features, dim=1)
    p_norm = F.normalize(prototypes.to(device=z_fault.device, dtype=z_fault.dtype), dim=1)
    cosine_distance = 1.0 - torch.matmul(z_norm, p_norm.t())
    nearest_known_distance = cosine_distance.index_select(dim=1, index=known_indices).min(dim=1).values
    own_anomaly_distance = cosine_distance.gather(1, selected_labels.view(-1, 1)).squeeze(1)
    proto_margin_per_sample = F.relu(own_anomaly_distance - nearest_known_distance + float(proto_margin))
    proto_margin_loss = (proto_margin_per_sample * sample_weight).sum() / weight_denom

    total = open_space + logit_margin_loss + proto_margin_loss
    return {
        "total": total,
        "open_space": open_space,
        "logit_margin": logit_margin_loss,
        "proto_margin": proto_margin_loss,
        "weight_mean": sample_weight.mean(),
    }


def proxy_aligned_unknown_boundary_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    teacher_outputs: Optional[Dict[str, torch.Tensor]],
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    anomaly_class_indices: Sequence[int] = (2, 4),
    class_weights: Optional[Any] = None,
    known_mass_tolerance: float = 0.0,
    margin_tolerance: float = 0.0,
    known_mass_weight: float = 1.0,
    margin_weight: float = 1.0,
    eps: float = 1e-8,
) -> Dict[str, torch.Tensor]:
    """
    Keep sim ITSC/tuici boundary diagnostics from regressing relative to a teacher.

    This loss is aligned with the leakage-safe Stage2 proxy diagnostics:
    - penalize an increase in p(health)+p(OPF)+p(Sensor);
    - penalize a decrease in own_logit - max_known_logit.

    It only selects sim-domain samples whose labels are in anomaly_class_indices.
    Real ITSC/tuici are never selected because domain must be 0.
    """
    logits = outputs["logits"]
    ref_zero = logits.new_tensor(0.0)
    if teacher_outputs is None or teacher_outputs.get("logits", None) is None:
        return {
            "total": ref_zero,
            "known_mass_regression": ref_zero,
            "margin_regression": ref_zero,
            "student_known_mass": ref_zero,
            "teacher_known_mass": ref_zero,
            "student_margin": ref_zero,
            "teacher_margin": ref_zero,
            "weight_mean": ref_zero,
            "num_samples": ref_zero,
        }

    y = batch["y"]
    domain = batch["domain"]
    anomaly_mask = (domain == 0) & _build_known_class_mask(y, anomaly_class_indices)
    if anomaly_mask.sum().item() <= 0:
        return {
            "total": ref_zero,
            "known_mass_regression": ref_zero,
            "margin_regression": ref_zero,
            "student_known_mass": ref_zero,
            "teacher_known_mass": ref_zero,
            "student_margin": ref_zero,
            "teacher_margin": ref_zero,
            "weight_mean": ref_zero,
            "num_samples": ref_zero,
        }

    known_indices = torch.as_tensor(
        [int(i) for i in known_real_class_indices],
        dtype=torch.long,
        device=logits.device,
    )
    selected_logits = logits[anomaly_mask]
    selected_teacher_logits = teacher_outputs["logits"].detach()[anomaly_mask].to(
        device=logits.device,
        dtype=logits.dtype,
    )
    selected_labels = y[anomaly_mask]
    sample_weight = _build_distill_sample_weights(
        y=selected_labels,
        class_weights=class_weights,
        protected_class_indices=anomaly_class_indices,
        protected_weight=1.0,
    ).to(device=logits.device, dtype=logits.dtype)
    weight_denom = sample_weight.sum().clamp_min(eps)

    student_probs = F.softmax(selected_logits, dim=1)
    teacher_probs = F.softmax(selected_teacher_logits, dim=1)
    student_known_mass = student_probs.index_select(dim=1, index=known_indices).sum(dim=1)
    teacher_known_mass = teacher_probs.index_select(dim=1, index=known_indices).sum(dim=1)
    known_mass_regression_per_sample = F.relu(
        student_known_mass - teacher_known_mass - float(known_mass_tolerance)
    )
    known_mass_regression = (
        known_mass_regression_per_sample * sample_weight
    ).sum() / weight_denom

    student_known_max_logit = selected_logits.index_select(dim=1, index=known_indices).max(dim=1).values
    teacher_known_max_logit = selected_teacher_logits.index_select(dim=1, index=known_indices).max(dim=1).values
    student_own_logit = selected_logits.gather(1, selected_labels.view(-1, 1)).squeeze(1)
    teacher_own_logit = selected_teacher_logits.gather(1, selected_labels.view(-1, 1)).squeeze(1)
    student_margin = student_own_logit - student_known_max_logit
    teacher_margin = teacher_own_logit - teacher_known_max_logit
    margin_regression_per_sample = F.relu(
        teacher_margin - student_margin - float(margin_tolerance)
    )
    margin_regression = (margin_regression_per_sample * sample_weight).sum() / weight_denom

    total = (
        float(known_mass_weight) * known_mass_regression
        + float(margin_weight) * margin_regression
    )
    return {
        "total": total,
        "known_mass_regression": known_mass_regression,
        "margin_regression": margin_regression,
        "student_known_mass": (student_known_mass * sample_weight).sum() / weight_denom,
        "teacher_known_mass": (teacher_known_mass * sample_weight).sum() / weight_denom,
        "student_margin": (student_margin * sample_weight).sum() / weight_denom,
        "teacher_margin": (teacher_margin * sample_weight).sum() / weight_denom,
        "weight_mean": sample_weight.mean(),
        "num_samples": logits.new_tensor(float(selected_labels.numel())),
    }


def target_known_center_boundary_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    prototypes: torch.Tensor,
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    anomaly_class_indices: Sequence[int] = (2, 4),
    class_weights: Optional[Any] = None,
    margin: float = 0.2,
    eps: float = 1e-8,
) -> Dict[str, torch.Tensor]:
    """
    Keep sim-only unknown candidate classes away from real-known class centers.

    This loss uses only:
    - sim samples whose labels are in anomaly_class_indices, e.g. ITSC/tuici;
    - real samples whose labels are trainable known classes, e.g. health/OPF/Sensor.

    It never uses real ITSC/tuici for training. The constraint is:
        dist(sim_unknown, own_sim_prototype) + margin <=
        dist(sim_unknown, nearest_real_known_center)
    """
    z_fault = outputs["z_fault"]
    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]

    ref_zero = z_fault.new_tensor(0.0)
    anomaly_mask = (domain == 0) & _build_known_class_mask(y, anomaly_class_indices)
    if anomaly_mask.sum().item() <= 0:
        return {
            "total": ref_zero,
            "own_distance": ref_zero,
            "nearest_real_known_distance": ref_zero,
            "weight_mean": ref_zero,
        }

    real_centers = []
    for cls_idx in known_real_class_indices:
        real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx))
        if real_mask.sum().item() > 0:
            real_centers.append(z_fault[real_mask].mean(dim=0))

    if len(real_centers) <= 0:
        return {
            "total": ref_zero,
            "own_distance": ref_zero,
            "nearest_real_known_distance": ref_zero,
            "weight_mean": ref_zero,
        }

    selected_features = z_fault[anomaly_mask]
    selected_labels = y[anomaly_mask]
    sample_weight = _build_distill_sample_weights(
        y=selected_labels,
        class_weights=class_weights,
        protected_class_indices=anomaly_class_indices,
        protected_weight=1.0,
    ).to(device=z_fault.device, dtype=z_fault.dtype)
    weight_denom = sample_weight.sum().clamp_min(eps)

    z_norm = F.normalize(selected_features, dim=1)
    p_norm = F.normalize(prototypes.to(device=z_fault.device, dtype=z_fault.dtype), dim=1)
    own_proto = p_norm[selected_labels]
    own_distance = 1.0 - F.cosine_similarity(z_norm, own_proto, dim=1)

    real_centers_tensor = torch.stack(real_centers, dim=0).to(device=z_fault.device, dtype=z_fault.dtype)
    real_centers_norm = F.normalize(real_centers_tensor, dim=1)
    real_known_distance = 1.0 - torch.matmul(z_norm, real_centers_norm.t())
    nearest_real_known_distance = real_known_distance.min(dim=1).values

    margin_loss_per_sample = F.relu(
        own_distance - nearest_real_known_distance + float(margin)
    )
    total = (margin_loss_per_sample * sample_weight).sum() / weight_denom
    return {
        "total": total,
        "own_distance": (own_distance * sample_weight).sum() / weight_denom,
        "nearest_real_known_distance": (
            nearest_real_known_distance * sample_weight
        ).sum() / weight_denom,
        "weight_mean": sample_weight.mean(),
    }


def known_domain_shift_transfer_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    model: torch.nn.Module,
    prototypes: torch.Tensor,
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    anomaly_class_indices: Sequence[int] = (2, 4),
    class_weights: Optional[Any] = None,
    label_smoothing: float = 0.0,
    logit_weight: float = 1.0,
    proto_margin_weight: float = 1.0,
    proto_compact_weight: float = 0.2,
    margin: float = 0.2,
    detach_delta: bool = True,
    normalize_shifted: bool = True,
    condition_aware: bool = False,
    condition_temperature: float = 1.0,
    delta_scale: float = 1.0,
    use_delta_bank: bool = False,
    speed_bin_size: float = 100.0,
    load_bin_size: float = 0.5,
    min_samples_per_bin: int = 2,
    delta_bank_temperature: float = 1.0,
    use_load_in_condition: bool = True,
    proto_synthesis_weight: float = 0.0,
    proto_synthesis_delta_scale: Optional[float] = None,
    proto_synthesis_margin: float = 0.2,
    proto_synthesis_temperature: Optional[float] = None,
    proto_synthesis_detach_delta: bool = True,
    eps: float = 1e-8,
    lambda_map: Optional[float] = None,
    mapping_audit_path: Optional[str] = None,
) -> Dict[str, torch.Tensor]:
    """
    Transfer the known-class sim->real feature shift to sim-only unknown classes.

    This loss never uses real ITSC/tuici. It estimates a domain shift from known
    classes that exist in both domains, then applies that shift to sim ITSC/tuici
    features and keeps the shifted features class-discriminative.
    """
    z_fault = outputs["z_fault"]
    y = batch["y"]
    domain = batch["domain"]
    trainable_in_real = batch["trainable_in_real"]

    ref_zero = z_fault.new_tensor(0.0)
    anomaly_mask = (domain == 0) & _build_known_class_mask(y, anomaly_class_indices)
    if lambda_map is not None and anomaly_mask.any().item():
        selected_features = z_fault[anomaly_mask]
        per_sample_delta, delta_bank_size = estimate_shift(
            z_fault, batch, anomaly_mask, branch="time", lambda_map=lambda_map,
            speed_bin_size=speed_bin_size, load_bin_size=load_bin_size,
            min_samples_per_bin=min_samples_per_bin, use_load=use_load_in_condition,
            known_labels=known_real_class_indices, target_labels=anomaly_class_indices,
            detach_delta=detach_delta, temperature=delta_bank_temperature,
            eps=eps, audit_path=mapping_audit_path,
        )
        delta_bank_fallback = ref_zero
    else:
        deltas = []
        cond_centers = []
        has_condition = (
            condition_aware
            and "speed" in batch
            and "load" in batch
        )
        if has_condition:
            cond = torch.stack(
                [
                    batch["speed"].to(device=z_fault.device, dtype=z_fault.dtype).view(-1),
                    batch["load"].to(device=z_fault.device, dtype=z_fault.dtype).view(-1),
                ],
                dim=1,
            )
            cond_valid = ~torch.isnan(cond).any(dim=1)
        else:
            cond = None
            cond_valid = None

        for cls_idx in known_real_class_indices:
            sim_mask = (domain == 0) & (y == int(cls_idx))
            real_mask = (domain == 1) & (trainable_in_real == 1) & (y == int(cls_idx))
            if sim_mask.sum().item() > 0 and real_mask.sum().item() > 0:
                sim_center = z_fault[sim_mask].mean(dim=0)
                real_center = z_fault[real_mask].mean(dim=0)
                deltas.append(real_center - sim_center)
                if has_condition:
                    sim_cond_mask = sim_mask & cond_valid
                    real_cond_mask = real_mask & cond_valid
                    if sim_cond_mask.sum().item() > 0 and real_cond_mask.sum().item() > 0:
                        cond_centers.append(
                            0.5 * (
                                cond[sim_cond_mask].mean(dim=0)
                                + cond[real_cond_mask].mean(dim=0)
                            )
                        )
                    else:
                        cond_centers.append(None)

        if len(deltas) <= 0 or anomaly_mask.sum().item() <= 0:
            return {
                "total": ref_zero,
                "logit": ref_zero,
                "proto_margin": ref_zero,
                "proto_compact": ref_zero,
                "delta_norm": ref_zero,
                "raw_delta_norm": ref_zero,
                "scaled_delta_norm": ref_zero,
                "delta_bank_size": ref_zero,
                "delta_bank_fallback": ref_zero,
                "proto_synthesis": ref_zero,
                "proto_synthesis_ce": ref_zero,
                "proto_synthesis_margin": ref_zero,
                "proto_synthesis_num_classes": ref_zero,
                "weight_mean": ref_zero,
            }

        delta_bank = torch.stack(deltas, dim=0)
        global_delta = delta_bank.mean(dim=0, keepdim=True)
        selected_features = z_fault[anomaly_mask]
        delta_bank_size = ref_zero
        delta_bank_fallback = ref_zero
        per_sample_delta = None

        if use_delta_bank and "speed" in batch:
            speed = batch["speed"].to(device=z_fault.device, dtype=z_fault.dtype).view(-1)
            load = batch.get("load", None)
            if load is not None:
                load = load.to(device=z_fault.device, dtype=z_fault.dtype).view(-1)

            use_load = bool(use_load_in_condition) and load is not None
            if use_load:
                bank_cond = torch.stack([speed, load], dim=1)
                bank_cond_valid = ~torch.isnan(bank_cond).any(dim=1)
            else:
                bank_cond = speed.view(-1, 1)
                bank_cond_valid = ~torch.isnan(speed)

            speed_bin = torch.round(speed / max(float(speed_bin_size), eps)) * float(speed_bin_size)
            if use_load:
                load_bin = torch.round(load / max(float(load_bin_size), eps)) * float(load_bin_size)
            else:
                load_bin = None

            bank_deltas = []
            bank_centers = []

            for cls_idx in known_real_class_indices:
                sim_mask = (domain == 0) & (y == int(cls_idx)) & bank_cond_valid
                real_mask = (
                    (domain == 1)
                    & (trainable_in_real == 1)
                    & (y == int(cls_idx))
                    & bank_cond_valid
                )
                if sim_mask.sum().item() <= 0 or real_mask.sum().item() <= 0:
                    continue

                sim_bins = {}
                real_bins = {}
                for idx in torch.nonzero(sim_mask, as_tuple=False).view(-1).detach().cpu().tolist():
                    if use_load:
                        key = (
                            float(speed_bin[idx].detach().cpu().item()),
                            float(load_bin[idx].detach().cpu().item()),
                        )
                    else:
                        key = (float(speed_bin[idx].detach().cpu().item()),)
                    sim_bins.setdefault(key, []).append(int(idx))
                for idx in torch.nonzero(real_mask, as_tuple=False).view(-1).detach().cpu().tolist():
                    if use_load:
                        key = (
                            float(speed_bin[idx].detach().cpu().item()),
                            float(load_bin[idx].detach().cpu().item()),
                        )
                    else:
                        key = (float(speed_bin[idx].detach().cpu().item()),)
                    real_bins.setdefault(key, []).append(int(idx))

                for key in sorted(set(sim_bins).intersection(real_bins)):
                    sim_indices = sim_bins[key]
                    real_indices = real_bins[key]
                    if (
                        len(sim_indices) < int(min_samples_per_bin)
                        or len(real_indices) < int(min_samples_per_bin)
                    ):
                        continue
                    sim_idx_tensor = torch.as_tensor(sim_indices, dtype=torch.long, device=z_fault.device)
                    real_idx_tensor = torch.as_tensor(real_indices, dtype=torch.long, device=z_fault.device)
                    sim_center = z_fault.index_select(0, sim_idx_tensor).mean(dim=0)
                    real_center = z_fault.index_select(0, real_idx_tensor).mean(dim=0)
                    bank_deltas.append(real_center - sim_center)
                    bank_centers.append(
                        0.5
                        * (
                            bank_cond.index_select(0, sim_idx_tensor).mean(dim=0)
                            + bank_cond.index_select(0, real_idx_tensor).mean(dim=0)
                        )
                    )

            if len(bank_deltas) > 0:
                bank_delta_tensor = torch.stack(bank_deltas, dim=0)
                bank_center_tensor = torch.stack(bank_centers, dim=0)
                delta_bank_size = z_fault.new_tensor(float(len(bank_deltas)))

                selected_cond = bank_cond[anomaly_mask]
                valid_selected = bank_cond_valid[anomaly_mask]

                if valid_selected.sum().item() > 0:
                    norm_source = torch.cat([bank_center_tensor, selected_cond[valid_selected]], dim=0)
                    cond_mean = norm_source.mean(dim=0, keepdim=True)
                    cond_std = norm_source.std(dim=0, keepdim=True, unbiased=False).clamp_min(eps)
                    bank_norm = (bank_center_tensor - cond_mean) / cond_std
                    safe_selected_cond = torch.where(
                        valid_selected.view(-1, 1),
                        selected_cond,
                        cond_mean.expand_as(selected_cond),
                    )
                    selected_norm = (safe_selected_cond - cond_mean) / cond_std
                    dist_sq = torch.cdist(selected_norm, bank_norm, p=2).pow(2)
                    weights = torch.softmax(
                        -dist_sq / max(float(delta_bank_temperature), eps),
                        dim=1,
                    )
                    per_sample_delta = torch.matmul(weights, bank_delta_tensor)
                    per_sample_delta = torch.where(
                        valid_selected.view(-1, 1),
                        per_sample_delta,
                        global_delta.expand_as(per_sample_delta),
                    )
                    if (~valid_selected).any().item():
                        delta_bank_fallback = z_fault.new_tensor(1.0)
                else:
                    delta_bank_fallback = z_fault.new_tensor(1.0)
            else:
                delta_bank_fallback = z_fault.new_tensor(1.0)

        if per_sample_delta is None:
            if (
                has_condition
                and len(cond_centers) == len(deltas)
                and all(center is not None for center in cond_centers)
                and (cond_valid[anomaly_mask].sum().item() > 0)
            ):
                cond_bank = torch.stack([center for center in cond_centers if center is not None], dim=0)
                selected_cond = cond[anomaly_mask]
                valid_selected = cond_valid[anomaly_mask]

                norm_source = torch.cat([cond_bank, selected_cond[valid_selected]], dim=0)
                cond_mean = norm_source.mean(dim=0, keepdim=True)
                cond_std = norm_source.std(dim=0, keepdim=True, unbiased=False).clamp_min(eps)
                bank_norm = (cond_bank - cond_mean) / cond_std
                safe_selected_cond = torch.where(
                    valid_selected.view(-1, 1),
                    selected_cond,
                    cond_mean.expand_as(selected_cond),
                )
                selected_norm = (safe_selected_cond - cond_mean) / cond_std

                dist_sq = torch.cdist(selected_norm, bank_norm, p=2).pow(2)
                weights = torch.softmax(
                    -dist_sq / max(float(condition_temperature), eps),
                    dim=1,
                )
                per_sample_delta = torch.matmul(weights, delta_bank)
                per_sample_delta = torch.where(
                    valid_selected.view(-1, 1),
                    per_sample_delta,
                    global_delta.expand_as(per_sample_delta),
                )
            else:
                per_sample_delta = global_delta.expand(selected_features.size(0), -1)
            if use_delta_bank:
                delta_bank_fallback = z_fault.new_tensor(1.0)

    raw_delta_norm = per_sample_delta.norm(dim=1).mean()
    per_sample_delta = float(delta_scale) * per_sample_delta
    scaled_delta_norm = per_sample_delta.norm(dim=1).mean()
    delta_norm = scaled_delta_norm
    if detach_delta:
        per_sample_delta = per_sample_delta.detach()

    shifted_z = selected_features + per_sample_delta
    if normalize_shifted:
        shifted_z = F.normalize(shifted_z, dim=1)

    selected_labels = y[anomaly_mask]
    sample_weight = _build_distill_sample_weights(
        y=selected_labels,
        class_weights=class_weights,
        protected_class_indices=anomaly_class_indices,
        protected_weight=1.0,
    ).to(device=z_fault.device, dtype=z_fault.dtype)
    weight_denom = sample_weight.sum().clamp_min(eps)

    fc_classifier = getattr(model, "fc_classifier", None)
    prototype_classifier = getattr(model, "prototype_classifier", None)
    if fc_classifier is None or prototype_classifier is None:
        return {
            "total": ref_zero,
            "logit": ref_zero,
            "proto_margin": ref_zero,
            "proto_compact": ref_zero,
            "delta_norm": delta_norm,
            "raw_delta_norm": raw_delta_norm,
            "scaled_delta_norm": scaled_delta_norm,
            "delta_bank_size": delta_bank_size,
            "delta_bank_fallback": delta_bank_fallback,
            "proto_synthesis": ref_zero,
            "proto_synthesis_ce": ref_zero,
            "proto_synthesis_margin": ref_zero,
            "proto_synthesis_num_classes": ref_zero,
            "weight_mean": sample_weight.mean(),
        }

    fc_logits = fc_classifier(shifted_z)
    proto_logits = prototype_classifier(shifted_z)
    proto_alpha = float(getattr(model, "proto_alpha", 0.0))
    shifted_logits = proto_alpha * proto_logits + (1.0 - proto_alpha) * fc_logits

    logit_per_sample = F.cross_entropy(
        shifted_logits,
        selected_labels,
        reduction="none",
        label_smoothing=float(label_smoothing),
    )
    logit_loss = (logit_per_sample * sample_weight).sum() / weight_denom

    p_norm = F.normalize(prototypes.to(device=z_fault.device, dtype=z_fault.dtype), dim=1)
    shifted_norm = F.normalize(shifted_z, dim=1)
    cosine_distance = 1.0 - torch.matmul(shifted_norm, p_norm.t())

    own_distance = cosine_distance.gather(1, selected_labels.view(-1, 1)).squeeze(1)
    known_indices = torch.as_tensor(
        [int(i) for i in known_real_class_indices],
        dtype=torch.long,
        device=z_fault.device,
    )
    nearest_known_distance = cosine_distance.index_select(dim=1, index=known_indices).min(dim=1).values
    proto_margin_per_sample = F.relu(own_distance - nearest_known_distance + float(margin))

    proto_margin_loss = (proto_margin_per_sample * sample_weight).sum() / weight_denom
    proto_compact_loss = (own_distance * sample_weight).sum() / weight_denom
    proto_synthesis_loss = ref_zero
    proto_synthesis_ce = ref_zero
    proto_synthesis_margin_loss = ref_zero
    proto_synthesis_num_classes = ref_zero

    if float(proto_synthesis_weight) != 0.0:
        synth_p = p_norm.clone()
        delta_for_proto = per_sample_delta
        if proto_synthesis_detach_delta:
            delta_for_proto = delta_for_proto.detach()
        prototype_delta_scale = (
            float(delta_scale)
            if proto_synthesis_delta_scale is None
            else float(proto_synthesis_delta_scale)
        )

        synth_count = 0
        for cls_idx in anomaly_class_indices:
            cls_idx = int(cls_idx)
            cls_mask = selected_labels == cls_idx
            if cls_mask.sum().item() <= 0:
                continue
            class_delta = delta_for_proto[cls_mask].mean(dim=0)
            synth_p[cls_idx] = F.normalize(
                p_norm[cls_idx] + prototype_delta_scale * class_delta,
                dim=0,
            )
            synth_count += 1

        if synth_count > 0:
            synth_temperature = proto_synthesis_temperature
            if synth_temperature is None:
                synth_temperature = getattr(prototype_classifier, "temperature", 0.1)
            synth_temperature = max(float(synth_temperature), eps)

            z_shift_norm = F.normalize(shifted_z, dim=1)
            logits_synth_proto = torch.matmul(z_shift_norm, synth_p.t()) / synth_temperature
            proto_synthesis_ce_per_sample = F.cross_entropy(
                logits_synth_proto,
                selected_labels,
                reduction="none",
                label_smoothing=float(label_smoothing),
            )
            proto_synthesis_ce = (
                proto_synthesis_ce_per_sample * sample_weight
            ).sum() / weight_denom

            synth_distance = 1.0 - torch.matmul(z_shift_norm, synth_p.t())
            own_synth_distance = synth_distance.gather(
                1,
                selected_labels.view(-1, 1),
            ).squeeze(1)
            nearest_synth_known_distance = synth_distance.index_select(
                dim=1,
                index=known_indices,
            ).min(dim=1).values
            proto_synthesis_margin_per_sample = F.relu(
                own_synth_distance
                - nearest_synth_known_distance
                + float(proto_synthesis_margin)
            )
            proto_synthesis_margin_loss = (
                proto_synthesis_margin_per_sample * sample_weight
            ).sum() / weight_denom
            proto_synthesis_loss = proto_synthesis_ce + proto_synthesis_margin_loss
            proto_synthesis_num_classes = z_fault.new_tensor(float(synth_count))

    total = (
        float(logit_weight) * logit_loss
        + float(proto_margin_weight) * proto_margin_loss
        + float(proto_compact_weight) * proto_compact_loss
        + float(proto_synthesis_weight) * proto_synthesis_loss
    )

    return {
        "total": total,
        "logit": logit_loss,
        "proto_margin": proto_margin_loss,
        "proto_compact": proto_compact_loss,
        "delta_norm": delta_norm,
        "raw_delta_norm": raw_delta_norm,
        "scaled_delta_norm": scaled_delta_norm,
        "delta_bank_size": delta_bank_size,
        "delta_bank_fallback": delta_bank_fallback,
        "proto_synthesis": proto_synthesis_loss,
        "proto_synthesis_ce": proto_synthesis_ce,
        "proto_synthesis_margin": proto_synthesis_margin_loss,
        "proto_synthesis_num_classes": proto_synthesis_num_classes,
        "weight_mean": sample_weight.mean(),
    }



def distillation_loss(
    outputs: Dict[str, torch.Tensor],
    teacher_outputs: Optional[Dict[str, torch.Tensor]],
    batch: Dict[str, Any],
    temperature: float = 2.0,
    logit_weight: float = 1.0,
    feature_weight: float = 1.0,
    protected_class_indices: Sequence[int] = (4,),
    class_weights: Optional[Any] = None,
    protected_weight: float = 2.0,
) -> Dict[str, torch.Tensor]:
    """
    teacher-student 蒸馏损失
    重点保护仿真域完整故障知识，当前五分类设置中特别保护 tuici 边界

    蒸馏仅在仿真域样本上进行，原因：
    - teacher 是 Stage1 仿真预训练得到的完整故障知识
    - 在 Stage2 / Stage3 中主要保护仿真知识不被真实 4 类迁移破坏

    返回:
        {
          "total": ...,
          "logit_kd": ...,
          "feature_kd": ...
        }
    """
    if teacher_outputs is None:
        zero = _zero_like_reference(outputs)
        return {
            "total": zero,
            "logit_kd": zero,
            "feature_kd": zero,
            "weight_mean": zero,
        }

    student_logits = outputs["logits"]                  # [B, K]
    teacher_logits = teacher_outputs["logits"].detach() # [B, K]
    student_feat = outputs["z_fault"]                   # [B, D]
    teacher_feat = teacher_outputs["z_fault"].detach()  # [B, D]

    y = batch["y"]
    domain = batch["domain"]

    sim_mask = (domain == 0)
    if sim_mask.sum().item() <= 0:
        zero = student_logits.new_tensor(0.0)
        return {
            "total": zero,
            "logit_kd": zero,
            "feature_kd": zero,
            "weight_mean": zero,
        }

    # 额外加权保护 tuici
    weight = _build_distill_sample_weights(
        y=y,
        class_weights=class_weights,
        protected_class_indices=protected_class_indices,
        protected_weight=protected_weight,
    )

    weight = weight[sim_mask]   # [Ns]

    # 1) logits 蒸馏
    s_log_prob = F.log_softmax(student_logits[sim_mask] / temperature, dim=1)
    t_prob = F.softmax(teacher_logits[sim_mask] / temperature, dim=1)

    # KLDiv 默认输出 [Ns, K]，这里转为逐样本损失
    kl_per_sample = F.kl_div(s_log_prob, t_prob, reduction="none").sum(dim=1)
    logit_kd = ((temperature ** 2) * kl_per_sample * weight).sum() / (weight.sum() + 1e-12)

    # 2) feature 蒸馏
    feat_diff = ((student_feat[sim_mask] - teacher_feat[sim_mask]) ** 2).mean(dim=1)
    feature_kd = (feat_diff * weight).sum() / (weight.sum() + 1e-12)

    total = logit_weight * logit_kd + feature_weight * feature_kd
    return {
        "total": total,
        "logit_kd": logit_kd,
        "feature_kd": feature_kd,
        "weight_mean": weight.mean(),
    }


def separation_loss(
    outputs: Dict[str, torch.Tensor],
    sep_type: str = "cosine"
) -> torch.Tensor:
    """Fault/condition disentanglement has been removed; keep L_sep as a no-op."""
    return outputs["z_fault"].new_tensor(0.0)


def total_loss(
    outputs: Dict[str, torch.Tensor],
    batch: Dict[str, Any],
    model: Optional[torch.nn.Module],
    loss_cfg: Dict[str, Any],
    teacher_outputs: Optional[Dict[str, torch.Tensor]] = None,
    known_real_class_indices: Sequence[int] = (0, 1, 3),
    anomaly_class_indices: Sequence[int] = (2, 4),
) -> Dict[str, torch.Tensor]:
    """
    统一总损失聚合接口

    返回:
        {
          "total": ...,
          "L_sim_cls": ...,
          "L_real_cls": ...,
          "L_proto": ...,
          "L_domain": ...,
          "L_distill": ...,
          "L_sep": ...,
          ...
        }
    """
    lambda_coral = float(loss_cfg.get("lambda_coral", 0.0))
    coral_mean_weight = float(loss_cfg.get("coral_mean_weight", 1.0))
    coral_cov_weight = float(loss_cfg.get("coral_cov_weight", 1.0))
    label_smoothing = float(loss_cfg.get("label_smoothing", 0.0))
    lambda_real = float(loss_cfg.get("lambda_real", 1.0))
    lambda_proto = float(loss_cfg.get("lambda_proto", 0.5))
    lambda_domain = float(loss_cfg.get("lambda_domain", 0.2))
    lambda_domain_global = float(loss_cfg.get("lambda_domain_global", 0.0))
    lambda_distill = float(loss_cfg.get("lambda_distill", 0.5))
    lambda_sep = float(loss_cfg.get("lambda_sep", 0.1))
    lambda_anomaly = float(loss_cfg.get("lambda_anomaly", 0.0))
    lambda_target_boundary = float(loss_cfg.get("lambda_target_boundary", 0.0))
    lambda_unknown_shift = float(loss_cfg.get("lambda_unknown_shift", 0.0))
    lambda_proxy_boundary = float(loss_cfg.get("lambda_proxy_boundary", 0.0))
    lambda_time_aux = float(loss_cfg.get("lambda_time_aux", 0.3))
    lambda_freq_aux = float(loss_cfg.get("lambda_freq_aux", 0.3))
    lambda_alpha_prior = float(loss_cfg.get("lambda_alpha_prior", 0.01))
    lambda_freq_order_coral = float(loss_cfg.get("lambda_freq_order_coral", 0.0))
    freq_order_coral_feature_key = str(loss_cfg.get("freq_order_coral_feature_key", "freq_order_features"))
    freq_order_coral_mean_weight = float(loss_cfg.get("freq_order_coral_mean_weight", 1.0))
    freq_order_coral_cov_weight = float(loss_cfg.get("freq_order_coral_cov_weight", 0.5))
    freq_order_coral_condition_wise = bool(loss_cfg.get("freq_order_coral_condition_wise", True))
    freq_order_coral_speed_bin_size = float(loss_cfg.get("freq_order_coral_speed_bin_size", 100.0))
    freq_order_coral_load_bin_size = float(loss_cfg.get("freq_order_coral_load_bin_size", 0.5))
    freq_order_coral_min_samples_per_bin = int(loss_cfg.get("freq_order_coral_min_samples_per_bin", 2))
    freq_order_coral_use_load_in_condition = bool(loss_cfg.get("freq_order_coral_use_load_in_condition", True))
    lambda_freq_unknown_shift = float(loss_cfg.get("lambda_freq_unknown_shift", 0.0))
    freq_unknown_shift_feature_key = str(loss_cfg.get("freq_unknown_shift_feature_key", "freq_vec"))
    freq_unknown_shift_delta_scale = float(loss_cfg.get("freq_unknown_shift_delta_scale", 0.5))
    freq_unknown_shift_speed_bin_size = float(loss_cfg.get("freq_unknown_shift_speed_bin_size", 100.0))
    freq_unknown_shift_load_bin_size = float(loss_cfg.get("freq_unknown_shift_load_bin_size", 0.5))
    freq_unknown_shift_min_samples_per_bin = int(loss_cfg.get("freq_unknown_shift_min_samples_per_bin", 2))
    freq_unknown_shift_delta_bank_temperature = float(loss_cfg.get("freq_unknown_shift_delta_bank_temperature", 1.0))
    freq_unknown_shift_use_load_in_condition = bool(loss_cfg.get("freq_unknown_shift_use_load_in_condition", True))
    freq_unknown_shift_margin = float(loss_cfg.get("freq_unknown_shift_margin", 0.25))
    freq_unknown_shift_logit_weight = float(loss_cfg.get("freq_unknown_shift_logit_weight", 1.0))
    freq_unknown_shift_boundary_weight = float(loss_cfg.get("freq_unknown_shift_boundary_weight", 1.0))
    freq_unknown_shift_compact_weight = float(loss_cfg.get("freq_unknown_shift_compact_weight", 0.1))
    freq_unknown_shift_detach_delta = bool(loss_cfg.get("freq_unknown_shift_detach_delta", True))
    freq_unknown_shift_class_weights = loss_cfg.get(
        "freq_unknown_shift_class_weights",
        loss_cfg.get("unknown_shift_class_weights", None),
    )
    anomaly_known_margin = float(loss_cfg.get("anomaly_known_margin", 0.2))
    anomaly_proto_margin = float(loss_cfg.get("anomaly_proto_margin", 0.2))
    anomaly_class_weights = loss_cfg.get("anomaly_class_weights", None)
    target_boundary_margin = float(loss_cfg.get("target_boundary_margin", 0.2))
    target_boundary_class_weights = loss_cfg.get("target_boundary_class_weights", anomaly_class_weights)
    proxy_boundary_class_weights = loss_cfg.get("proxy_boundary_class_weights", anomaly_class_weights)
    proxy_boundary_known_mass_tolerance = float(loss_cfg.get("proxy_boundary_known_mass_tolerance", 0.0))
    proxy_boundary_margin_tolerance = float(loss_cfg.get("proxy_boundary_margin_tolerance", 0.0))
    proxy_boundary_known_mass_weight = float(loss_cfg.get("proxy_boundary_known_mass_weight", 1.0))
    proxy_boundary_margin_weight = float(loss_cfg.get("proxy_boundary_margin_weight", 1.0))
    unknown_shift_margin = float(loss_cfg.get("unknown_shift_margin", 0.2))
    unknown_shift_class_weights = loss_cfg.get("unknown_shift_class_weights", anomaly_class_weights)
    unknown_shift_logit_weight = float(loss_cfg.get("unknown_shift_logit_weight", 1.0))
    unknown_shift_proto_margin_weight = float(loss_cfg.get("unknown_shift_proto_margin_weight", 1.0))
    unknown_shift_proto_compact_weight = float(loss_cfg.get("unknown_shift_proto_compact_weight", 0.2))
    unknown_shift_detach_delta = bool(loss_cfg.get("unknown_shift_detach_delta", True))
    unknown_shift_condition_aware = bool(loss_cfg.get("unknown_shift_condition_aware", False))
    unknown_shift_condition_temperature = float(loss_cfg.get("unknown_shift_condition_temperature", 1.0))
    unknown_shift_delta_scale = float(loss_cfg.get("unknown_shift_delta_scale", 1.0))
    unknown_shift_use_delta_bank = bool(loss_cfg.get("unknown_shift_use_delta_bank", False))
    unknown_shift_speed_bin_size = float(loss_cfg.get("unknown_shift_speed_bin_size", 100.0))
    unknown_shift_load_bin_size = float(loss_cfg.get("unknown_shift_load_bin_size", 0.5))
    unknown_shift_min_samples_per_bin = int(loss_cfg.get("unknown_shift_min_samples_per_bin", 2))
    unknown_shift_delta_bank_temperature = float(loss_cfg.get("unknown_shift_delta_bank_temperature", 1.0))
    unknown_shift_use_load_in_condition = bool(loss_cfg.get("unknown_shift_use_load_in_condition", True))
    unknown_proto_synthesis_weight = float(loss_cfg.get("unknown_proto_synthesis_weight", 0.0))
    unknown_proto_synthesis_delta_scale = loss_cfg.get("unknown_proto_synthesis_delta_scale", None)
    if unknown_proto_synthesis_delta_scale is not None:
        unknown_proto_synthesis_delta_scale = float(unknown_proto_synthesis_delta_scale)
    unknown_proto_synthesis_margin = float(loss_cfg.get("unknown_proto_synthesis_margin", 0.2))
    unknown_proto_synthesis_temperature = loss_cfg.get("unknown_proto_synthesis_temperature", None)
    if unknown_proto_synthesis_temperature is not None:
        unknown_proto_synthesis_temperature = float(unknown_proto_synthesis_temperature)
    unknown_proto_synthesis_detach_delta = bool(loss_cfg.get("unknown_proto_synthesis_detach_delta", True))

    distill_temperature = float(loss_cfg.get("distill_temperature", 2.0))
    distill_feature_weight = float(loss_cfg.get("distill_feature_weight", 1.0))
    distill_logit_weight = float(loss_cfg.get("distill_logit_weight", 1.0))
    distill_class_weights = loss_cfg.get("distill_class_weights", None)
    distill_protected_weight = float(loss_cfg.get("distill_protected_weight", 2.0))

    proto_margin = float(loss_cfg.get("proto_margin", 1.0))
    sep_type = str(loss_cfg.get("sep_type", "cosine"))

    if model is None:
        raise ValueError("total_loss 需要传入 model，以便读取 prototype_classifier.prototypes")

    # 1) 分类损失
    L_sim_cls = sim_classification_loss(
        outputs=outputs,
        batch=batch,
        label_smoothing=label_smoothing,
        logit_key="logits",
    )

    L_real_cls = real_classification_loss(
        outputs=outputs,
        batch=batch,
        label_smoothing=label_smoothing,
        logit_key="logits",
    )

    L_sim_time_cls = sim_classification_loss(
        outputs=outputs,
        batch=batch,
        label_smoothing=label_smoothing,
        logit_key="logits_time",
    )
    L_real_time_cls = real_classification_loss(
        outputs=outputs,
        batch=batch,
        label_smoothing=label_smoothing,
        logit_key="logits_time",
    )
    L_time_aux = L_sim_time_cls + lambda_real * L_real_time_cls

    L_sim_freq_cls = sim_classification_loss(
        outputs=outputs,
        batch=batch,
        label_smoothing=label_smoothing,
        logit_key="logits_freq",
    )
    L_real_freq_cls = real_classification_loss(
        outputs=outputs,
        batch=batch,
        label_smoothing=label_smoothing,
        logit_key="logits_freq",
    )
    L_freq_aux = L_sim_freq_cls + lambda_real * L_real_freq_cls

    L_alpha = alpha_prior_loss(outputs)

    # 2) 原型损失
    proto_metric = getattr(model.prototype_classifier, "metric", "cosine")
    proto_dict = prototype_loss(
        outputs=outputs,
        batch=batch,
        prototypes=model.prototype_classifier.prototypes,
        proto_margin=proto_margin,
        known_real_class_indices=known_real_class_indices,
        metric=proto_metric,
    )
    L_proto = proto_dict["total"]

    # 3) 域对齐损失
    L_domain = conditional_domain_loss(
        outputs=outputs,
        batch=batch,
        known_real_class_indices=known_real_class_indices
    )
    L_domain_global = global_domain_loss(
        outputs=outputs,
        batch=batch,
        known_real_class_indices=known_real_class_indices
    )
    L_coral = classwise_coral_loss(
        outputs=outputs,
        batch=batch,
        known_real_class_indices=known_real_class_indices,
        mean_weight=coral_mean_weight,
        cov_weight=coral_cov_weight,
    )
    freq_coral_dict = classwise_frequency_coral_loss(
        outputs=outputs,
        batch=batch,
        known_real_class_indices=known_real_class_indices,
        feature_key=freq_order_coral_feature_key,
        mean_weight=freq_order_coral_mean_weight,
        cov_weight=freq_order_coral_cov_weight,
        condition_wise=freq_order_coral_condition_wise,
        speed_bin_size=freq_order_coral_speed_bin_size,
        load_bin_size=freq_order_coral_load_bin_size,
        min_samples_per_bin=freq_order_coral_min_samples_per_bin,
        use_load_in_condition=freq_order_coral_use_load_in_condition,
    )
    L_freq_order_coral = freq_coral_dict["total"]

    anomaly_dict = anomaly_boundary_loss(
        outputs=outputs,
        batch=batch,
        prototypes=model.prototype_classifier.prototypes,
        known_real_class_indices=known_real_class_indices,
        anomaly_class_indices=anomaly_class_indices,
        class_weights=anomaly_class_weights,
        known_margin=anomaly_known_margin,
        proto_margin=anomaly_proto_margin,
    )
    L_anomaly = anomaly_dict["total"]

    target_boundary_dict = target_known_center_boundary_loss(
        outputs=outputs,
        batch=batch,
        prototypes=model.prototype_classifier.prototypes,
        known_real_class_indices=known_real_class_indices,
        anomaly_class_indices=anomaly_class_indices,
        class_weights=target_boundary_class_weights,
        margin=target_boundary_margin,
    )
    L_target_boundary = target_boundary_dict["total"]

    proxy_boundary_dict = proxy_aligned_unknown_boundary_loss(
        outputs=outputs,
        batch=batch,
        teacher_outputs=teacher_outputs,
        known_real_class_indices=known_real_class_indices,
        anomaly_class_indices=anomaly_class_indices,
        class_weights=proxy_boundary_class_weights,
        known_mass_tolerance=proxy_boundary_known_mass_tolerance,
        margin_tolerance=proxy_boundary_margin_tolerance,
        known_mass_weight=proxy_boundary_known_mass_weight,
        margin_weight=proxy_boundary_margin_weight,
    )
    L_proxy_boundary = proxy_boundary_dict["total"]

    unknown_shift_dict = known_domain_shift_transfer_loss(
        outputs=outputs,
        batch=batch,
        model=model,
        prototypes=model.prototype_classifier.prototypes,
        known_real_class_indices=known_real_class_indices,
        anomaly_class_indices=anomaly_class_indices,
        class_weights=unknown_shift_class_weights,
        label_smoothing=label_smoothing,
        logit_weight=unknown_shift_logit_weight,
        proto_margin_weight=unknown_shift_proto_margin_weight,
        proto_compact_weight=unknown_shift_proto_compact_weight,
        margin=unknown_shift_margin,
        detach_delta=unknown_shift_detach_delta,
        condition_aware=unknown_shift_condition_aware,
        condition_temperature=unknown_shift_condition_temperature,
        delta_scale=unknown_shift_delta_scale,
        use_delta_bank=unknown_shift_use_delta_bank,
        speed_bin_size=unknown_shift_speed_bin_size,
        load_bin_size=unknown_shift_load_bin_size,
        min_samples_per_bin=unknown_shift_min_samples_per_bin,
        delta_bank_temperature=unknown_shift_delta_bank_temperature,
        use_load_in_condition=unknown_shift_use_load_in_condition,
        lambda_map=loss_cfg.get("lambda_map"),
        mapping_audit_path=loss_cfg.get("local_mapping_audit_path"),
        proto_synthesis_weight=unknown_proto_synthesis_weight,
        proto_synthesis_delta_scale=unknown_proto_synthesis_delta_scale,
        proto_synthesis_margin=unknown_proto_synthesis_margin,
        proto_synthesis_temperature=unknown_proto_synthesis_temperature,
        proto_synthesis_detach_delta=unknown_proto_synthesis_detach_delta,
    )
    L_unknown_shift = unknown_shift_dict["total"]
    freq_unknown_shift_dict = frequency_unknown_shift_transfer_loss(
        outputs=outputs,
        batch=batch,
        model=model,
        known_real_class_indices=known_real_class_indices,
        anomaly_class_indices=anomaly_class_indices,
        class_weights=freq_unknown_shift_class_weights,
        feature_key=freq_unknown_shift_feature_key,
        delta_scale=freq_unknown_shift_delta_scale,
        speed_bin_size=freq_unknown_shift_speed_bin_size,
        load_bin_size=freq_unknown_shift_load_bin_size,
        min_samples_per_bin=freq_unknown_shift_min_samples_per_bin,
        delta_bank_temperature=freq_unknown_shift_delta_bank_temperature,
        use_load_in_condition=freq_unknown_shift_use_load_in_condition,
        lambda_map=loss_cfg.get("lambda_map"),
        mapping_audit_path=loss_cfg.get("local_mapping_audit_path"),
        label_smoothing=label_smoothing,
        margin=freq_unknown_shift_margin,
        logit_weight=freq_unknown_shift_logit_weight,
        boundary_weight=freq_unknown_shift_boundary_weight,
        compact_weight=freq_unknown_shift_compact_weight,
        detach_delta=freq_unknown_shift_detach_delta,
    )
    L_freq_unknown_shift = freq_unknown_shift_dict["total"]

    # 4) 蒸馏损失
    distill_dict = distillation_loss(
        outputs=outputs,
        teacher_outputs=teacher_outputs,
        batch=batch,
        temperature=distill_temperature,
        logit_weight=distill_logit_weight,
        feature_weight=distill_feature_weight,
        protected_class_indices=anomaly_class_indices,
        class_weights=distill_class_weights,
        protected_weight=distill_protected_weight,
    )
    L_distill = distill_dict["total"]

    # 5) 分离损失：故障/工况解耦已移除，保留 L_sep 为兼容性 no-op
    L_sep = separation_loss(outputs=outputs, sep_type=sep_type)

    total = (
        L_sim_cls
        + lambda_real * L_real_cls
        + lambda_time_aux * L_time_aux
        + lambda_freq_aux * L_freq_aux
        + lambda_alpha_prior * L_alpha
        + lambda_proto * L_proto
        + lambda_domain * L_domain
        + lambda_domain_global * L_domain_global
        + lambda_distill * L_distill
        + lambda_sep * L_sep
        + lambda_anomaly * L_anomaly
        + lambda_target_boundary * L_target_boundary
        + lambda_proxy_boundary * L_proxy_boundary
        + lambda_unknown_shift * L_unknown_shift
        + lambda_coral * L_coral
        + lambda_freq_order_coral * L_freq_order_coral
        + lambda_freq_unknown_shift * L_freq_unknown_shift
    )

    return {
        "total": total,
        "L_coral": L_coral,
        "L_freq_order_coral": L_freq_order_coral,
        "L_freq_unknown_shift": L_freq_unknown_shift,
        "L_sim_cls": L_sim_cls,
        "L_real_cls": L_real_cls,
        "L_time_aux": L_time_aux,
        "L_freq_aux": L_freq_aux,
        "L_alpha": L_alpha,
        "L_sim_time_cls": L_sim_time_cls,
        "L_real_time_cls": L_real_time_cls,
        "L_sim_freq_cls": L_sim_freq_cls,
        "L_real_freq_cls": L_real_freq_cls,
        "L_proto": L_proto,
        "L_domain": L_domain,
        "L_domain_global": L_domain_global,
        "L_distill": L_distill,
        "L_sep": L_sep,
        "L_anomaly": L_anomaly,
        "L_target_boundary": L_target_boundary,
        "L_proxy_boundary": L_proxy_boundary,
        "L_unknown_shift": L_unknown_shift,

        # 额外展开的诊断项，便于日志观察
        "proto_compact": proto_dict["compact"],
        "proto_cross_domain_pull": proto_dict["cross_domain_pull"],
        "proto_inter_separation": proto_dict["inter_separation"],
        "distill_logit_kd": distill_dict["logit_kd"],
        "distill_feature_kd": distill_dict["feature_kd"],
        "distill_weight_mean": distill_dict["weight_mean"],
        "anomaly_open_space": anomaly_dict["open_space"],
        "anomaly_logit_margin": anomaly_dict["logit_margin"],
        "anomaly_proto_margin": anomaly_dict["proto_margin"],
        "anomaly_weight_mean": anomaly_dict["weight_mean"],
        "target_boundary_own_distance": target_boundary_dict["own_distance"],
        "target_boundary_nearest_real_known_distance": target_boundary_dict["nearest_real_known_distance"],
        "target_boundary_weight_mean": target_boundary_dict["weight_mean"],
        "proxy_boundary_known_mass_regression": proxy_boundary_dict["known_mass_regression"],
        "proxy_boundary_margin_regression": proxy_boundary_dict["margin_regression"],
        "proxy_boundary_student_known_mass": proxy_boundary_dict["student_known_mass"],
        "proxy_boundary_teacher_known_mass": proxy_boundary_dict["teacher_known_mass"],
        "proxy_boundary_student_margin": proxy_boundary_dict["student_margin"],
        "proxy_boundary_teacher_margin": proxy_boundary_dict["teacher_margin"],
        "proxy_boundary_weight_mean": proxy_boundary_dict["weight_mean"],
        "proxy_boundary_num_samples": proxy_boundary_dict["num_samples"],
        "unknown_shift_logit": unknown_shift_dict["logit"],
        "unknown_shift_proto_margin": unknown_shift_dict["proto_margin"],
        "unknown_shift_proto_compact": unknown_shift_dict["proto_compact"],
        "unknown_shift_delta_norm": unknown_shift_dict["delta_norm"],
        "unknown_shift_raw_delta_norm": unknown_shift_dict["raw_delta_norm"],
        "unknown_shift_scaled_delta_norm": unknown_shift_dict["scaled_delta_norm"],
        "unknown_shift_delta_bank_size": unknown_shift_dict["delta_bank_size"],
        "unknown_shift_delta_bank_fallback": unknown_shift_dict["delta_bank_fallback"],
        "L_unknown_proto_synthesis": unknown_shift_dict["proto_synthesis"],
        "unknown_proto_synthesis_ce": unknown_shift_dict["proto_synthesis_ce"],
        "unknown_proto_synthesis_margin": unknown_shift_dict["proto_synthesis_margin"],
        "unknown_proto_synthesis_num_classes": unknown_shift_dict["proto_synthesis_num_classes"],
        "unknown_shift_weight_mean": unknown_shift_dict["weight_mean"],
        "freq_order_coral_mean": freq_coral_dict["mean"],
        "freq_order_coral_cov": freq_coral_dict["cov"],
        "freq_order_coral_num_groups": freq_coral_dict["num_groups"],
        "freq_unknown_shift_ce": freq_unknown_shift_dict["ce"],
        "freq_unknown_shift_boundary": freq_unknown_shift_dict["boundary"],
        "freq_unknown_shift_compact": freq_unknown_shift_dict["compact"],
        "freq_unknown_shift_delta_norm": freq_unknown_shift_dict["delta_norm"],
        "freq_unknown_shift_raw_delta_norm": freq_unknown_shift_dict["raw_delta_norm"],
        "freq_unknown_shift_scaled_delta_norm": freq_unknown_shift_dict["scaled_delta_norm"],
        "freq_unknown_shift_delta_bank_size": freq_unknown_shift_dict["delta_bank_size"],
        "freq_unknown_shift_delta_bank_fallback": freq_unknown_shift_dict["delta_bank_fallback"],
    }
