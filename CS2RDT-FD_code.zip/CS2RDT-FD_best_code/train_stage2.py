"""Train the selected CS2RDT-FD Stage 2 model from a Stage 1 teacher."""

import argparse
from pathlib import Path

from stage2_data import build_formal
from trainer import Stage2Trainer
from utils import (
    build_model, build_optimizer, get_device, get_or_create_split_records,
    load_config, load_model_weights, save_json, save_scaler, set_random_seed, setup_logger,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config.yaml"))
    parser.add_argument("--teacher", type=Path, help="Stage 1 checkpoint")
    parser.add_argument("--data-root", type=Path)
    parser.add_argument("--cache-dir", type=Path)
    args = parser.parse_args()

    config = load_config(args.config)
    paths = config["paths"]
    if args.data_root is not None:
        paths["data_root"] = str(args.data_root)
    if args.cache_dir is not None:
        config["data"]["cache_dir"] = str(args.cache_dir)
    train = config["train"]
    stage = train["stage2"]
    if args.teacher is not None:
        stage["teacher_ckpt"] = str(args.teacher)
    teacher_path = Path(stage["teacher_ckpt"])
    if not teacher_path.is_file():
        raise FileNotFoundError(f"Stage 1 teacher checkpoint required: {teacher_path}")

    logger = setup_logger("train_stage2", paths["log_dir"], level=config["logging"]["level"])
    split = get_or_create_split_records(config, logger)["split_records"]
    set_random_seed(config["random_seed"])
    device = get_device(config)
    views = build_formal(config, split, logger)

    student = build_model(config).to(device)
    teacher = build_model(config).to(device)
    load_model_weights(student, teacher_path, strict=True)
    load_model_weights(teacher, teacher_path, strict=True)
    checkpoint_dir = Path(paths["checkpoint_dir"])
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    save_scaler(views["scaler"], str(checkpoint_dir / "scaler_stage2.json"))

    optimizer = build_optimizer(student, stage["lr"], train["weight_decay"])
    trainer = Stage2Trainer(
        student, optimizer, views["train_loader"], views["val_loader"], device, config,
        logger, str(checkpoint_dir), teacher_model=teacher,
    )
    # The trainer ranks epochs by validation accuracy, then recalls and loss.
    result = trainer.fit(num_epochs=stage["epochs"], save_name=stage["save_name"])
    save_json(result, str(Path(paths["output_dir"]) / "stage2_train_result.json"))
    logger.info("Selected checkpoint: %s", result["best_ckpt_path"])


if __name__ == "__main__":
    main()
