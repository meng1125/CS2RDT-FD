"""Measure the Stage 2 Student's signed recall drops for each signal group."""

import argparse
import csv
import logging
from pathlib import Path

import numpy as np
import torch

from dataset import FEATURE_CHANNELS
from evaluate import (
    CLASSES, add_model_arguments, add_test_data_arguments, build_real_test_loader,
    configure_test_data, inference, load_student, read_evaluation_config,
)


PHASE_CURRENTS = ("ia", "ib", "id2", "ie")
DQ_CURRENTS = ("id", "iq")
XY_CURRENTS = ("ix", "iy")
DQ_VOLTAGES = ("ud", "uq")
XY_VOLTAGES = ("ux", "uy")
GROUPS = {
    "All currents": PHASE_CURRENTS + DQ_CURRENTS + XY_CURRENTS,
    "Auxiliary current": XY_CURRENTS,
    "Phase + aux. currents": PHASE_CURRENTS + XY_CURRENTS,
    "Phase current": PHASE_CURRENTS,
    "dq-axis variables": DQ_CURRENTS + DQ_VOLTAGES,
    "dq voltage": DQ_VOLTAGES,
    "All voltages": DQ_VOLTAGES + XY_VOLTAGES,
    "xy-axis variables": XY_CURRENTS + XY_VOLTAGES,
}
TARGETS = ("ITSC", "Demag")


def masked_batches(loader, channels, mean):
    indices = [FEATURE_CHANNELS.index(channel) for channel in channels]
    raw_fill = torch.as_tensor(mean[indices])[None, :, None]
    for batch in loader:
        # The time branch sees standardized signals. The FFT sees raw signals.
        batch["x_raw"][:, indices, :] = raw_fill
        batch["x"][:, indices, :] = 0.0
        yield batch


def window_ids(result):
    return [(item["file_path"], item["window_start"], item["window_end"]) for item in result["meta"]]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_model_arguments(parser)
    add_test_data_arguments(parser)
    parser.add_argument("--output", type=Path, default=Path("outputs/channel_occlusion.csv"))
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    logger = logging.getLogger("evaluate_occlusion")
    config = read_evaluation_config(args)
    configure_test_data(config, args)
    model, scaler, device, _ = load_student(config, args.ckpt, args.scaler)
    if not config["data"]["standardize"] or config["data"]["feature_channels"] != FEATURE_CHANNELS:
        raise ValueError("Occlusion requires the model's standardized 13-channel inputs")
    loader = build_real_test_loader(config, scaler, logger)

    unmasked = inference(model, loader, device)
    ids = window_ids(unmasked)
    labels = unmasked["y_true"]
    baseline = unmasked["y_pred"]
    class_windows = {target: labels == CLASSES.index(target) for target in TARGETS}
    if any(not mask.any() for mask in class_windows.values()):
        raise ValueError("Both ITSC and Demag must be present in the test split")
    del unmasked

    columns = ["Channel group", "Masked channels"]
    for target in TARGETS:
        columns.extend(f"{target} {metric}" for metric in ("correct", "total", "recall", "recall drop"))

    rows = []
    for group, channels in {"All inputs": (), **GROUPS}.items():
        predictions = baseline
        if channels:
            result = inference(model, masked_batches(loader, channels, scaler.mean), device)
            if window_ids(result) != ids or not np.array_equal(labels, result["y_true"]):
                raise ValueError(f"Test windows changed for {group}")
            predictions = result["y_pred"]
            del result

        row = [group, ", ".join(channels)]
        for mask in class_windows.values():
            support = int(mask.sum())
            correct = int((predictions[mask] == labels[mask]).sum())
            baseline_correct = int((baseline[mask] == labels[mask]).sum())
            drop = (baseline_correct - correct) / support
            row.extend((correct, support, f"{correct / support:.9f}", f"{drop:.9f}"))
        rows.append(row)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(columns)
        writer.writerows(rows)
    print(f"Occlusion results written to {args.output}")


if __name__ == "__main__":
    main()
