"""Render the signed recall changes from the frozen channel-occlusion evaluation."""

import argparse
import csv
from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np


DISPLAY_NAMES = {
    "Auxiliary current": "Auxiliary xy currents",
    "Phase + aux. currents": "Phase + xy currents",
    "Phase current": "Phase currents",
}
SERIES = (
    ("ITSC", -0.20, "#286DA6", "#A8CDE5", "#234F72", ""),
    ("Demag", 0.20, "#B55833", "#ECC3AC", "#743920", "///"),
)


def make_figure(results_path):
    mpl.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 8,
        "text.color": "#1F2933",
        "axes.labelcolor": "#1F2933",
        "axes.edgecolor": "#66717A",
        "axes.linewidth": 0.6,
        "axes.spines.left": False,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "xtick.color": "#1F2933",
        "ytick.color": "#1F2933",
        "hatch.linewidth": 0.35,
        "pdf.fonttype": 42,
    })

    with results_path.open(encoding="utf-8-sig", newline="") as stream:
        baseline, *rows = csv.DictReader(stream)
    if baseline["Channel group"] != "All inputs":
        raise ValueError("The first row must contain the unmasked baseline")

    labels = [DISPLAY_NAMES.get(row["Channel group"], row["Channel group"]) for row in rows]
    positions = np.arange(len(rows))
    fig, ax = plt.subplots(figsize=(3.50, 2.93))
    fig.subplots_adjust(left=0.335, right=0.980, bottom=0.154, top=0.870)

    ax.set_xlim(-0.32, 1.18)
    ax.set_ylim(len(rows) - 0.45, -0.55)
    ax.set_yticks(positions, labels)
    ax.set_xticks([-0.25, 0.0, 0.25, 0.50, 0.75, 1.0], ["−0.25", "0", "0.25", "0.50", "0.75", "1.00"])
    ax.set_xlabel("Recall drop (unmasked − masked)", labelpad=5)
    ax.tick_params(axis="x", labelsize=7.5, length=2.4, width=0.6, pad=3)
    ax.tick_params(axis="y", length=0, pad=5)
    ax.set_axisbelow(True)
    ax.grid(axis="x", color="#DDE2E7", linewidth=0.45, linestyle="--")
    ax.axvline(0, color="#525D68", linewidth=0.75, zorder=2)
    for divider in (3.5, 6.5):
        ax.axhline(divider, color="#DEE3E8", linewidth=0.55, zorder=1)

    legend_handles = []
    for target, offset, dark, light, edge, hatch in SERIES:
        drops = np.array([float(row[f"{target} recall drop"]) for row in rows])
        largest = set(np.argsort(drops)[-3:])
        colors = [dark if index in largest else light for index in range(len(rows))]
        y = positions + offset
        ax.barh(y, drops, height=0.31, color=colors, edgecolor=edge,
                linewidth=0.44, hatch=hatch, zorder=3)
        for index, (drop, row_y) in enumerate(zip(drops, y)):
            dx = -2.7 if drop < 0 else 2.7
            ax.annotate(
                f"{drop:.3f}".replace("-", "−"),
                (drop, row_y),
                xytext=(dx, 0),
                textcoords="offset points",
                ha="right" if drop < 0 else "left",
                va="center",
                fontsize=7.5,
                fontweight="bold" if index in largest else "normal",
            )
        unmasked = float(baseline[f"{target} recall"])
        legend_handles.append(Patch(facecolor=dark, edgecolor=edge, linewidth=0.44,
                                    hatch=hatch, label=f"{target} ({unmasked:.2%} unmasked)"))

    fig.legend(handles=legend_handles, loc="upper center", bbox_to_anchor=(0.54, 0.98),
               ncols=2, frameon=False, fontsize=8, handlelength=1.4,
               handletextpad=0.45, columnspacing=1.2)
    return fig



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, default=Path("outputs/channel_occlusion.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    figure = make_figure(args.csv)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    figure.savefig(args.output_dir / "fig6_channel_occlusion.png", dpi=600)
    figure.savefig(args.output_dir / "fig6_channel_occlusion.pdf")
    plt.close(figure)


if __name__ == "__main__":
    main()
