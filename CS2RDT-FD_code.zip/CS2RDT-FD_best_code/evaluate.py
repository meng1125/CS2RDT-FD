"""Evaluate Stage 2 on the measured five-class test split.

Run from the code folder. Set data and artifact paths in config.yaml or pass
them on the command line. The paper's full method uses its frozen fitted
physics reference, supplied separately via --physics-reference.
"""

import argparse
from copy import deepcopy
import logging
from pathlib import Path

import numpy as np

from dataset import IDX_TO_CLASS
from metrics import compute_confusion_matrix, compute_per_class_accuracy_from_cm
from test import apply_physics_postprocess_to_eval, evaluate_loader
from utils import (
    build_dataloader, build_model, build_stage_datasets_from_splits, get_device,
    get_or_create_split_records, load_config, load_model_weights, load_scaler,
    save_json, set_random_seed,
)


DISPLAY_NAMES = {"health": "Health", "tuici": "Demag"}
CLASSES = [DISPLAY_NAMES.get(IDX_TO_CLASS[index], IDX_TO_CLASS[index]) for index in range(len(IDX_TO_CLASS))]
OBSERVED = [CLASSES.index(name) for name in ("Health", "OPF", "Sensor")]
UNOBSERVED = [CLASSES.index(name) for name in ("ITSC", "Demag")]
ITSC_SWITCHES = (
    "enable_tuici_to_itsc", "enable_opf_to_itsc", "enable_health_to_itsc",
    "enable_a_phase_structural_itsc_rescue", "enable_i3a_health_to_itsc",
    "enable_i3b_freq_margin_rule", "enable_i3b_structural_override",
    "enable_segment_opf_itsc_refinement",
)
PHYSICS_MODES = {"itsc_only": (True, False), "demag_only": (False, True), "with_physics": (True, True)}


def add_model_arguments(parser):
    parser.add_argument("--config", type=Path, default=Path("config.yaml"))
    parser.add_argument("--ckpt", type=Path, help="Stage 2 checkpoint")
    parser.add_argument("--scaler", type=Path, help="Fitted Stage 2 scaler JSON")
    parser.add_argument("--device", choices=("cpu", "cuda"))


def add_test_data_arguments(parser):
    parser.add_argument("--data-root", type=Path, help="Directory containing data_real_* and data_sim_*")
    parser.add_argument("--cache-dir", type=Path, help="Directory for the split cache")


def read_evaluation_config(args):
    config = load_config(args.config)
    if args.device is not None:
        config["device"] = args.device
    return config


def configure_test_data(config, args):
    if args.data_root is not None:
        config["paths"]["data_root"] = str(args.data_root)
    if args.cache_dir is not None:
        config["data"]["cache_dir"] = str(args.cache_dir)


def load_student(config, ckpt=None, scaler_path=None):
    checkpoint_dir = Path(config["paths"]["checkpoint_dir"])
    ckpt = ckpt or checkpoint_dir / config["train"]["stage2"]["save_name"]
    scaler_path = scaler_path or checkpoint_dir / "scaler_stage2.json"
    if not Path(ckpt).is_file() or not Path(scaler_path).is_file():
        raise FileNotFoundError(f"Provide the Stage 2 checkpoint and fitted scaler: {ckpt}, {scaler_path}")

    set_random_seed(config["random_seed"])
    device = get_device(config)
    model = build_model(config).to(device)
    state = load_model_weights(model, str(ckpt), strict=True)
    if state.get("stage_name") != "stage2":
        raise ValueError(f"Expected a Stage 2 checkpoint: {ckpt}")
    model.eval().requires_grad_(False)
    scaler = load_scaler(str(scaler_path))
    if config["data"]["standardize"] and not scaler.fitted:
        raise ValueError(f"Expected a fitted Stage 2 scaler: {scaler_path}")
    model_info = {"checkpoint": str(ckpt), "scaler": str(scaler_path), "epoch": state["epoch"],
                  "seed": state["config"]["random_seed"]}
    return model, scaler, device, model_info


def build_real_test_loader(config, scaler, logger):
    split = get_or_create_split_records(config, logger)["split_records"]
    datasets = build_stage_datasets_from_splits(config, split, "test", logger, scaler=scaler, fit_scaler=False)
    data = config["data"]
    return build_dataloader(
        datasets["test_datasets"]["real_test_all5"], data["batch_size"], data["num_workers"],
        pin_memory=data["pin_memory"], shuffle=False, drop_last=False,
    )


def inference(model, loader, device):
    result = evaluate_loader(model, loader, device, len(CLASSES))
    if len(result["y_true"]) == 0 or not np.isfinite(result["logits"]).all():
        raise ValueError("Expected nonempty test data and finite logits")
    return result


def summarize(y_true, y_pred):
    matrix = compute_confusion_matrix(y_true, y_pred, len(CLASSES))
    correct = matrix.diagonal()
    support = matrix.sum(axis=1)
    if support.sum() != len(y_true) or (support == 0).any():
        raise ValueError("The paper's metrics require test windows from all five classes")
    recall = compute_per_class_accuracy_from_cm(matrix)
    return {
        "metrics": {
            "Overall Acc.": float(correct.sum() / support.sum()),
            "Observed Acc.": float(correct[OBSERVED].sum() / support[OBSERVED].sum()),
            "ITSC Rec.": float(recall[UNOBSERVED[0]]),
            "Demag Rec.": float(recall[UNOBSERVED[1]]),
            "Unobserved Rec.": float(correct[UNOBSERVED].sum() / support[UNOBSERVED].sum()),
            "Macro-F1": float((2 * correct / (support + matrix.sum(axis=0))).mean()),
        },
        "per_class_accuracy": {label: float(recall[index]) for index, label in enumerate(CLASSES)},
        "support": dict(zip(CLASSES, map(int, support))),
        "confusion_matrix": matrix.tolist(),
    }


def set_physics_reference(config, path):
    section = config["physics_fusion"]
    reference = path or Path(section["reference_path"])
    if not reference.is_file():
        raise FileNotFoundError(f"Provide the fitted physics reference with --physics-reference: {reference}")
    section["reference_path"] = str(reference.resolve())
    return reference.resolve()


def refinement_config(config, itsc, demag):
    mode = deepcopy(config)
    physics = mode["physics_fusion"]
    physics.update(enabled=itsc or demag, apply_correction=itsc or demag)
    if not itsc:
        physics["rules"].update(dict.fromkeys(ITSC_SWITCHES, False))
    if not demag:
        physics["rules"]["enable_flux_demag_rescue"] = False
    return mode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_model_arguments(parser)
    add_test_data_arguments(parser)
    parser.add_argument("--physics", choices=("none", "full", "ablation"), default="full")
    parser.add_argument("--physics-reference", type=Path)
    parser.add_argument("--output", type=Path, default=Path("outputs/evaluation.json"))
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    config = read_evaluation_config(args)
    configure_test_data(config, args)
    if args.physics != "none":
        reference = set_physics_reference(config, args.physics_reference)
    model, scaler, device, model_info = load_student(config, args.ckpt, args.scaler)
    loader = build_real_test_loader(config, scaler, logging.getLogger("evaluate"))
    result = inference(model, loader, device)
    y_true = result["y_true"]
    reports = {"student": summarize(y_true, result["y_pred"])}
    report = {"model": model_info, "class_order": CLASSES, "test_window_count": len(y_true), "results": reports}

    if args.physics != "none":
        report["physics_reference"] = str(reference)
        modes = PHYSICS_MODES if args.physics == "ablation" else {"with_physics": PHYSICS_MODES["with_physics"]}
        for name, switches in modes.items():
            print(f"Evaluating {name}", flush=True)
            mode = refinement_config(config, *switches)
            physics = apply_physics_postprocess_to_eval(dict(result), mode, IDX_TO_CLASS)
            reports[name] = summarize(y_true, physics["physics_y_pred"])

    save_json(report, str(args.output))
    for name, result in reports.items():
        print(name, " | ".join(f"{key} {value:.2%}" for key, value in result["metrics"].items()))


if __name__ == "__main__":
    main()
