# utils.py
# -*- coding: utf-8 -*-

"""
通用工具模块：
1. YAML 配置读取
2. 随机种子固定
3. 日志创建
4. 目录创建
5. 设备选择
6. 自定义 DataLoader 的 collate_fn
7. 模型构建
8. 优化器构建
9. 数据集准备（避免真实未知类进入训练统计）
10. checkpoint 辅助加载
"""

import os
import json
import copy
import pickle
import random
import logging
from typing import Dict, Any, Optional, List, Sequence, Tuple

import yaml
import numpy as np
import torch
from torch.utils.data import BatchSampler, DataLoader

from dataset import (
    FEATURE_CHANNELS,
    IDX_TO_CLASS,
    FileRecord,
    build_file_records,
    stratified_split_records,
    filter_records,
    filter_records_by_unknown_fault_speed,
    split_unknown_real_test_records,
    WindowedFaultDataset,
    IndexedWindowFaultDataset,
    ChannelWiseScaler,
)
from augment import TimeSeriesAugment
# 延迟导入 FullModel，避免只使用数据工具时强制加载完整 torch/model 依赖


# =========================
# 配置与基础工具
# =========================
def load_config(config_path: str) -> Dict[str, Any]:
    """
    读取 YAML 配置
    """
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return cfg


def ensure_dir(path: str) -> None:
    """
    若目录不存在则创建
    """
    os.makedirs(path, exist_ok=True)


def save_json(obj: Dict[str, Any], save_path: str) -> None:
    """
    保存 JSON
    """
    ensure_dir(os.path.dirname(save_path) if os.path.dirname(save_path) else ".")
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=True)


def set_random_seed(seed: int = 3407) -> None:
    """
    固定随机种子，保证实验可复现
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    # 为了尽量可复现，关闭部分 cudnn 自动优化
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def setup_logger(
    name: str,
    log_dir: str,
    log_filename: Optional[str] = None,
    level: str = "INFO"
) -> logging.Logger:
    """
    同时输出到控制台和文件的日志器
    """
    ensure_dir(log_dir)

    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.propagate = False

    # 避免重复添加 handler
    if logger.handlers:
        return logger

    formatter = logging.Formatter(
        fmt="[%(asctime)s] [%(levelname)s] %(name)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    if log_filename is None:
        log_filename = f"{name}.log"

    file_handler = logging.FileHandler(
        os.path.join(log_dir, log_filename),
        encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


def get_device(config: Dict[str, Any]) -> torch.device:
    """
    根据配置选择 device
    """
    use_gpu_if_available = bool(config.get("use_gpu_if_available", True))
    device_name = str(config.get("device", "cuda"))

    if use_gpu_if_available and torch.cuda.is_available():
        return torch.device(device_name)
    return torch.device("cpu")


def count_trainable_parameters(model: torch.nn.Module) -> int:
    """
    统计可训练参数量
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


# =========================
# DataLoader 辅助
# =========================
def fault_diagnosis_collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    自定义 collate_fn

    为什么需要自定义：
    - dataset.py 中 meta 是嵌套 dict，里面有字符串、list 等非张量对象
    - 默认 collate 可能对可变长 list（如 available_signals）处理失败

    因此这里显式地：
    - 将 x / y / domain / known_real / trainable_in_real / speed / load 堆叠成 Tensor
    - meta 保留为“样本级 dict 列表”
    """
    x = torch.stack([item["x"] for item in batch], dim=0)
    x_raw = torch.stack([item["x_raw"] for item in batch], dim=0)
    y = torch.tensor([int(item["y"]) for item in batch], dtype=torch.long)
    domain = torch.tensor([int(item["domain"]) for item in batch], dtype=torch.long)
    known_real = torch.tensor([int(item["known_real"]) for item in batch], dtype=torch.long)
    trainable_in_real = torch.tensor([int(item["trainable_in_real"]) for item in batch], dtype=torch.long)
    speed = torch.stack([item["speed"] for item in batch], dim=0)
    load = torch.stack([item["load"] for item in batch], dim=0)

    meta = [item["meta"] for item in batch]

    return {
        "x": x,
        "x_raw": x_raw,
        "y": y,
        "domain": domain,
        "known_real": known_real,
        "trainable_in_real": trainable_in_real,
        "speed": speed,
        "load": load,
        "meta": meta,
    }


def build_dataloader(
    dataset,
    batch_size: int,
    num_workers: int,
    pin_memory: bool = True,
    shuffle: bool = False,
    drop_last: bool = False
) -> DataLoader:
    """
    构建 DataLoader
    """
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=drop_last,
        collate_fn=fault_diagnosis_collate_fn,
    )


def move_batch_to_device(batch: Dict[str, Any], device: torch.device) -> Dict[str, Any]:
    """
    将 batch 中的 tensor 移动到目标设备
    """
    moved = {}
    for k, v in batch.items():
        if torch.is_tensor(v):
            moved[k] = v.to(device, non_blocking=True)
        else:
            moved[k] = v
    return moved


# =========================
# 模型 / 优化器
# =========================
def build_model(config: Dict[str, Any]):
    """
    根据 config 构建 FullModel
    """
    from models import FullModel

    model_cfg = config["model"]

    # 这里优先信任 config 中的 backbone_in_channels，
    # 但额外检查是否与 dataset.py 中 FEATURE_CHANNELS 数一致
    if int(model_cfg["backbone_in_channels"]) != len(FEATURE_CHANNELS):
        raise ValueError(
            f"config 中 backbone_in_channels={model_cfg['backbone_in_channels']} "
            f"与 dataset.FEATURE_CHANNELS 长度 {len(FEATURE_CHANNELS)} 不一致"
        )

    freq_input_channels = model_cfg.get("freq_input_channels", ["ia", "id2"])
    freq_input_indices = []
    for channel_name in freq_input_channels:
        if channel_name not in FEATURE_CHANNELS:
            raise ValueError(f"未知频域输入通道: {channel_name}; 可选通道={FEATURE_CHANNELS}")
        freq_input_indices.append(FEATURE_CHANNELS.index(channel_name))

    model = FullModel(
        in_channels=int(model_cfg["backbone_in_channels"]),
        num_classes=int(model_cfg["num_classes"]),
        num_domains=int(model_cfg["num_domains"]),
        shared_dim=int(model_cfg["shared_dim"]),
        feature_dim=int(model_cfg["feature_dim"]),
        mscnn_branch_channels=int(model_cfg["mscnn_branch_channels"]),
        mscnn_kernel_sizes=tuple(model_cfg["mscnn_kernel_sizes"]),
        tcn_hidden_channels=tuple(model_cfg["tcn_hidden_channels"]),
        tcn_kernel_size=int(model_cfg["tcn_kernel_size"]),
        tcn_dropout=float(model_cfg["tcn_dropout"]),
        use_freq_branch=bool(model_cfg["use_freq_branch"]),
        freq_branch_channels=int(model_cfg["freq_branch_channels"]),
        freq_out_dim=int(model_cfg["freq_out_dim"]),
        sample_rate_hz=float(model_cfg.get("sample_rate_hz", 1000.0)),
        window_size=int(model_cfg.get("window_size", config.get("data", {}).get("window_size", 2000))),
        pole_pairs=int(model_cfg.get("pole_pairs", 5)),
        freq_input_indices=tuple(freq_input_indices),
        freq_num_centers=int(model_cfg.get("freq_num_centers", 5)),
        freq_half_width_fe_ratio=float(model_cfg.get("freq_half_width_fe_ratio", 0.5)),
        freq_log_scale=float(model_cfg.get("freq_log_scale", 100.0)),
        fusion_alpha_init=model_cfg.get("fusion_alpha_init", [0.25, 0.40, 0.75, 0.30, 0.40]),
        fusion_alpha_min=float(model_cfg.get("fusion_alpha_min", 0.1)),
        fusion_alpha_max=float(model_cfg.get("fusion_alpha_max", 0.9)),
        classifier_hidden_dim=int(model_cfg["classifier_hidden_dim"]),
        domain_hidden_dim=int(model_cfg["domain_hidden_dim"]),
        proto_metric=str(model_cfg["proto_metric"]),
        proto_temperature=float(model_cfg["proto_temperature"]),
        proto_alpha=float(model_cfg["proto_alpha"]),
        dropout=float(model_cfg.get("dropout", 0.1)),
    )
    return model


def build_optimizer(
    model: torch.nn.Module,
    lr: float,
    weight_decay: float = 1e-4
) -> torch.optim.Optimizer:
    """
    构建 AdamW 优化器
    """
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(
        trainable_params,
        lr=lr,
        weight_decay=weight_decay
    )
    return optimizer


def load_checkpoint_file(
    ckpt_path: str,
    map_location: str = "cpu"
) -> Dict[str, Any]:
    """
    加载 checkpoint 文件
    """
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"checkpoint 不存在: {ckpt_path}")
    return torch.load(ckpt_path, map_location=map_location)


def load_model_weights(
    model: torch.nn.Module,
    ckpt_path: str,
    map_location: str = "cpu",
    strict: bool = True
) -> Dict[str, Any]:
    """
    从 checkpoint 中加载模型权重
    """
    ckpt = load_checkpoint_file(ckpt_path, map_location=map_location)
    if "model_state_dict" not in ckpt:
        raise KeyError(f"checkpoint 中缺少 model_state_dict: {ckpt_path}")
    load_result = model.load_state_dict(ckpt["model_state_dict"], strict=strict)
    if not strict:
        missing_keys = list(getattr(load_result, "missing_keys", []))
        unexpected_keys = list(getattr(load_result, "unexpected_keys", []))
        if missing_keys:
            print(f"[load_model_weights] missing_keys: {missing_keys}")
        if unexpected_keys:
            print(f"[load_model_weights] unexpected_keys: {unexpected_keys}")
    return ckpt


def clone_model_for_teacher(
    student_model: torch.nn.Module,
    device: torch.device
) -> torch.nn.Module:
    """
    复制一个 teacher 模型副本
    """
    teacher_model = copy.deepcopy(student_model).to(device)
    teacher_model.eval()
    for p in teacher_model.parameters():
        p.requires_grad = False
    return teacher_model


# =========================
# 训练统计
# =========================
class AverageMeter:
    """
    用于累计均值统计
    """
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.val = 0.0
        self.sum = 0.0
        self.count = 0
        self.avg = 0.0

    def update(self, val: float, n: int = 1) -> None:
        self.val = float(val)
        self.sum += float(val) * int(n)
        self.count += int(n)
        self.avg = self.sum / max(self.count, 1)


def detach_loss_dict(loss_dict: Dict[str, torch.Tensor]) -> Dict[str, float]:
    """
    将 loss dict 转为普通 float dict，方便日志打印
    """
    out = {}
    for k, v in loss_dict.items():
        if torch.is_tensor(v):
            out[k] = float(v.detach().cpu().item())
        else:
            out[k] = float(v)
    return out


def summarize_records_by_label(records: List[Any]) -> Dict[str, Any]:
    """
    按类别汇总文件数、窗口数和工况分布，便于检查 train/val/test 划分是否均衡。
    """
    summary: Dict[str, Any] = {}
    for record in records:
        label_name = record.label_name
        if label_name not in summary:
            summary[label_name] = {
                "num_files": 0,
                "num_windows": 0,
                "loads": [],
                "speeds": [],
            }

        item = summary[label_name]
        item["num_files"] += 1
        item["num_windows"] += int(record.num_windows)
        if record.load is not None:
            item["loads"].append(float(record.load))
        if record.speed is not None:
            item["speeds"].append(float(record.speed))

    compact: Dict[str, Any] = {}
    for label_name, item in summary.items():
        loads = item["loads"]
        speeds = item["speeds"]
        compact[label_name] = {
            "num_files": item["num_files"],
            "num_windows": item["num_windows"],
            "loads_unique": sorted(set(loads)),
            "speed_min": None if len(speeds) == 0 else float(min(speeds)),
            "speed_max": None if len(speeds) == 0 else float(max(speeds)),
            "speed_mean": None if len(speeds) == 0 else float(np.mean(speeds)),
        }
    return compact


def get_configured_known_real_classes(config: Dict[str, Any]) -> Tuple[str, ...]:
    """Return config-driven real-domain known classes."""
    data_cfg = config.get("data", {})
    class_names = data_cfg.get("known_real_classes", ["health", "OPF", "Sensor"])
    return tuple(str(name) for name in class_names)


def get_configured_unknown_real_classes(config: Dict[str, Any]) -> Tuple[str, ...]:
    """Return config-driven real-domain unknown classes."""
    data_cfg = config.get("data", {})
    class_names = data_cfg.get("unknown_real_classes", ["ITSC", "tuici"])
    return tuple(str(name) for name in class_names)


def get_class_indices_by_name(class_names: Sequence[str]) -> Tuple[int, ...]:
    """Convert class names to CLASS_TO_IDX indices with validation."""
    from dataset import CLASS_TO_IDX

    indices: List[int] = []
    for name in class_names:
        if name not in CLASS_TO_IDX:
            raise ValueError(f"未知类别名: {name}")
        indices.append(int(CLASS_TO_IDX[name]))
    return tuple(indices)


def get_known_unknown_real_class_indices(config: Dict[str, Any]) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
    """Return (known_real_indices, unknown_real_indices) from config."""
    known_names = get_configured_known_real_classes(config)
    unknown_names = get_configured_unknown_real_classes(config)
    overlap = set(known_names) & set(unknown_names)
    if overlap:
        raise ValueError(f"known_real_classes 与 unknown_real_classes 有交集: {sorted(overlap)}")
    return get_class_indices_by_name(known_names), get_class_indices_by_name(unknown_names)


def summarize_records_by_domain_label_speed(records: Sequence[FileRecord]) -> Dict[str, Dict[str, Dict[int, int]]]:
    """Summarize record counts by domain, label, and rounded speed."""
    summary: Dict[str, Dict[str, Dict[int, int]]] = {}
    for record in records:
        if record.speed is None:
            speed_key = -1
        else:
            speed_key = int(round(float(record.speed)))
        label_summary = summary.setdefault(record.domain_name, {}).setdefault(record.label_name, {})
        label_summary[speed_key] = label_summary.get(speed_key, 0) + 1
    return summary


def filter_records_by_speed_whitelist(
    records: Sequence[FileRecord],
    speed_filter_cfg: Optional[Dict[str, Any]] = None,
    logger: Optional[logging.Logger] = None,
) -> List[FileRecord]:
    """Filter records by an explicit rounded-speed whitelist."""
    logger = logger or logging.getLogger(__name__)
    speed_filter_cfg = speed_filter_cfg or {}
    if not bool(speed_filter_cfg.get("enabled", False)):
        return list(records)

    allowed_speeds = {int(round(float(speed))) for speed in speed_filter_cfg.get("speeds", [])}
    if not allowed_speeds:
        raise ValueError("speed_filter.enabled=True 但 speeds 为空")

    apply_domains_cfg = speed_filter_cfg.get("apply_domains", None)
    apply_labels_cfg = speed_filter_cfg.get("apply_labels", None)
    apply_domains = None if apply_domains_cfg is None else {str(x) for x in apply_domains_cfg}
    apply_labels = None if apply_labels_cfg is None else {str(x) for x in apply_labels_cfg}

    kept: List[FileRecord] = []
    removed: List[FileRecord] = []
    for record in records:
        domain_match = apply_domains is None or record.domain_name in apply_domains
        label_match = apply_labels is None or record.label_name in apply_labels
        if not (domain_match and label_match):
            kept.append(record)
            continue

        rounded_speed = None if record.speed is None else int(round(float(record.speed)))
        if rounded_speed in allowed_speeds:
            kept.append(record)
        else:
            removed.append(record)

    logger.info(
        f"[速度白名单过滤] enabled=True, speeds={sorted(allowed_speeds)}, "
        f"apply_domains={'all' if apply_domains is None else sorted(apply_domains)}, "
        f"apply_labels={'all' if apply_labels is None else sorted(apply_labels)}, "
        f"before={len(records)}, after={len(kept)}, removed={len(removed)}"
    )
    logger.info(f"[速度白名单过滤] 保留统计: {summarize_records_by_domain_label_speed(kept)}")
    if removed:
        logger.info(f"[速度白名单过滤] 移除统计: {summarize_records_by_domain_label_speed(removed)}")
    return kept


def apply_real_class_policy(
    records: Sequence[FileRecord],
    known_real_classes: Sequence[str],
    unknown_real_classes: Sequence[str],
    logger: Optional[logging.Logger] = None,
) -> List[FileRecord]:
    """Apply config-driven real known/unknown class flags to FileRecord objects."""
    logger = logger or logging.getLogger(__name__)
    known_set = {str(name) for name in known_real_classes}
    unknown_set = {str(name) for name in unknown_real_classes}
    overlap = known_set & unknown_set
    if overlap:
        raise ValueError(f"known_real_classes 与 unknown_real_classes 有交集: {sorted(overlap)}")

    updated = list(records)
    for record in updated:
        if record.domain_name != "real":
            record.known_real = 0
            record.trainable_in_real = 0
            continue

        if record.label_name in known_set:
            record.known_real = 1
            record.trainable_in_real = 1
        elif record.label_name in unknown_set:
            record.known_real = 0
            record.trainable_in_real = 0
        else:
            raise ValueError(
                f"真实域类别 {record.label_name} 既不在 known_real_classes={sorted(known_set)} "
                f"也不在 unknown_real_classes={sorted(unknown_set)}"
            )

    logger.info(
        f"[真实类别策略] known_real_classes={sorted(known_set)}, "
        f"unknown_real_classes={sorted(unknown_set)}"
    )
    return updated


WindowIndex = Tuple[int, int]


def make_window_indices_for_records(records: Sequence[FileRecord]) -> List[WindowIndex]:
    """展开所有 FileRecord 的窗口索引。"""
    indices: List[WindowIndex] = []
    for record_idx, record in enumerate(records):
        for window_idx in range(int(record.num_windows)):
            indices.append((int(record_idx), int(window_idx)))
    return indices


def filter_window_indices(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    domain_names: Optional[Sequence[str]] = None,
    label_names: Optional[Sequence[str]] = None,
    real_trainable_only: bool = False,
) -> List[WindowIndex]:
    """按 FileRecord 元信息过滤窗口索引。"""
    domain_set = None if domain_names is None else set(domain_names)
    label_set = None if label_names is None else set(label_names)
    filtered: List[WindowIndex] = []

    for record_idx, window_idx in window_indices:
        record = records[int(record_idx)]
        if domain_set is not None and record.domain_name not in domain_set:
            continue
        if label_set is not None and record.label_name not in label_set:
            continue
        if real_trainable_only and record.domain_name == "real" and record.trainable_in_real != 1:
            continue
        filtered.append((int(record_idx), int(window_idx)))

    return filtered


def _compute_window_split_counts(n: int, train_ratio: float, val_ratio: float, test_ratio: float) -> Tuple[int, int, int]:
    if n <= 0:
        return 0, 0, 0
    if n == 1:
        return 1, 0, 0
    if n == 2:
        return 1, 0, 1

    n_train = int(round(n * train_ratio))
    n_val = int(round(n * val_ratio))
    n_test = n - n_train - n_val

    if n_train <= 0:
        n_train = 1
    if n_val <= 0:
        n_val = 1
    if n_test <= 0:
        n_test = 1

    total = n_train + n_val + n_test
    while total > n:
        if n_train >= n_val and n_train >= n_test and n_train > 1:
            n_train -= 1
        elif n_val >= n_test and n_val > 1:
            n_val -= 1
        elif n_test > 1:
            n_test -= 1
        else:
            break
        total = n_train + n_val + n_test

    return n_train, n_val, n_test


def make_condition_key(
    record: FileRecord,
    speed_bin_size: float = 100.0,
    use_load: bool = True,
    load_bin_size: float = 0.5,
) -> Optional[Tuple[float, ...]]:
    """Build a speed/load condition key for condition-aware splitting and sampling."""
    speed = getattr(record, "speed", None)
    if speed is None or not np.isfinite(float(speed)):
        return None
    speed_size = max(float(speed_bin_size), 1e-12)
    speed_bin = round(float(speed) / speed_size) * speed_size

    load = getattr(record, "load", None)
    if use_load and load is not None and np.isfinite(float(load)):
        load_size = max(float(load_bin_size), 1e-12)
        load_bin = round(float(load) / load_size) * load_size
        return (float(load_bin), float(speed_bin))
    return (float(speed_bin),)


def _exact_condition_key_for_record(record: FileRecord) -> Tuple[Any, ...]:
    """Exact operating condition: domain, label, load, speed."""
    load = None if record.load is None else round(float(record.load), 6)
    speed = None if record.speed is None else round(float(record.speed), 6)
    return (record.domain_name, record.label_name, load, speed)


def _condition_distance(a: Optional[Tuple[float, ...]], b: Optional[Tuple[float, ...]]) -> float:
    if a is None or b is None:
        return float("inf")
    if len(a) != len(b):
        return float("inf")
    return float(sum((float(x) - float(y)) ** 2 for x, y in zip(a, b)))


def _group_window_indices_by_label_condition(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    domain_name: str,
    label_names: Sequence[str],
    speed_bin_size: float,
    use_load: bool,
    load_bin_size: float,
) -> Dict[Tuple[str, Tuple[float, ...]], List[WindowIndex]]:
    label_set = {str(name) for name in label_names}
    groups: Dict[Tuple[str, Tuple[float, ...]], List[WindowIndex]] = {}
    for record_idx, window_idx in window_indices:
        record = records[int(record_idx)]
        if record.domain_name != domain_name or record.label_name not in label_set:
            continue
        condition_key = make_condition_key(
            record,
            speed_bin_size=speed_bin_size,
            use_load=use_load,
            load_bin_size=load_bin_size,
        )
        if condition_key is None:
            continue
        groups.setdefault((record.label_name, condition_key), []).append((int(record_idx), int(window_idx)))
    return groups


def _split_one_window_group(
    group: Sequence[WindowIndex],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
) -> Tuple[List[WindowIndex], List[WindowIndex], List[WindowIndex]]:
    n_train, n_val, n_test = _compute_window_split_counts(len(group), train_ratio, val_ratio, test_ratio)
    group = list(group)
    return (
        group[:n_train],
        group[n_train:n_train + n_val],
        group[n_train + n_val:n_train + n_val + n_test],
    )


def _draw_sim_windows_for_split(
    *,
    label_name: str,
    condition_key: Tuple[float, ...],
    target_count: int,
    split_name: str,
    sim_groups: Dict[Tuple[str, Tuple[float, ...]], List[WindowIndex]],
    used_by_label: Dict[str, set],
    rng: random.Random,
    replacement: bool,
    fallback_stats: Dict[str, int],
    logger: Optional[logging.Logger] = None,
) -> List[WindowIndex]:
    target_count = int(target_count)
    if target_count <= 0:
        return []

    used = used_by_label.setdefault(label_name, set())
    exact_group = list(sim_groups.get((label_name, condition_key), []))
    exact_available = [idx for idx in exact_group if idx not in used]
    chosen: List[WindowIndex] = []

    take = min(target_count, len(exact_available))
    if take > 0:
        chosen.extend(exact_available[:take])

    missing = target_count - len(chosen)
    if missing > 0:
        fallback_stats["missing_exact"] = fallback_stats.get("missing_exact", 0) + missing
        same_label_groups = [
            (key[1], values)
            for key, values in sim_groups.items()
            if key[0] == label_name and key[1] != condition_key
        ]
        same_label_groups.sort(key=lambda item: _condition_distance(condition_key, item[0]))
        for _, values in same_label_groups:
            available = [idx for idx in values if idx not in used and idx not in chosen]
            take = min(missing, len(available))
            if take > 0:
                chosen.extend(available[:take])
                fallback_stats["fallback_neighbor"] = fallback_stats.get("fallback_neighbor", 0) + take
                missing -= take
            if missing <= 0:
                break

    if missing > 0:
        all_same_label = [
            idx
            for key, values in sim_groups.items()
            if key[0] == label_name
            for idx in values
            if idx not in used and idx not in chosen
        ]
        take = min(missing, len(all_same_label))
        if take > 0:
            chosen.extend(all_same_label[:take])
            fallback_stats["fallback_all_label"] = fallback_stats.get("fallback_all_label", 0) + take
            missing -= take

    if missing > 0 and replacement:
        replacement_pool = exact_group or [
            idx
            for key, values in sim_groups.items()
            if key[0] == label_name
            for idx in values
        ]
        if replacement_pool:
            sampled = [rng.choice(replacement_pool) for _ in range(missing)]
            chosen.extend(sampled)
            fallback_stats["replacement"] = fallback_stats.get("replacement", 0) + len(sampled)
            missing = 0

    if missing > 0:
        fallback_stats["shortage"] = fallback_stats.get("shortage", 0) + missing
        if logger is not None:
            logger.warning(
                "[condition_mirrored_split] sim %s %s condition=%s target=%s shortage=%s",
                label_name,
                split_name,
                condition_key,
                target_count,
                missing,
            )

    for idx in chosen:
        used.add(idx)
    return chosen


def _summarize_window_indices_by_label_condition(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    speed_bin_size: float,
    use_load: bool,
    load_bin_size: float,
) -> Dict[str, Dict[str, Dict[str, int]]]:
    summary: Dict[str, Dict[str, Dict[str, int]]] = {}
    for record_idx, _ in window_indices:
        record = records[int(record_idx)]
        condition_key = make_condition_key(record, speed_bin_size, use_load, load_bin_size)
        key = str(condition_key)
        summary.setdefault(record.domain_name, {}).setdefault(record.label_name, {})
        summary[record.domain_name][record.label_name][key] = summary[record.domain_name][record.label_name].get(key, 0) + 1
    return summary


def _assert_no_real_unknown_windows(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    unknown_real_classes: Sequence[str],
    context: str,
) -> None:
    unknown_set = {str(name) for name in unknown_real_classes}
    leaked = [
        (record_idx, window_idx, records[int(record_idx)].label_name)
        for record_idx, window_idx in window_indices
        if records[int(record_idx)].domain_name == "real"
        and records[int(record_idx)].label_name in unknown_set
    ]
    if leaked:
        preview = leaked[:5]
        raise RuntimeError(f"{context} contains real unknown samples: {preview}")


def _assert_no_real_unknown_records(
    records: Sequence[FileRecord],
    unknown_real_classes: Sequence[str],
    context: str,
) -> None:
    unknown_set = {str(name) for name in unknown_real_classes}
    leaked = [
        (idx, record.label_name, record.filename)
        for idx, record in enumerate(records)
        if record.domain_name == "real" and record.label_name in unknown_set
    ]
    if leaked:
        raise RuntimeError(f"{context} contains real unknown records: {leaked[:5]}")


def stratified_split_window_indices_real_condition_mirrored(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    train_ratio: float = 0.7,
    val_ratio: float = 0.2,
    test_ratio: float = 0.1,
    seed: int = 3407,
    known_real_class_names: Sequence[str] = ("health", "OPF", "Sensor"),
    unknown_real_class_names: Sequence[str] = ("ITSC", "tuici"),
    unknown_sim_class_names: Sequence[str] = ("ITSC", "tuici"),
    speed_bin_size: float = 100.0,
    use_load: bool = True,
    load_bin_size: float = 0.5,
    replacement: bool = False,
    split_real_unknown_as_shadow: bool = True,
    mirror_sim_from_real_unknown_shadow: bool = True,
    unknown_count_policy: str = "mean_known",
    unknown_class_multipliers: Optional[Dict[str, float]] = None,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, List[WindowIndex]]:
    """Condition-aware real split with sim split mirrored from real condition counts."""
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "split ratios must sum to 1"
    rng = random.Random(seed)
    logger = logger or logging.getLogger(__name__)
    known_real_class_names = tuple(str(name) for name in known_real_class_names)
    unknown_real_class_names = tuple(str(name) for name in unknown_real_class_names)
    unknown_sim_class_names = tuple(str(name) for name in unknown_sim_class_names)
    unknown_class_multipliers = unknown_class_multipliers or {}

    real_known_groups = _group_window_indices_by_label_condition(
        records, window_indices, "real", known_real_class_names, speed_bin_size, use_load, load_bin_size
    )
    real_unknown_groups = _group_window_indices_by_label_condition(
        records, window_indices, "real", unknown_real_class_names, speed_bin_size, use_load, load_bin_size
    )
    sim_groups = _group_window_indices_by_label_condition(
        records,
        window_indices,
        "sim",
        tuple(dict.fromkeys(list(known_real_class_names) + list(unknown_sim_class_names))),
        speed_bin_size,
        use_load,
        load_bin_size,
    )

    for group_dict in (real_known_groups, real_unknown_groups, sim_groups):
        for key in list(group_dict.keys()):
            values = list(group_dict[key])
            rng.shuffle(values)
            group_dict[key] = values

    train_indices: List[WindowIndex] = []
    val_indices: List[WindowIndex] = []
    test_indices: List[WindowIndex] = []
    real_known_train: List[WindowIndex] = []
    real_known_val: List[WindowIndex] = []
    real_known_test: List[WindowIndex] = []
    real_unknown_train_shadow: List[WindowIndex] = []
    real_unknown_val_shadow: List[WindowIndex] = []
    real_unknown_test: List[WindowIndex] = []
    sim_train: List[WindowIndex] = []
    sim_val: List[WindowIndex] = []
    sim_test: List[WindowIndex] = []

    known_targets: Dict[Tuple[str, Tuple[float, ...]], Tuple[int, int, int]] = {}
    aggregate_known: Dict[Tuple[float, ...], List[int]] = {}

    for key, group in real_known_groups.items():
        part_train, part_val, part_test = _split_one_window_group(group, train_ratio, val_ratio, test_ratio)
        real_known_train.extend(part_train)
        real_known_val.extend(part_val)
        real_known_test.extend(part_test)
        train_indices.extend(part_train)
        val_indices.extend(part_val)
        test_indices.extend(part_test)
        known_targets[key] = (len(part_train), len(part_val), len(part_test))
        aggregate = aggregate_known.setdefault(key[1], [0, 0, 0])
        aggregate[0] += len(part_train)
        aggregate[1] += len(part_val)
        aggregate[2] += len(part_test)

    unknown_targets: Dict[Tuple[str, Tuple[float, ...]], Tuple[int, int, int]] = {}
    for key, group in real_unknown_groups.items():
        part_train, part_val, part_test = _split_one_window_group(group, train_ratio, val_ratio, test_ratio)
        if split_real_unknown_as_shadow:
            real_unknown_train_shadow.extend(part_train)
            real_unknown_val_shadow.extend(part_val)
            real_unknown_test.extend(part_test)
            test_indices.extend(part_test)
            unknown_targets[key] = (len(part_train), len(part_val), len(part_test))
        else:
            real_unknown_test.extend(group)
            test_indices.extend(group)
            unknown_targets[key] = (0, 0, len(group))

    used_sim_by_label: Dict[str, set] = {}
    fallback_stats: Dict[str, int] = {}
    split_buckets = {"train": sim_train, "val": sim_val, "test": sim_test}
    split_all = {"train": train_indices, "val": val_indices, "test": test_indices}

    for key, counts in known_targets.items():
        label_name, condition_key = key
        for split_name, target_count in zip(("train", "val", "test"), counts):
            drawn = _draw_sim_windows_for_split(
                label_name=label_name,
                condition_key=condition_key,
                target_count=target_count,
                split_name=split_name,
                sim_groups=sim_groups,
                used_by_label=used_sim_by_label,
                rng=rng,
                replacement=replacement,
                fallback_stats=fallback_stats,
                logger=logger,
            )
            split_buckets[split_name].extend(drawn)
            split_all[split_name].extend(drawn)

    if mirror_sim_from_real_unknown_shadow:
        unknown_distribution = unknown_targets
    else:
        unknown_distribution = {}
        divisor = max(1, len(known_real_class_names))
        for condition_key, counts in aggregate_known.items():
            for label_name in unknown_sim_class_names:
                multiplier = float(unknown_class_multipliers.get(label_name, 1.0))
                if unknown_count_policy == "sum_known":
                    target_counts = tuple(int(round(v * multiplier)) for v in counts)
                else:
                    target_counts = tuple(int(round((v / divisor) * multiplier)) for v in counts)
                unknown_distribution[(label_name, condition_key)] = target_counts  # type: ignore[assignment]

    for key, counts in unknown_distribution.items():
        label_name, condition_key = key
        if label_name not in unknown_sim_class_names:
            continue
        multiplier = float(unknown_class_multipliers.get(label_name, 1.0))
        scaled_counts = tuple(int(round(v * multiplier)) for v in counts)
        for split_name, target_count in zip(("train", "val", "test"), scaled_counts):
            drawn = _draw_sim_windows_for_split(
                label_name=label_name,
                condition_key=condition_key,
                target_count=target_count,
                split_name=split_name,
                sim_groups=sim_groups,
                used_by_label=used_sim_by_label,
                rng=rng,
                replacement=replacement,
                fallback_stats=fallback_stats,
                logger=logger,
            )
            split_buckets[split_name].extend(drawn)
            split_all[split_name].extend(drawn)

    rng.shuffle(train_indices)
    rng.shuffle(val_indices)
    rng.shuffle(test_indices)
    _assert_no_real_unknown_windows(records, train_indices, unknown_real_class_names, "condition mirrored train")
    _assert_no_real_unknown_windows(records, val_indices, unknown_real_class_names, "condition mirrored val")

    for split_name, indices in (("real_known_train", real_known_train), ("real_known_val", real_known_val), ("real_known_test", real_known_test)):
        logger.info("[condition_mirrored_split] %s=%s", split_name, summarize_window_indices_by_label(records, indices))
    for split_name, indices in (
        ("real_unknown_train_shadow", real_unknown_train_shadow),
        ("real_unknown_val_shadow", real_unknown_val_shadow),
        ("real_unknown_test", real_unknown_test),
    ):
        logger.info("[condition_mirrored_split] %s=%s", split_name, summarize_window_indices_by_label(records, indices))
    for split_name, indices in (("sim_train", sim_train), ("sim_val", sim_val), ("sim_test", sim_test)):
        logger.info("[condition_mirrored_split] %s=%s", split_name, summarize_window_indices_by_label(records, indices))
        logger.info(
            "[condition_mirrored_split] %s condition_distribution=%s",
            split_name,
            _summarize_window_indices_by_label_condition(records, indices, speed_bin_size, use_load, load_bin_size),
        )
    for split_name, indices in (("train", train_indices), ("val", val_indices), ("test", test_indices)):
        logger.info("[condition_mirrored_split] %s total=%s", split_name, summarize_window_indices_by_label(records, indices))
    logger.info("[condition_mirrored_split] fallback_stats=%s, replacement=%s", fallback_stats, replacement)
    logger.info(
        "[condition_mirrored_split] real unknown shadow split enabled=%s; rebuild cache is required after changing split logic",
        split_real_unknown_as_shadow,
    )

    return {
        "train": train_indices,
        "val": val_indices,
        "test": test_indices,
        "real_known_train": real_known_train,
        "real_known_val": real_known_val,
        "real_known_test": real_known_test,
        "real_unknown_train_shadow": real_unknown_train_shadow,
        "real_unknown_val_shadow": real_unknown_val_shadow,
        "real_unknown_test": real_unknown_test,
        "sim_train": sim_train,
        "sim_val": sim_val,
        "sim_test": sim_test,
    }


def split_window_indices_by_condition(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 3407,
    real_unknown_classes: Sequence[str] = ("ITSC", "tuici"),
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """
    Split windows inside each exact operating condition.

    One condition is (domain, label, load, speed). Real unknown-class train/val
    windows are stored as holdout only and are never returned in effective
    train/val splits used by training, validation, scaler fitting, or alignment.
    The membership split is contiguous in record/window order to avoid random
    mixing of overlapping windows across train/val/test.
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "split ratios must sum to 1"
    rng = random.Random(seed)
    logger = logger or logging.getLogger(__name__)
    real_unknown_set = {str(name) for name in real_unknown_classes}

    grouped: Dict[Tuple[Any, ...], List[WindowIndex]] = {}
    for record_idx, window_idx in window_indices:
        record = records[int(record_idx)]
        key = _exact_condition_key_for_record(record)
        grouped.setdefault(key, []).append((int(record_idx), int(window_idx)))

    train_indices: List[WindowIndex] = []
    val_indices: List[WindowIndex] = []
    test_indices: List[WindowIndex] = []
    real_unknown_train_holdout: List[WindowIndex] = []
    real_unknown_val_holdout: List[WindowIndex] = []
    real_unknown_test: List[WindowIndex] = []
    condition_summaries: List[Dict[str, Any]] = []

    for key in sorted(grouped.keys(), key=lambda item: tuple("" if part is None else str(part) for part in item)):
        group = list(grouped[key])
        part_train, part_val, part_test = _split_one_window_group(group, train_ratio, val_ratio, test_ratio)

        domain_name, label_name, load, speed = key
        is_real_unknown = domain_name == "real" and label_name in real_unknown_set
        if is_real_unknown:
            real_unknown_train_holdout.extend(part_train)
            real_unknown_val_holdout.extend(part_val)
            real_unknown_test.extend(part_test)
        else:
            train_indices.extend(part_train)
            val_indices.extend(part_val)
        test_indices.extend(part_test)

        condition_summaries.append({
            "domain_name": domain_name,
            "label_name": label_name,
            "load": load,
            "speed": speed,
            "num_windows": len(group),
            "train": len(part_train),
            "val": len(part_val),
            "test": len(part_test),
            "held_out_from_train_val": bool(is_real_unknown),
        })

    rng.shuffle(train_indices)
    rng.shuffle(val_indices)
    rng.shuffle(test_indices)

    _assert_no_real_unknown_windows(records, train_indices, real_unknown_classes, "by_condition train")
    _assert_no_real_unknown_windows(records, val_indices, real_unknown_classes, "by_condition val")

    logger.info(
        "[by_condition_split] train=%d, val=%d, test=%d, "
        "real_unknown_train_holdout=%d, real_unknown_val_holdout=%d, real_unknown_test=%d, conditions=%d",
        len(train_indices),
        len(val_indices),
        len(test_indices),
        len(real_unknown_train_holdout),
        len(real_unknown_val_holdout),
        len(real_unknown_test),
        len(condition_summaries),
    )
    for split_name, indices in (
        ("train", train_indices),
        ("val", val_indices),
        ("test", test_indices),
        ("real_unknown_train_holdout", real_unknown_train_holdout),
        ("real_unknown_val_holdout", real_unknown_val_holdout),
        ("real_unknown_test", real_unknown_test),
    ):
        logger.info("[by_condition_split] %s=%s", split_name, summarize_window_indices_by_label(records, indices))

    return {
        "train": train_indices,
        "val": val_indices,
        "test": test_indices,
        "real_unknown_train_holdout": real_unknown_train_holdout,
        "real_unknown_val_holdout": real_unknown_val_holdout,
        "real_unknown_test": real_unknown_test,
        "condition_summaries": condition_summaries,
    }


def stratified_split_window_indices(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    train_ratio: float = 0.7,
    val_ratio: float = 0.2,
    test_ratio: float = 0.1,
    seed: int = 3407,
    group_by: Sequence[str] = ("domain_name", "label_name"),
) -> Dict[str, List[WindowIndex]]:
    """按窗口索引做分层 train/val/test 划分。"""
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "划分比例必须和为 1"
    rng = random.Random(seed)

    grouped: Dict[Tuple[Any, ...], List[WindowIndex]] = {}
    for record_idx, window_idx in window_indices:
        record = records[int(record_idx)]
        key = tuple(getattr(record, field) for field in group_by)
        grouped.setdefault(key, []).append((int(record_idx), int(window_idx)))

    train_indices: List[WindowIndex] = []
    val_indices: List[WindowIndex] = []
    test_indices: List[WindowIndex] = []

    for _, group in grouped.items():
        group = list(group)
        rng.shuffle(group)
        n_train, n_val, n_test = _compute_window_split_counts(len(group), train_ratio, val_ratio, test_ratio)
        train_indices.extend(group[:n_train])
        val_indices.extend(group[n_train:n_train + n_val])
        test_indices.extend(group[n_train + n_val:n_train + n_val + n_test])

    return {
        "train": train_indices,
        "val": val_indices,
        "test": test_indices,
    }


def split_real_unknown_tuici_windows(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
    unknown_cfg: Optional[Dict[str, Any]] = None,
    seed: int = 3407,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, List[WindowIndex]]:
    """剥离真实域高速未知故障窗口，并抽取指定比例作为最终未知测试。"""
    logger = logger or logging.getLogger(__name__)
    unknown_cfg = unknown_cfg or {}
    if not bool(unknown_cfg.get("enabled", False)):
        return {"known_indices": list(window_indices), "unknown_test_indices": []}

    target_labels = set(unknown_cfg.get("labels", ["tuici"]))
    target_domain = str(unknown_cfg.get("domain", "real"))
    target_speeds = {int(round(float(speed))) for speed in unknown_cfg.get("speeds", [600, 700, 800, 900, 1000])}
    test_ratio = float(unknown_cfg.get("test_ratio", 0.2))
    rng = random.Random(seed)

    known_indices: List[WindowIndex] = []
    candidate_unknown_indices: List[WindowIndex] = []

    for record_idx, window_idx in window_indices:
        record = records[int(record_idx)]
        speed = None if record.speed is None else int(round(float(record.speed)))
        is_unknown_candidate = (
            record.domain_name == target_domain
            and record.label_name in target_labels
            and speed in target_speeds
        )

        if is_unknown_candidate:
            candidate_unknown_indices.append((int(record_idx), int(window_idx)))
        else:
            known_indices.append((int(record_idx), int(window_idx)))

    candidate_unknown_indices = list(candidate_unknown_indices)
    rng.shuffle(candidate_unknown_indices)
    n_unknown_test = int(round(len(candidate_unknown_indices) * test_ratio))
    if len(candidate_unknown_indices) > 0:
        n_unknown_test = max(1, n_unknown_test)
    unknown_test_indices = candidate_unknown_indices[:n_unknown_test]

    logger.info(
        f"[真实未知窗口测试集] domain={target_domain}, labels={sorted(target_labels)}, "
        f"speeds={sorted(target_speeds)}, candidates={len(candidate_unknown_indices)}, "
        f"test_ratio={test_ratio:g}, unknown_test={len(unknown_test_indices)}"
    )

    return {
        "known_indices": known_indices,
        "unknown_test_indices": unknown_test_indices,
    }


def summarize_window_indices_by_label(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
) -> Dict[str, Dict[str, int]]:
    """按 domain/label 汇总窗口数量。"""
    summary: Dict[str, Dict[str, int]] = {}
    for record_idx, _ in window_indices:
        record = records[int(record_idx)]
        domain_summary = summary.setdefault(record.domain_name, {})
        domain_summary[record.label_name] = domain_summary.get(record.label_name, 0) + 1
    return summary


def get_records_for_window_indices(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
) -> List[FileRecord]:
    """提取窗口索引涉及的唯一 FileRecord，用于拟合 scaler。"""
    seen = set()
    selected: List[FileRecord] = []
    for record_idx, _ in window_indices:
        record_idx = int(record_idx)
        if record_idx in seen:
            continue
        seen.add(record_idx)
        selected.append(records[record_idx])
    return selected


def _record_condition_key(record: FileRecord) -> Tuple[Optional[float], Optional[float]]:
    load = None if record.load is None else float(record.load)
    speed = None if record.speed is None else float(record.speed)
    return load, speed


def _is_condition(record: FileRecord, *, label_name: str, load: float, speed: float) -> bool:
    record_load, record_speed = _record_condition_key(record)
    return bool(
        record.domain_name == "real"
        and record.label_name == label_name
        and record_load is not None
        and record_speed is not None
        and abs(float(record_load) - float(load)) < 1.0e-6
        and abs(float(record_speed) - float(speed)) < 1.0e-6
    )


def _indices_by_record(window_indices: Sequence[WindowIndex]) -> Dict[int, List[WindowIndex]]:
    grouped: Dict[int, List[WindowIndex]] = {}
    for record_idx, window_idx in window_indices:
        grouped.setdefault(int(record_idx), []).append((int(record_idx), int(window_idx)))
    for record_idx in list(grouped.keys()):
        grouped[record_idx] = sorted(grouped[record_idx], key=lambda item: int(item[1]))
    return grouped


def _condition_label(record: FileRecord) -> str:
    load = "nan" if record.load is None else f"{float(record.load):g}Nm"
    speed = "nan" if record.speed is None else f"{int(round(float(record.speed)))}rpm"
    return f"{load}/{speed}"


def _summarize_itsc_conditions(
    records: Sequence[FileRecord],
    window_indices: Sequence[WindowIndex],
) -> Dict[str, Dict[str, int]]:
    record_windows = _indices_by_record(window_indices)
    summary: Dict[str, Dict[str, int]] = {}
    for record_idx, indices in sorted(record_windows.items()):
        record = records[int(record_idx)]
        if record.domain_name != "real" or record.label_name != "ITSC":
            continue
        key = _condition_label(record)
        item = summary.setdefault(key, {"records": 0, "windows": 0})
        item["records"] += 1
        item["windows"] += len(indices)
    return dict(sorted(summary.items(), key=lambda item: item[0]))


def build_operational_boundary_excluded_indices(
    records: Sequence[FileRecord],
    real_test_unknown2_indices: Sequence[WindowIndex],
    real_test_known3_indices: Sequence[WindowIndex],
    supplement_holdout_indices: Sequence[WindowIndex],
    *,
    random_seed: int = 2026,
) -> Tuple[List[WindowIndex], List[WindowIndex], Dict[str, Any]]:
    """
    Build an additional operational-boundary-excluded evaluation view.

    Only real ITSC 0Nm/500rpm test slices are removed. The same number of
    evaluation record groups is supplemented from real ITSC holdout slices that
    have never been used by train/val/scaler/reference/threshold selection.
    """
    rng = random.Random(int(random_seed))
    unknown_by_record = _indices_by_record(real_test_unknown2_indices)
    holdout_by_record = _indices_by_record(supplement_holdout_indices)
    known_indices = [(int(record_idx), int(window_idx)) for record_idx, window_idx in real_test_known3_indices]

    removed_record_indices = sorted(
        record_idx
        for record_idx in unknown_by_record
        if _is_condition(records[int(record_idx)], label_name="ITSC", load=0.0, speed=500.0)
    )
    removed_set = set(removed_record_indices)

    kept_unknown_record_indices = [
        record_idx
        for record_idx in sorted(unknown_by_record)
        if record_idx not in removed_set
    ]

    candidate_by_condition: Dict[Tuple[float, float], List[Tuple[int, List[WindowIndex]]]] = {}
    for record_idx, indices in holdout_by_record.items():
        record = records[int(record_idx)]
        if record.domain_name != "real" or record.label_name != "ITSC":
            continue
        load, speed = _record_condition_key(record)
        if load is None or speed is None:
            continue
        if abs(float(load) - 0.0) < 1.0e-6 and abs(float(speed) - 500.0) < 1.0e-6:
            continue
        candidate_by_condition.setdefault((float(load), float(speed)), []).append((int(record_idx), list(indices)))

    for condition in list(candidate_by_condition.keys()):
        values = list(candidate_by_condition[condition])
        rng.shuffle(values)
        candidate_by_condition[condition] = values

    removed_groups = [
        (record_idx, unknown_by_record[int(record_idx)])
        for record_idx in removed_record_indices
    ]
    need_records = len(removed_groups)
    need_windows_total = sum(len(indices) for _, indices in removed_groups)
    available_records = sum(1 for values in candidate_by_condition.values() for _, indices in values if len(indices) > 0)
    available_windows = sum(len(indices) for values in candidate_by_condition.values() for _, indices in values)
    if available_records < need_records or available_windows < need_windows_total:
        raise RuntimeError(
            "operational_boundary_excluded_test supplement shortage: "
            f"need_records={need_records}, available_records={available_records}, "
            f"need_windows={need_windows_total}, available_windows={available_windows}, replacement_sampling=false"
        )

    selected_supplement: List[Tuple[int, List[WindowIndex]]] = []
    condition_order = sorted(candidate_by_condition.keys(), key=lambda item: (item[0], item[1]))
    cursor = 0
    for _, removed_indices in removed_groups:
        need_windows = len(removed_indices)
        progressed = False
        for offset in range(len(condition_order)):
            condition = condition_order[(cursor + offset) % len(condition_order)]
            pool = candidate_by_condition.get(condition, [])
            if not pool:
                continue
            record_idx, candidate_indices = pool.pop(0)
            if len(candidate_indices) < need_windows:
                continue
            selected_supplement.append((record_idx, candidate_indices[:need_windows]))
            cursor = (cursor + offset + 1) % len(condition_order)
            progressed = True
            break
        if not progressed:
            raise RuntimeError(
                "operational_boundary_excluded_test supplement failed without replacement: "
                f"need_windows_for_group={need_windows}"
            )

    if len(selected_supplement) != need_records:
        raise RuntimeError(
            "operational_boundary_excluded_test supplement failed without replacement: "
            f"need_records={need_records}, selected={len(selected_supplement)}"
        )

    final_unknown_records = [
        record_idx
        for record_idx in kept_unknown_record_indices
    ]
    final_unknown_indices: List[WindowIndex] = []
    for record_idx in final_unknown_records:
        final_unknown_indices.extend(unknown_by_record[int(record_idx)])
    for _, indices in selected_supplement:
        final_unknown_indices.extend(indices)

    final_all5_indices = known_indices + final_unknown_indices

    removed_windows = sum(len(unknown_by_record[idx]) for idx in removed_record_indices)
    added_windows = sum(len(indices) for _, indices in selected_supplement)
    final_itsc_record_groups = [
        record_idx
        for record_idx in final_unknown_records
        if records[int(record_idx)].domain_name == "real" and records[int(record_idx)].label_name == "ITSC"
    ]
    final_itsc_windows = sum(
        1
        for record_idx, _ in final_unknown_indices
        if records[int(record_idx)].domain_name == "real" and records[int(record_idx)].label_name == "ITSC"
    )

    supplement_conditions = sorted({_condition_label(records[int(idx)]) for idx, _ in selected_supplement})
    audit = {
        "removed_condition": "ITSC / 0Nm / 500rpm",
        "removed_records_count": int(len(removed_record_indices)),
        "removed_windows_count": int(removed_windows),
        "added_records_count": int(len(selected_supplement)),
        "added_windows_count": int(added_windows),
        "final_itsc_records_count": int(len(final_itsc_record_groups) + len(selected_supplement)),
        "final_itsc_record_groups_count": int(len(final_itsc_record_groups) + len(selected_supplement)),
        "final_itsc_source_files_count": int(len({int(record_idx) for record_idx, _ in final_unknown_indices if records[int(record_idx)].label_name == "ITSC"})),
        "final_itsc_windows_count": int(final_itsc_windows),
        "itsc_condition_counts": _summarize_itsc_conditions(records, final_unknown_indices),
        "replacement_sampling": False,
        "random_seed": int(random_seed),
        "supplement_source_conditions": supplement_conditions,
        "removed_records": [
            {
                "record_idx": int(idx),
                "filename": records[int(idx)].filename,
                "file_path": records[int(idx)].file_path,
                "load": None if records[int(idx)].load is None else float(records[int(idx)].load),
                "speed": None if records[int(idx)].speed is None else float(records[int(idx)].speed),
                "num_windows": int(len(unknown_by_record[int(idx)])),
            }
            for idx in removed_record_indices
        ],
        "added_records": [
            {
                "record_idx": int(idx),
                "filename": records[int(idx)].filename,
                "file_path": records[int(idx)].file_path,
                "load": None if records[int(idx)].load is None else float(records[int(idx)].load),
                "speed": None if records[int(idx)].speed is None else float(records[int(idx)].speed),
                "num_windows": int(len(indices)),
                "window_indices": [int(window_idx) for _, window_idx in indices],
            }
            for idx, indices in selected_supplement
        ],
        "leakage_audit": {
            "forbidden_real_unknown_used": False,
            "real_unknown_used_for_training": False,
            "real_unknown_used_for_scaler": False,
            "real_unknown_used_for_reference": False,
            "real_unknown_used_for_threshold": False,
            "real_unknown_used_for_model_selection": False,
        },
    }
    return final_unknown_indices, final_all5_indices, audit


class DomainClassConditionBatchSampler(BatchSampler):
    """Balanced sampler for Stage2/3 train batches with condition-wise sim/real pairs."""

    def __init__(
        self,
        dataset,
        batch_size: int,
        known_classes: Sequence[str] = ("health", "OPF", "Sensor"),
        unknown_sim_classes: Sequence[str] = ("ITSC", "tuici"),
        speed_bin_size: float = 100.0,
        use_load: bool = True,
        load_bin_size: float = 0.5,
        known_pair_per_class: int = 2,
        unknown_per_class: int = 2,
        num_conditions_per_batch: int = 1,
        fill_remaining: bool = True,
        replacement: bool = True,
        drop_last: bool = False,
        max_batches_per_epoch: Optional[int] = None,
        seed: int = 3407,
        logger: Optional[logging.Logger] = None,
        log_first_n_batches: int = 0,
    ):
        self.dataset = dataset
        self.batch_size = int(batch_size)
        self.known_classes = tuple(str(name) for name in known_classes)
        self.unknown_sim_classes = tuple(str(name) for name in unknown_sim_classes)
        self.speed_bin_size = float(speed_bin_size)
        self.use_load = bool(use_load)
        self.load_bin_size = float(load_bin_size)
        self.known_pair_per_class = int(known_pair_per_class)
        self.unknown_per_class = int(unknown_per_class)
        self.num_conditions_per_batch = max(1, int(num_conditions_per_batch))
        self.fill_remaining = bool(fill_remaining)
        self.replacement = bool(replacement)
        self.drop_last = bool(drop_last)
        self.max_batches_per_epoch = max_batches_per_epoch
        self.seed = int(seed)
        self.logger = logger or logging.getLogger(__name__)
        self.log_first_n_batches = int(log_first_n_batches)
        self.epoch = 0
        self.fallback_count = 0
        self.skipped_real_unknown = 0

        if self.batch_size <= 0:
            raise ValueError("batch_size must be positive")
        self.pools: Dict[Tuple[str, str, Tuple[float, ...]], List[int]] = {}
        self.condition_keys: List[Tuple[float, ...]] = []
        self._build_pools()
        if not self.condition_keys:
            raise ValueError("DomainClassConditionBatchSampler has no usable condition groups")

        self.samples_per_condition = (
            2 * len(self.known_classes) * self.known_pair_per_class
            + len(self.unknown_sim_classes) * self.unknown_per_class
        )
        if not self.fill_remaining and self.samples_per_condition * self.num_conditions_per_batch != self.batch_size:
            raise ValueError(
                "When fill_remaining=false, batch_size must equal "
                "samples_per_condition * num_conditions_per_batch"
            )
        if self.samples_per_condition * self.num_conditions_per_batch > self.batch_size:
            raise ValueError(
                "Required per-condition quota exceeds batch_size; reduce quotas or num_conditions_per_batch"
            )

        if self.max_batches_per_epoch is None:
            n = len(dataset) // max(1, self.batch_size)
            if not self.drop_last and len(dataset) % max(1, self.batch_size):
                n += 1
            self.max_batches_per_epoch = max(1, n)
        else:
            self.max_batches_per_epoch = int(self.max_batches_per_epoch)

        pool_sizes = {str(key): len(value) for key, value in sorted(self.pools.items(), key=lambda item: str(item[0]))}
        self.logger.info(
            "[balanced_condition_sampler] enabled=True, batch_size=%s, known_classes=%s, "
            "unknown_sim_classes=%s, speed_bin_size=%s, use_load=%s, load_bin_size=%s, "
            "num_conditions_per_batch=%s, known_pair_per_class=%s, unknown_per_class=%s, "
            "available_condition_keys=%s, skipped_real_unknown=%s",
            self.batch_size,
            self.known_classes,
            self.unknown_sim_classes,
            self.speed_bin_size,
            self.use_load,
            self.load_bin_size,
            self.num_conditions_per_batch,
            self.known_pair_per_class,
            self.unknown_per_class,
            len(self.condition_keys),
            self.skipped_real_unknown,
        )
        self.logger.info("[balanced_condition_sampler] pool sizes: %s", json.dumps(pool_sizes, ensure_ascii=False))

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def _records(self) -> Sequence[FileRecord]:
        return getattr(self.dataset, "file_records")

    def _record_index_for_dataset_idx(self, dataset_idx: int) -> int:
        dataset_idx = int(dataset_idx)
        if hasattr(self.dataset, "window_indices"):
            record_idx, _ = self.dataset.window_indices[dataset_idx]
            return int(record_idx)
        if hasattr(self.dataset, "index_map"):
            record_idx, _, _ = self.dataset.index_map[dataset_idx]
            return int(record_idx)
        raise AttributeError("dataset must expose window_indices or index_map")

    def _condition_key_for_record(self, record: FileRecord) -> Optional[Tuple[float, ...]]:
        return make_condition_key(
            record,
            speed_bin_size=self.speed_bin_size,
            use_load=self.use_load,
            load_bin_size=self.load_bin_size,
        )

    def _build_pools(self) -> None:
        known_set = set(self.known_classes)
        unknown_set = set(self.unknown_sim_classes)
        condition_candidates = set()
        for dataset_idx in range(len(self.dataset)):
            record_idx = self._record_index_for_dataset_idx(dataset_idx)
            record = self._records()[record_idx]
            if record.domain_name == "real" and record.label_name in unknown_set:
                self.skipped_real_unknown += 1
                continue
            if record.domain_name == "real":
                if int(getattr(record, "trainable_in_real", 0)) != 1 or record.label_name not in known_set:
                    continue
            elif record.domain_name == "sim":
                if record.label_name not in known_set.union(unknown_set):
                    continue
            else:
                continue

            condition_key = self._condition_key_for_record(record)
            if condition_key is None:
                continue
            self.pools.setdefault((record.domain_name, record.label_name, condition_key), []).append(int(dataset_idx))
            condition_candidates.add(condition_key)

        usable = []
        for condition_key in condition_candidates:
            ok = True
            for label_name in self.known_classes:
                ok = ok and bool(self.pools.get(("real", label_name, condition_key)))
                ok = ok and bool(self.pools.get(("sim", label_name, condition_key)))
            for label_name in self.unknown_sim_classes:
                ok = ok and bool(self.pools.get(("sim", label_name, condition_key)))
            if ok:
                usable.append(condition_key)
        self.condition_keys = sorted(usable, key=lambda key: tuple(float(v) for v in key))

    def _nearest_condition_key(self, domain_name: str, label_name: str, condition_key: Tuple[float, ...]) -> Optional[Tuple[float, ...]]:
        candidates = [
            key[2]
            for key, values in self.pools.items()
            if key[0] == domain_name and key[1] == label_name and values
        ]
        if not candidates:
            return None
        return min(candidates, key=lambda candidate: _condition_distance(condition_key, candidate))

    def _draw_from_group(
        self,
        rng: random.Random,
        domain_name: str,
        label_name: str,
        condition_key: Tuple[float, ...],
        n: int,
    ) -> List[int]:
        if n <= 0:
            return []
        pool = list(self.pools.get((domain_name, label_name, condition_key), []))
        if not pool:
            nearest = self._nearest_condition_key(domain_name, label_name, condition_key)
            if nearest is not None:
                pool = list(self.pools.get((domain_name, label_name, nearest), []))
                self.fallback_count += n
        if not pool:
            pool = [
                idx
                for key, values in self.pools.items()
                if key[0] == domain_name and key[1] == label_name
                for idx in values
            ]
            self.fallback_count += n
        if not pool:
            return []
        if self.replacement:
            return [rng.choice(pool) for _ in range(n)]
        if len(pool) >= n:
            return rng.sample(pool, n)
        self.fallback_count += n - len(pool)
        return list(pool)

    def _draw_fill(self, rng: random.Random, batch: List[int], n: int, condition_keys: Sequence[Tuple[float, ...]]) -> None:
        if n <= 0:
            return
        allowed = []
        for condition_key in condition_keys:
            for key, values in self.pools.items():
                if key[2] == condition_key:
                    allowed.extend(values)
        if not allowed:
            allowed = [idx for values in self.pools.values() for idx in values]
        if not allowed:
            return
        if self.replacement:
            batch.extend(rng.choice(allowed) for _ in range(n))
        else:
            candidates = [idx for idx in allowed if idx not in set(batch)]
            batch.extend(rng.sample(candidates, min(n, len(candidates))))

    def _validate_batch(self, batch: Sequence[int]) -> None:
        unknown_set = set(self.unknown_sim_classes)
        leaked = []
        for dataset_idx in batch:
            record_idx = self._record_index_for_dataset_idx(int(dataset_idx))
            record = self._records()[record_idx]
            if record.domain_name == "real" and record.label_name in unknown_set:
                leaked.append((int(dataset_idx), record.label_name))
        if leaked:
            raise RuntimeError(f"real unknown samples leaked into balanced sampler batch: {leaked[:5]}")

    def __iter__(self):
        rng = random.Random(self.seed + self.epoch)
        condition_order = list(self.condition_keys)
        rng.shuffle(condition_order)
        cursor = 0

        for batch_idx in range(int(self.max_batches_per_epoch)):
            selected_conditions = []
            for _ in range(self.num_conditions_per_batch):
                if cursor >= len(condition_order):
                    rng.shuffle(condition_order)
                    cursor = 0
                selected_conditions.append(condition_order[cursor])
                cursor += 1

            batch: List[int] = []
            for condition_key in selected_conditions:
                for label_name in self.known_classes:
                    batch.extend(self._draw_from_group(rng, "real", label_name, condition_key, self.known_pair_per_class))
                    batch.extend(self._draw_from_group(rng, "sim", label_name, condition_key, self.known_pair_per_class))
                for label_name in self.unknown_sim_classes:
                    batch.extend(self._draw_from_group(rng, "sim", label_name, condition_key, self.unknown_per_class))

            if self.fill_remaining and len(batch) < self.batch_size:
                self._draw_fill(rng, batch, self.batch_size - len(batch), selected_conditions)
            if len(batch) > self.batch_size:
                batch = batch[: self.batch_size]
            if self.drop_last and len(batch) < self.batch_size:
                continue
            rng.shuffle(batch)
            self._validate_batch(batch)
            if self.log_first_n_batches > 0 and batch_idx < self.log_first_n_batches:
                self._log_batch(batch_idx, batch, selected_conditions)
            yield batch
        self.epoch += 1

    def _log_batch(self, batch_idx: int, batch: Sequence[int], condition_keys: Sequence[Tuple[float, ...]]) -> None:
        condition_counts: Dict[str, int] = {}
        domain_label_counts: Dict[str, Dict[str, int]] = {}
        for dataset_idx in batch:
            record_idx = self._record_index_for_dataset_idx(int(dataset_idx))
            record = self._records()[record_idx]
            condition_key = self._condition_key_for_record(record)
            condition_counts[str(condition_key)] = condition_counts.get(str(condition_key), 0) + 1
            domain_label_counts.setdefault(record.domain_name, {})
            domain_label_counts[record.domain_name][record.label_name] = domain_label_counts[record.domain_name].get(record.label_name, 0) + 1

        has_groups = {}
        for label_name in self.known_classes:
            has_groups[f"real+sim {label_name}"] = (
                domain_label_counts.get("real", {}).get(label_name, 0) > 0
                and domain_label_counts.get("sim", {}).get(label_name, 0) > 0
            )
        for label_name in self.unknown_sim_classes:
            has_groups[f"sim {label_name}"] = domain_label_counts.get("sim", {}).get(label_name, 0) > 0

        self.logger.info(
            "[balanced_condition_sampler] batch=%s, conditions=%s, domain_label_counts=%s, "
            "condition_counts=%s, has_groups=%s, fallback_count=%s",
            batch_idx,
            list(condition_keys),
            domain_label_counts,
            condition_counts,
            has_groups,
            self.fallback_count,
        )

    def __len__(self) -> int:
        return int(self.max_batches_per_epoch)


def build_balanced_condition_dataloader(
    dataset,
    batch_size: int,
    num_workers: int,
    pin_memory: bool = True,
    drop_last: bool = False,
    sampler_cfg: Optional[Dict[str, Any]] = None,
    seed: int = 3407,
    logger: Optional[logging.Logger] = None,
) -> DataLoader:
    sampler_cfg = sampler_cfg or {}
    if not bool(sampler_cfg.get("enabled", True)):
        return build_dataloader(
            dataset=dataset,
            batch_size=batch_size,
            num_workers=num_workers,
            pin_memory=pin_memory,
            shuffle=True,
            drop_last=drop_last,
        )

    batch_sampler = DomainClassConditionBatchSampler(
        dataset=dataset,
        batch_size=batch_size,
        known_classes=sampler_cfg.get("known_classes", ("health", "OPF", "Sensor")),
        unknown_sim_classes=sampler_cfg.get("unknown_sim_classes", ("ITSC", "tuici")),
        speed_bin_size=float(sampler_cfg.get("speed_bin_size", 100.0)),
        use_load=bool(sampler_cfg.get("use_load", True)),
        load_bin_size=float(sampler_cfg.get("load_bin_size", 0.5)),
        known_pair_per_class=int(sampler_cfg.get("known_pair_per_class", 2)),
        unknown_per_class=int(sampler_cfg.get("unknown_per_class", 2)),
        num_conditions_per_batch=int(sampler_cfg.get("num_conditions_per_batch", 1)),
        fill_remaining=bool(sampler_cfg.get("fill_remaining", True)),
        replacement=bool(sampler_cfg.get("replacement", True)),
        drop_last=drop_last,
        max_batches_per_epoch=sampler_cfg.get("max_batches_per_epoch", None),
        seed=seed,
        logger=logger,
        log_first_n_batches=int(sampler_cfg.get("log_first_n_batches", 0)),
    )
    return DataLoader(
        dataset,
        batch_sampler=batch_sampler,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=fault_diagnosis_collate_fn,
    )


# =========================
def get_dataset_cache_paths(config: Dict[str, Any]) -> Dict[str, str]:
    """根据配置返回统一数据划分缓存路径。"""
    data_cfg = config.get("data", {})
    cache_dir = str(data_cfg.get("cache_dir", "./dataset_cache"))
    split_cache_name = str(data_cfg.get("split_cache_name", "split_records.pkl"))
    split_meta_name = str(data_cfg.get("split_meta_name", "split_meta.json"))
    return {
        "cache_dir": cache_dir,
        "split_cache": os.path.join(cache_dir, split_cache_name),
        "split_meta": os.path.join(cache_dir, split_meta_name),
    }


def build_split_cache_meta(config: Dict[str, Any]) -> Dict[str, Any]:
    """提取会影响 CSV 处理和 train/val/test 划分的配置，用于判断缓存是否过期。"""
    data_cfg = config.get("data", {})
    paths_cfg = config.get("paths", {})
    return {
        "data_root": str(paths_cfg.get("data_root", "./data")),
        "window_size": int(data_cfg.get("window_size", 2000)),
        "stride": int(data_cfg.get("stride", 1000)),
        "recursive": bool(data_cfg.get("recursive", True)),
        "train_ratio": float(data_cfg.get("train_ratio", 0.7)),
        "val_ratio": float(data_cfg.get("val_ratio", 0.2)),
        "test_ratio": float(data_cfg.get("test_ratio", 0.1)),
        "split_strategy": str(data_cfg.get("split_strategy", "by_file")),
        "split_semantics_version": 4,
        "condition_split_key": ["domain_name", "label_name", "load", "speed"],
        "real_unknown_train_val_policy": "holdout_not_used_for_training_or_validation",
        "random_seed": int(config.get("random_seed", 3407)),
        "standardize": bool(data_cfg.get("standardize", True)),
        "scaler_eps": float(data_cfg.get("scaler_eps", 1e-6)),
        "speed_filter": copy.deepcopy(data_cfg.get("speed_filter", {})),
        "feature_channels": copy.deepcopy(data_cfg.get("feature_channels", [])),
        "known_real_classes": copy.deepcopy(data_cfg.get("known_real_classes", [])),
        "unknown_real_classes": copy.deepcopy(data_cfg.get("unknown_real_classes", [])),
        "condition_mirrored_split": copy.deepcopy(data_cfg.get("condition_mirrored_split", {})),
        "balanced_condition_sampler": copy.deepcopy(data_cfg.get("balanced_condition_sampler", {})),
    }


def save_split_cache(split_pack: Dict[str, Any], config: Dict[str, Any], logger: logging.Logger) -> None:
    """保存一次性扫描得到的 all_records/split_records，供所有 stage 复用。"""
    cache_paths = get_dataset_cache_paths(config)
    ensure_dir(cache_paths["cache_dir"])
    with open(cache_paths["split_cache"], "wb") as f:
        pickle.dump(split_pack, f, protocol=pickle.HIGHEST_PROTOCOL)
    save_json(build_split_cache_meta(config), cache_paths["split_meta"])
    logger.info(f"数据划分缓存已保存: {cache_paths['split_cache']}")
    logger.info(f"数据划分缓存元信息已保存: {cache_paths['split_meta']}")


def load_split_cache(config: Dict[str, Any], logger: logging.Logger) -> Dict[str, Any]:
    """加载统一数据划分缓存。"""
    cache_paths = get_dataset_cache_paths(config)
    with open(cache_paths["split_cache"], "rb") as f:
        split_pack = pickle.load(f)
    logger.info(f"已加载数据划分缓存: {cache_paths['split_cache']}")
    return split_pack


def is_split_cache_valid(config: Dict[str, Any], logger: logging.Logger) -> bool:
    """检查缓存文件存在且 split_meta 与当前关键配置一致。"""
    cache_paths = get_dataset_cache_paths(config)
    if not os.path.exists(cache_paths["split_cache"]) or not os.path.exists(cache_paths["split_meta"]):
        return False
    try:
        with open(cache_paths["split_meta"], "r", encoding="utf-8") as f:
            cached_meta = json.load(f)
    except Exception as e:
        logger.warning(f"读取数据划分缓存元信息失败，将重建缓存: {e}")
        return False

    current_meta = build_split_cache_meta(config)
    if cached_meta != current_meta:
        logger.warning("数据划分缓存元信息与当前配置不一致，将重建缓存")
        return False
    return True


def get_or_create_split_records(
    config: Dict[str, Any],
    logger: logging.Logger,
    rebuild: Optional[bool] = None
) -> Dict[str, Any]:
    """优先加载统一 split cache；不存在、过期或要求重建时重新扫描并保存。"""
    data_cfg = config.get("data", {})
    use_cached_split = bool(data_cfg.get("use_cached_split", True))
    rebuild_cache = bool(data_cfg.get("rebuild_cache", False)) if rebuild is None else bool(rebuild)

    if use_cached_split and (not rebuild_cache) and is_split_cache_valid(config, logger):
        return load_split_cache(config, logger)

    split_pack = scan_and_split_records(config=config, logger=logger)
    if use_cached_split:
        save_split_cache(split_pack=split_pack, config=config, logger=logger)
    return split_pack


def build_augmentor_for_stage(
    config: Dict[str, Any],
    stage_name: str,
    logger: Optional[logging.Logger] = None,
) -> TimeSeriesAugment:
    """构建训练集增强器；即使 disabled 也返回对象，便于统一记录配置。"""
    augmentor = TimeSeriesAugment(
        config=config,
        channel_names=FEATURE_CHANNELS,
        class_names=[IDX_TO_CLASS[i] for i in range(len(IDX_TO_CLASS))],
    )
    if logger is not None:
        logger.info(f"[{stage_name}] 数据增强配置: {augmentor.describe_stage(stage_name)}")
    return augmentor


def get_dataset_augmentation_counters(dataset) -> Dict[str, Any]:
    """从 Dataset 中提取增强统计，若未启用增强则返回空 dict。"""
    augmentor = getattr(dataset, "augmentor", None)
    if augmentor is None or not hasattr(augmentor, "get_counters"):
        return {}
    return augmentor.get_counters()


# =========================
# 数据准备
# =========================
def scan_and_split_records(
    config: Dict[str, Any],
    logger: logging.Logger
) -> Dict[str, Any]:
    """
    扫描并划分文件记录

    说明：
    - 这里按“文件级”切分 train/val/test，避免同一原始文件的不同窗口泄漏到不同集合
    """
    data_cfg = config["data"]
    paths_cfg = config["paths"]

    all_records = build_file_records(
        data_root=paths_cfg["data_root"],
        window_size=int(data_cfg["window_size"]),
        stride=int(data_cfg["stride"]),
        recursive=bool(data_cfg.get("recursive", True)),
        logger=logger,
    )

    all_records = filter_records_by_speed_whitelist(
        records=all_records,
        speed_filter_cfg=data_cfg.get("speed_filter", {}),
        logger=logger,
    )
    all_records = apply_real_class_policy(
        records=all_records,
        known_real_classes=data_cfg.get("known_real_classes", ["health", "OPF", "Sensor"]),
        unknown_real_classes=data_cfg.get("unknown_real_classes", ["ITSC", "tuici"]),
        logger=logger,
    )

    split_strategy = str(data_cfg.get("split_strategy", "by_file"))

    if split_strategy in {"by_condition", "by_window"}:
        all_window_indices = make_window_indices_for_records(all_records)
        if split_strategy == "by_window":
            logger.warning(
                "split_strategy='by_window' is treated as the safe by_condition split. "
                "Use split_strategy='by_condition' for explicit naming."
            )
        split_records = split_window_indices_by_condition(
            records=all_records,
            window_indices=all_window_indices,
            train_ratio=float(data_cfg["train_ratio"]),
            val_ratio=float(data_cfg["val_ratio"]),
            test_ratio=float(data_cfg["test_ratio"]),
            seed=int(config["random_seed"]),
            real_unknown_classes=data_cfg.get("unknown_real_classes", ["ITSC", "tuici"]),
            logger=logger,
        )
        split_records["all_records"] = all_records
        split_records["split_unit"] = "window"
        split_records["split_strategy"] = split_strategy

        logger.info(
            f"by_condition 窗口划分完成 | train={len(split_records['train'])}, "
            f"val={len(split_records['val'])}, test={len(split_records['test'])}"
        )
        for split_name in ["train", "val", "test"]:
            logger.info(
                f"by_condition split[{split_name}]: "
                f"{summarize_window_indices_by_label(all_records, split_records[split_name])}"
            )
        return {
            "all_records": all_records,
            "split_records": split_records,
            "unknown_test_records": [],
        }

    if split_strategy == "by_window_real_condition_mirrored":
        mirror_cfg = data_cfg.get("condition_mirrored_split", {})
        if not bool(mirror_cfg.get("enabled", True)):
            logger.warning(
                "split_strategy=by_window_real_condition_mirrored but condition_mirrored_split.enabled=false; "
                "falling back to by_window"
            )
            split_strategy = "by_window"
        else:
            all_window_indices = make_window_indices_for_records(all_records)
            split_records = stratified_split_window_indices_real_condition_mirrored(
                records=all_records,
                window_indices=all_window_indices,
                train_ratio=float(data_cfg["train_ratio"]),
                val_ratio=float(data_cfg["val_ratio"]),
                test_ratio=float(data_cfg["test_ratio"]),
                seed=int(config["random_seed"]),
                known_real_class_names=mirror_cfg.get(
                    "known_real_classes",
                    data_cfg.get("known_real_classes", ["health", "OPF", "Sensor"]),
                ),
                unknown_real_class_names=mirror_cfg.get(
                    "unknown_real_classes",
                    data_cfg.get("unknown_real_classes", ["ITSC", "tuici"]),
                ),
                unknown_sim_class_names=mirror_cfg.get("unknown_sim_classes", ["ITSC", "tuici"]),
                speed_bin_size=float(mirror_cfg.get("speed_bin_size", 100.0)),
                use_load=bool(mirror_cfg.get("use_load", True)),
                load_bin_size=float(mirror_cfg.get("load_bin_size", 0.5)),
                replacement=bool(mirror_cfg.get("replacement", False)),
                split_real_unknown_as_shadow=bool(mirror_cfg.get("split_real_unknown_as_shadow", True)),
                mirror_sim_from_real_unknown_shadow=bool(mirror_cfg.get("mirror_sim_from_real_unknown_shadow", True)),
                unknown_count_policy=str(mirror_cfg.get("unknown_count_policy", "mean_known")),
                unknown_class_multipliers=mirror_cfg.get("unknown_class_multipliers", {}),
                logger=logger,
            )
            split_records["all_records"] = all_records
            split_records["split_unit"] = "window"

            logger.info(
                f"condition mirrored 窗口划分完成 | train={len(split_records['train'])}, "
                f"val={len(split_records['val'])}, test={len(split_records['test'])}"
            )
            for split_name in ["train", "val", "test"]:
                logger.info(
                    f"condition mirrored split[{split_name}]: "
                    f"{summarize_window_indices_by_label(all_records, split_records[split_name])}"
                )
            logger.info(
                "condition_mirrored_split 已启用；如修改 split 逻辑或配置，请设置 data.rebuild_cache=true "
                "或删除 dataset_cache 后重建。"
            )
            return {
                "all_records": all_records,
                "split_records": split_records,
                "unknown_test_records": [],
            }

    logger.warning(
        "当前需求推荐 split_strategy='by_condition'；by_file 分支仍保留旧兼容逻辑，"
        "不会严格保证每个工况内独立划分，也不建议用于当前实验。"
    )
    unknown_split = split_unknown_real_test_records(
        records=all_records,
        unknown_cfg=data_cfg.get("unknown_real_test", {}),
        logger=logger,
    )
    split_source_records = unknown_split["known_records"]
    unknown_test_records = unknown_split["unknown_test_records"]

    split_records = stratified_split_records(
        records=split_source_records,
        train_ratio=float(data_cfg["train_ratio"]),
        val_ratio=float(data_cfg["val_ratio"]),
        test_ratio=float(data_cfg["test_ratio"]),
        seed=int(config["random_seed"]),
    )

    split_records["unknown_test"] = unknown_test_records
    split_records["split_unit"] = "file"

    logger.info(
        f"文件划分完成 | train={len(split_records['train'])}, "
        f"val={len(split_records['val'])}, test={len(split_records['test'])}"
    )
    for split_name in ["train", "val", "test"]:
        logger.info(
            f"文件划分统计[{split_name}]: "
            f"{summarize_records_by_label(split_records[split_name])}"
        )

    return {
        "all_records": all_records,
        "split_records": split_records,
        "unknown_test_records": unknown_test_records,
    }


def build_stage_datasets_from_splits(
    config: Dict[str, Any],
    split_records: Dict[str, Any],
    stage_name: str,
    logger: logging.Logger,
    scaler: Optional[ChannelWiseScaler] = None,
    fit_scaler: bool = True
) -> Dict[str, Any]:
    """
    根据已有 split_records 构建指定阶段的数据集

    关键说明：
    - 为了避免真实未知类在标准化统计中造成信息泄漏，
      这里不会简单使用“全部 train 文件”去拟合 scaler
    - Stage1 的 scaler 仅由仿真 train 拟合
    - Stage2 / Stage3 的 scaler 由“仿真 五类 + 真实可见已知类”的 train 拟合

    返回:
        {
          "scaler": scaler,
          "train_dataset": ...,
          "val_dataset": ...,
          "test_datasets": {...}
        }
    """
    data_cfg = config["data"]
    window_size = int(data_cfg["window_size"])
    stride = int(data_cfg["stride"])
    standardize = bool(data_cfg["standardize"])
    scaler_eps = float(data_cfg["scaler_eps"])

    split_unit = split_records.get("split_unit", "file")
    if split_unit == "window":
        all_records = split_records["all_records"]
        train_indices_all = split_records["train"]
        val_indices_all = split_records["val"]
        test_indices_all = split_records["test"]
        known_real_classes = list(data_cfg.get("known_real_classes", ["health", "OPF", "Sensor"]))
        unknown_real_classes = list(data_cfg.get("unknown_real_classes", ["ITSC", "tuici"]))

        if stage_name == "stage1":
            train_indices = filter_window_indices(all_records, train_indices_all, domain_names=["sim"])
            val_indices = filter_window_indices(all_records, val_indices_all, domain_names=["sim"])
            scaler_fit_records = get_records_for_window_indices(all_records, train_indices)
        elif stage_name in ["stage2", "stage3"]:
            train_indices = filter_window_indices(
                all_records,
                train_indices_all,
                domain_names=["sim", "real"],
                real_trainable_only=True,
            )
            val_indices = filter_window_indices(
                all_records,
                val_indices_all,
                domain_names=["sim", "real"],
                real_trainable_only=True,
            )
            scaler_fit_records = get_records_for_window_indices(all_records, train_indices)
            _assert_no_real_unknown_windows(all_records, train_indices, unknown_real_classes, f"{stage_name} train_dataset")
            _assert_no_real_unknown_windows(all_records, val_indices, unknown_real_classes, f"{stage_name} val_dataset")
            _assert_no_real_unknown_records(scaler_fit_records, unknown_real_classes, f"{stage_name} scaler_fit_records")
        elif stage_name == "test":
            train_indices = []
            val_indices = []
            scaler_fit_records = []
        else:
            raise ValueError(f"未知 stage_name: {stage_name}")

        if scaler is None:
            scaler = ChannelWiseScaler(eps=scaler_eps)

        if fit_scaler and standardize and len(scaler_fit_records) > 0:
            scaler.fit(scaler_fit_records)
            logger.info(f"[{stage_name}] 已根据可见训练窗口涉及记录拟合 scaler")

        train_dataset = None
        val_dataset = None
        train_augmentor = None
        if stage_name != "test":
            train_augmentor = build_augmentor_for_stage(config=config, stage_name=stage_name, logger=logger)
            train_dataset = IndexedWindowFaultDataset(
                file_records=all_records,
                window_indices=train_indices,
                window_size=window_size,
                stride=stride,
                scaler=scaler,
                standardize=standardize,
                augmentor=train_augmentor,
                is_train=True,
                stage_name=stage_name,
            )
            val_dataset = IndexedWindowFaultDataset(
                file_records=all_records,
                window_indices=val_indices,
                window_size=window_size,
                stride=stride,
                scaler=scaler,
                standardize=standardize,
                augmentor=None,
                is_train=False,
                stage_name=stage_name,
            )
            logger.info(f"[{stage_name}] train_dataset: {train_dataset.summary()}")
            logger.info(f"[{stage_name}] val_dataset: {val_dataset.summary()}")

        sim_test_indices = filter_window_indices(all_records, test_indices_all, domain_names=["sim"])
        real_test_known3_indices = filter_window_indices(
            all_records,
            test_indices_all,
            domain_names=["real"],
            label_names=known_real_classes,
        )
        real_test_unknown2_indices = list(split_records.get("real_unknown_test", []))
        if not real_test_unknown2_indices:
            real_test_unknown2_indices = filter_window_indices(
                all_records,
                test_indices_all,
                domain_names=["real"],
                label_names=unknown_real_classes,
            )
        real_test_all5_indices = real_test_known3_indices + real_test_unknown2_indices
        operational_audits: Dict[str, Any] = {}
        real_unknown_holdout_indices = list(split_records.get("real_unknown_train_holdout", [])) + list(split_records.get("real_unknown_val_holdout", []))
        if real_unknown_holdout_indices:
            (
                operational_unknown2_indices,
                operational_all5_indices,
                operational_audit,
            ) = build_operational_boundary_excluded_indices(
                records=all_records,
                real_test_unknown2_indices=real_test_unknown2_indices,
                real_test_known3_indices=real_test_known3_indices,
                supplement_holdout_indices=real_unknown_holdout_indices,
                random_seed=2026,
            )
            operational_audits["operational_boundary_excluded_test"] = operational_audit
        else:
            operational_unknown2_indices = []
            operational_all5_indices = []

        test_datasets = {
            "sim_test": IndexedWindowFaultDataset(all_records, sim_test_indices, window_size, stride, scaler=scaler, standardize=standardize),
            "real_test_known3": IndexedWindowFaultDataset(all_records, real_test_known3_indices, window_size, stride, scaler=scaler, standardize=standardize),
            "real_test_unknown2": IndexedWindowFaultDataset(all_records, real_test_unknown2_indices, window_size, stride, scaler=scaler, standardize=standardize),
            "real_test_all5": IndexedWindowFaultDataset(all_records, real_test_all5_indices, window_size, stride, scaler=scaler, standardize=standardize),
            "real_test_all5_final": IndexedWindowFaultDataset(all_records, real_test_all5_indices, window_size, stride, scaler=scaler, standardize=standardize),
        }
        if operational_unknown2_indices and operational_all5_indices:
            test_datasets["operational_boundary_excluded_real_test_unknown2"] = IndexedWindowFaultDataset(
                all_records, operational_unknown2_indices, window_size, stride, scaler=scaler, standardize=standardize
            )
            test_datasets["operational_boundary_excluded_real_test_all5"] = IndexedWindowFaultDataset(
                all_records, operational_all5_indices, window_size, stride, scaler=scaler, standardize=standardize
            )

        for name, ds in test_datasets.items():
            logger.info(f"[{stage_name}] {name}: {ds.summary()}")
        logger.info(
            "[%s] real_test_all5 per-class counts: %s",
            stage_name,
            test_datasets["real_test_all5"].summary().get("label_counter_by_window", {}),
        )

        return {
            "scaler": scaler,
            "train_dataset": train_dataset,
            "val_dataset": val_dataset,
            "test_datasets": test_datasets,
            "test_split_audits": operational_audits,
        }

    train_records_all = split_records["train"]
    val_records_all = split_records["val"]
    test_records_all = split_records["test"]
    unknown_test_records = split_records.get("unknown_test", [])
    known_real_classes = list(data_cfg.get("known_real_classes", ["health", "OPF", "Sensor"]))
    unknown_real_classes = list(data_cfg.get("unknown_real_classes", ["ITSC", "tuici"]))

    if stage_name == "stage1":
        train_records = filter_records(train_records_all, domain_names=["sim"])
        val_records = filter_records(val_records_all, domain_names=["sim"])
        scaler_fit_records = train_records
    elif stage_name in ["stage2", "stage3"]:
        train_records = filter_records(
            train_records_all,
            domain_names=["sim", "real"],
            real_trainable_only=True
        )
        val_records = filter_records(
            val_records_all,
            domain_names=["sim", "real"],
            real_trainable_only=True
        )
        scaler_fit_records = train_records
        _assert_no_real_unknown_records(train_records, unknown_real_classes, f"{stage_name} train_dataset")
        _assert_no_real_unknown_records(val_records, unknown_real_classes, f"{stage_name} val_dataset")
        _assert_no_real_unknown_records(scaler_fit_records, unknown_real_classes, f"{stage_name} scaler_fit_records")
    elif stage_name == "test":
        # test 阶段不重新定义训练集，只返回评估用数据视图
        train_records = []
        val_records = []
        scaler_fit_records = []
    else:
        raise ValueError(f"未知 stage_name: {stage_name}")

    if scaler is None:
        scaler = ChannelWiseScaler(eps=scaler_eps)

    if fit_scaler and standardize and len(scaler_fit_records) > 0:
        scaler.fit(scaler_fit_records)
        logger.info(f"[{stage_name}] 已根据可见训练集拟合 scaler")

    train_dataset = None
    val_dataset = None
    train_augmentor = None

    if stage_name != "test":
        train_augmentor = build_augmentor_for_stage(config=config, stage_name=stage_name, logger=logger)
        train_dataset = WindowedFaultDataset(
            file_records=train_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
            augmentor=train_augmentor,
            is_train=True,
            stage_name=stage_name,
        )

        val_dataset = WindowedFaultDataset(
            file_records=val_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
            augmentor=None,
            is_train=False,
            stage_name=stage_name,
        )

        logger.info(f"[{stage_name}] train_dataset: {train_dataset.summary()}")
        logger.info(f"[{stage_name}] val_dataset: {val_dataset.summary()}")

    # 测试视图
    sim_test_records = filter_records(test_records_all, domain_names=["sim"])
    known_real_classes = list(data_cfg.get("known_real_classes", ["health", "OPF", "Sensor"]))
    unknown_real_classes = list(data_cfg.get("unknown_real_classes", ["ITSC", "tuici"]))
    real_test_known3_records = filter_records(
        test_records_all,
        domain_names=["real"],
        label_names=known_real_classes,
    )
    real_test_unknown2_records = list(unknown_test_records)
    if not real_test_unknown2_records:
        real_test_unknown2_records = filter_records(
            test_records_all,
            domain_names=["real"],
            label_names=unknown_real_classes,
        )
    real_test_all5_records = real_test_known3_records + real_test_unknown2_records

    test_datasets = {
        "sim_test": WindowedFaultDataset(
            file_records=sim_test_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
        ),
        "real_test_known3": WindowedFaultDataset(
            file_records=real_test_known3_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
        ),
        "real_test_unknown2": WindowedFaultDataset(
            file_records=real_test_unknown2_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
        ),
        "real_test_all5": WindowedFaultDataset(
            file_records=real_test_all5_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
        ),
        "real_test_all5_final": WindowedFaultDataset(
            file_records=real_test_all5_records,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=standardize,
        ),
    }

    for name, ds in test_datasets.items():
        logger.info(f"[{stage_name}] {name}: {ds.summary()}")

    return {
        "scaler": scaler,
        "train_dataset": train_dataset,
        "val_dataset": val_dataset,
        "test_datasets": test_datasets,
    }


def save_scaler(scaler: ChannelWiseScaler, save_path: str) -> None:
    """
    保存 scaler
    """
    ensure_dir(os.path.dirname(save_path) if os.path.dirname(save_path) else ".")
    scaler.save_json(save_path)


def load_scaler(load_path: str) -> ChannelWiseScaler:
    """
    加载 scaler
    """
    return ChannelWiseScaler.load_json(load_path)
