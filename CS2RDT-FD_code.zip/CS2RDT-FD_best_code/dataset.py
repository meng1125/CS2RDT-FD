# dataset.py
# -*- coding: utf-8 -*-

"""
数据集模块：
1. 递归扫描 data 根目录下的 CSV 文件
2. 根据文件名优先解析 load / domain / label
3. 自动适配列名别名
4. 将原始 CSV 转成固定 13 通道顺序的多变量时序数据（忽略位置角列）
5. 支持滑动窗口切片
6. 支持按训练集统计量做通道 z-score 标准化
7. 严格标记真实域中可参与训练的 4 类，避免 real_tuici / real_zhoucheng 泄漏到训练
"""

import os
import re
import json
import random
import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Any, Sequence

WindowIndex = Tuple[int, int]

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


# =========================
# 全局常量定义
# =========================
CLASS_TO_IDX = {
    "health": 0,
    "OPF": 1,
    "ITSC": 2,
    "Sensor": 3,
    "tuici": 4,
}

IDX_TO_CLASS = {v: k for k, v in CLASS_TO_IDX.items()}

DOMAIN_TO_IDX = {
    "sim": 0,
    "real": 1,
}

IDX_TO_DOMAIN = {v: k for k, v in DOMAIN_TO_IDX.items()}

KNOWN_REAL_CLASSES = {"health", "OPF", "Sensor"}

# 文件名解析正则
FILENAME_REGEX = re.compile(
    r"^(?P<load>\d+(?:\.\d+)?)Nm_(?P<domain>sim|real)_(?P<label>health|OPF|ITSC|Sensor|tuici)\.csv$",
    re.IGNORECASE
)

# 新数据目录布局：data_<domain>_<fault>/<load>Nm/<speed>.csv
NEW_LAYOUT_DIR_REGEX = re.compile(
    r"^data_(?P<domain>sim|real)_(?P<label>health|OPF|ITSC|Sensor|tuici)$",
    re.IGNORECASE
)
LOAD_DIR_REGEX = re.compile(r"^(?P<load>\d+(?:\.\d+)?)Nm$", re.IGNORECASE)
SPEED_FILENAME_REGEX = re.compile(r"^(?P<speed>\d+(?:\.\d+)?)\.csv$", re.IGNORECASE)

# 原始无表头 CSV 的 14 列顺序；theta_e 会被忽略，不进入 FEATURE_CHANNELS
RAW_CSV_COLUMNS = [
    "v",
    "theta_e",
    "id",
    "iq",
    "ix",
    "iy",
    "ia",
    "ib",
    "id2",
    "ie",
    "ud",
    "uq",
    "ux",
    "uy",
]

# 固定通道顺序：最终输入模型的通道顺序
FEATURE_CHANNELS = [
    "v",
    "id",
    "iq",
    "ix",
    "iy",
    "ia",
    "ib",
    "id2",
    "ie",
    "ud",
    "uq",
    "ux",
    "uy",
]

# 原始 CSV 可能出现的列名别名映射
SIGNAL_ALIASES = {
    "v": [
        "v", "speed", "rpm", "rot_speed", "motor_speed", "n", "omega", "velocity"
    ],
    "id": [
        "id", "i_d", "Id", "d_axis_current", "current_d", "rotor_id"
    ],
    "iq": [
        "iq", "i_q", "Iq", "q_axis_current", "current_q", "rotor_iq"
    ],
    "ix": [
        "ix", "i_x", "Ix", "x_axis_current", "current_x"
    ],
    "iy": [
        "iy", "i_y", "Iy", "y_axis_current", "current_y"
    ],
    "ia": [
        "ia", "i_a", "Ia", "phase_a_current", "stator_a_current", "current_a"
    ],
    "ib": [
        "ib", "i_b", "Ib", "phase_b_current", "stator_b_current", "current_b"
    ],
    "id2": [
        "id2", "i_d2", "Id2", "phase_d_current", "stator_d_current", "current_d2"
    ],
    "ie": [
        "ie", "i_e", "Ie", "phase_e_current", "stator_e_current", "current_e"
    ],
    "ud": [
        "ud", "u_d", "Ud", "vd", "d_axis_voltage", "voltage_d"
    ],
    "uq": [
        "uq", "u_q", "Uq", "vq", "q_axis_voltage", "voltage_q"
    ],
    "ux": [
        "ux", "u_x", "Ux", "x_axis_voltage", "voltage_x"
    ],
    "uy": [
        "uy", "u_y", "Uy", "y_axis_voltage", "voltage_y"
    ],
}

# 额外工况相关别名
CONDITION_ALIASES = {
    "speed": [
        "speed", "rpm", "rot_speed", "motor_speed", "v", "velocity"
    ],
    "load": [
        "load", "torque", "nm", "load_nm", "torque_nm", "loadtorque"
    ],
}

LABEL_CANONICAL_MAP = {k.lower(): k for k in CLASS_TO_IDX.keys()}


# =========================
# 日志工具
# =========================
def get_logger(name: str = "dataset", level: int = logging.INFO) -> logging.Logger:
    """创建或获取日志器"""
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(level)
        formatter = logging.Formatter(
            fmt="[%(asctime)s] [%(levelname)s] %(name)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)
    return logger


LOGGER = get_logger()


# =========================
# 数据结构定义
# =========================
@dataclass
class FileRecord:
    """单个 CSV 文件处理后的记录"""
    file_path: str
    filename: str
    load: Optional[float]
    speed: Optional[float]
    domain_name: str
    domain: int
    label_name: str
    label: int
    known_real: int
    trainable_in_real: int
    num_steps: int
    num_windows: int
    feature_matrix: np.ndarray       # [T, C]
    available_signals: List[str]

    def to_meta(self) -> Dict[str, Any]:
        """导出元信息（不包含大矩阵）"""
        return {
            "file_path": self.file_path,
            "filename": self.filename,
            "load": self.load,
            "speed": self.speed,
            "domain_name": self.domain_name,
            "domain": self.domain,
            "label_name": self.label_name,
            "label": self.label,
            "known_real": self.known_real,
            "trainable_in_real": self.trainable_in_real,
            "num_steps": self.num_steps,
            "num_windows": self.num_windows,
            "available_signals": self.available_signals,
        }


# =========================
# 基础辅助函数
# =========================
def set_random_seed(seed: int = 3407) -> None:
    """固定随机种子，保证数据划分可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def normalize_token(text: str) -> str:
    """
    归一化列名：
    - 转小写
    - 去除空格、下划线、横线、括号、单位等干扰字符
    """
    text = str(text).strip().lower()
    text = re.sub(r"[\s\-()[\]{}/\\]+", "", text)
    text = text.replace(".", "")
    return text


def canonicalize_label(label_name: str) -> str:
    """将大小写不一致的标签统一映射到规范标签名"""
    key = str(label_name).strip().lower()
    if key not in LABEL_CANONICAL_MAP:
        raise ValueError(f"未知标签名: {label_name}")
    return LABEL_CANONICAL_MAP[key]


def parse_filename_metadata(file_path: str) -> Dict[str, Any]:
    """
    根据文件名解析元信息。
    文件名格式：
    {load}Nm_{domain}_{fault}.csv

    例如：
    0Nm_sim_health.csv
    0.25Nm_real_OPF.csv
    """
    filename = os.path.basename(file_path)
    match = FILENAME_REGEX.match(filename)
    if match is None:
        raise ValueError(
            f"文件名不符合约定格式，无法解析: {filename}；"
            f"期望格式类似 0.25Nm_real_OPF.csv"
        )

    load = float(match.group("load"))
    domain_name = match.group("domain").lower()
    label_name = canonicalize_label(match.group("label"))

    return {
        "filename": filename,
        "load": load,
        "speed": None,
        "domain_name": domain_name,
        "domain": DOMAIN_TO_IDX[domain_name],
        "label_name": label_name,
        "label": CLASS_TO_IDX[label_name],
    }


def parse_new_layout_metadata(file_path: str) -> Optional[Dict[str, Any]]:
    """
    解析新数据目录布局：
    data_<domain>_<label>/<load>Nm/<speed>.csv

    例如：
    data/data_real_health/0.5Nm/500.csv
    data/data_sim_OPF/1Nm/1000.csv
    """
    norm_path = os.path.normpath(file_path)
    parts = norm_path.split(os.sep)
    filename = os.path.basename(file_path)

    speed_match = SPEED_FILENAME_REGEX.match(filename)
    if speed_match is None:
        return None

    load = None
    domain_name = None
    label_name = None

    for part in parts:
        dir_match = NEW_LAYOUT_DIR_REGEX.match(part)
        if dir_match is not None:
            domain_name = dir_match.group("domain").lower()
            label_name = canonicalize_label(dir_match.group("label"))
            continue

        load_match = LOAD_DIR_REGEX.match(part)
        if load_match is not None:
            load = float(load_match.group("load"))

    if domain_name is None or label_name is None or load is None:
        return None

    speed = float(speed_match.group("speed"))

    return {
        "filename": filename,
        "load": load,
        "speed": speed,
        "domain_name": domain_name,
        "domain": DOMAIN_TO_IDX[domain_name],
        "label_name": label_name,
        "label": CLASS_TO_IDX[label_name],
    }


def infer_metadata_from_path(file_path: str) -> Dict[str, Any]:
    """
    当文件名解析失败时的兜底逻辑。
    优先支持新布局 data_<domain>_<label>/<load>Nm/<speed>.csv，
    再从父目录名中尝试推断 domain 与 label。
    load/speed 若推断不出则记为 None。
    """
    new_layout_metadata = parse_new_layout_metadata(file_path)
    if new_layout_metadata is not None:
        return new_layout_metadata

    norm_path = os.path.normpath(file_path)
    path_parts = [p.lower() for p in norm_path.split(os.sep)]

    # 推断 domain
    domain_name = None
    for part in path_parts:
        if "sim" in part:
            domain_name = "sim"
            break
        if "real" in part:
            domain_name = "real"
            break

    # 推断 label
    label_name = None
    for canonical_label in CLASS_TO_IDX.keys():
        for part in path_parts:
            if canonical_label.lower() in part.lower():
                label_name = canonical_label
                break
        if label_name is not None:
            break

    # 从路径各层级中宽松提取 load
    load = None
    for part in norm_path.split(os.sep):
        load_match = re.search(r"(?P<load>\d+(?:\.\d+)?)\s*nm", part, re.IGNORECASE)
        if load_match:
            load = float(load_match.group("load"))
            break

    # 从文件名中解析 speed，例如 500.csv 或 1500rpm.csv
    filename = os.path.basename(file_path)
    speed = None
    speed_match = SPEED_FILENAME_REGEX.match(filename)
    if speed_match:
        speed = float(speed_match.group("speed"))
    else:
        rpm_match = re.search(r"(?P<speed>\d+(?:\.\d+)?)\s*rpm", filename, re.IGNORECASE)
        if rpm_match:
            speed = float(rpm_match.group("speed"))

    if domain_name is None or label_name is None:
        raise ValueError(f"无法从路径中兜底推断 domain/label: {file_path}")

    return {
        "filename": filename,
        "load": load,
        "speed": speed,
        "domain_name": domain_name,
        "domain": DOMAIN_TO_IDX[domain_name],
        "label_name": label_name,
        "label": CLASS_TO_IDX[label_name],
    }


def safe_parse_metadata(file_path: str, logger: Optional[logging.Logger] = None) -> Dict[str, Any]:
    """
    安全解析元信息：
    1. 优先解析新布局 data_<domain>_<label>/<load>Nm/<speed>.csv
    2. 再尝试旧版规范文件名正则
    3. 若失败，再尝试从路径兜底推断
    """
    logger = logger or LOGGER

    new_layout_metadata = parse_new_layout_metadata(file_path)
    if new_layout_metadata is not None:
        return new_layout_metadata

    try:
        return parse_filename_metadata(file_path)
    except Exception as e:
        logger.warning(f"[文件名解析失败] {file_path} | 原因: {e}，尝试路径兜底解析")
        return infer_metadata_from_path(file_path)


def scan_csv_files(data_root: str, recursive: bool = True) -> List[str]:
    """递归扫描 CSV 文件"""
    csv_files = []
    if recursive:
        for root, _, files in os.walk(data_root):
            for fname in files:
                if fname.lower().endswith(".csv"):
                    csv_files.append(os.path.join(root, fname))
    else:
        for fname in os.listdir(data_root):
            full_path = os.path.join(data_root, fname)
            if os.path.isfile(full_path) and fname.lower().endswith(".csv"):
                csv_files.append(full_path)

    csv_files = sorted(csv_files)
    return csv_files


def is_new_layout_file(file_path: str) -> bool:
    """判断文件是否属于新布局 data_<domain>_<label>/<load>Nm/<speed>.csv。"""
    return parse_new_layout_metadata(file_path) is not None


def looks_like_generated_header_row(row: pd.Series) -> bool:
    """识别 pandas/仿真导出的 I0,I1,...,I13 这类索引列名行。"""
    values = [str(v).strip().lower() for v in row.tolist()]
    expected = [f"i{i}" for i in range(len(RAW_CSV_COLUMNS))]
    return values == expected


def assign_headerless_columns(df: pd.DataFrame) -> pd.DataFrame:
    """为无表头 CSV 分配原始 14 列列名；若首行为 I0..I13 则先丢弃。"""
    if df.shape[1] != len(RAW_CSV_COLUMNS):
        raise ValueError(
            f"无表头 CSV 期望 {len(RAW_CSV_COLUMNS)} 列，实际 {df.shape[1]} 列"
        )
    df = df.copy()
    if len(df) > 0 and looks_like_generated_header_row(df.iloc[0]):
        df = df.iloc[1:].reset_index(drop=True)
    df.columns = RAW_CSV_COLUMNS
    return df


def read_csv_robust(file_path: str, logger: Optional[logging.Logger] = None) -> Optional[pd.DataFrame]:
    """
    健壮读取 CSV：
    - 尝试多种编码
    - 尝试容错解析
    - 跳过坏行
    - 空文件返回 None
    """
    logger = logger or LOGGER
    encodings = ["utf-8", "utf-8-sig", "gbk", "latin1"]
    header = None if is_new_layout_file(file_path) else "infer"

    for encoding in encodings:
        try:
            df = pd.read_csv(
                file_path,
                encoding=encoding,
                engine="python",
                on_bad_lines="skip",
                header=header,
            )
            if df is None or df.empty:
                logger.warning(f"[空文件或无有效数据] {file_path}")
                return None

            # 清理完全空行
            df = df.dropna(how="all").reset_index(drop=True)
            if df.empty:
                logger.warning(f"[空文件] {file_path}")
                return None

            if header is None:
                df = assign_headerless_columns(df)
            else:
                # 规范列名
                df.columns = [str(c).strip() for c in df.columns]
            return df

        except Exception as e:
            logger.debug(f"尝试编码 {encoding} 读取失败: {file_path} | {e}")
            continue

    logger.warning(f"[CSV读取失败] {file_path}，已跳过")
    return None


def find_best_matching_column(columns: Sequence[str], aliases: Sequence[str]) -> Optional[str]:
    """
    在现有列名中寻找某个 canonical signal 最匹配的列。

    匹配策略：
    1. 归一化后完全匹配
    2. 对较长别名允许 startswith/endswith 宽松匹配
    """
    norm_to_orig = {normalize_token(c): c for c in columns}
    alias_norms = [normalize_token(a) for a in aliases]

    # 完全匹配优先
    for alias_norm in alias_norms:
        if alias_norm in norm_to_orig:
            return norm_to_orig[alias_norm]

    # 宽松匹配：只对长度较长的别名启用，避免 id / iq / ix / iy 相互误匹配
    for alias_norm in alias_norms:
        if len(alias_norm) < 4:
            continue
        for col_norm, orig_col in norm_to_orig.items():
            if col_norm.startswith(alias_norm) or col_norm.endswith(alias_norm):
                return orig_col

    return None


def build_column_mapping(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    """
    为每个 canonical signal 寻找实际数据列名。
    返回结果示例：
    {
        "v": "speed",
        "id": "i_d",
        ...
    }
    """
    mapping = {}
    for canonical_name, aliases in SIGNAL_ALIASES.items():
        mapping[canonical_name] = find_best_matching_column(df.columns, aliases)
    return mapping


def clean_numeric_series(series: pd.Series) -> np.ndarray:
    """
    将列转成数值型并进行简单缺失值处理：
    - 非法值 -> NaN
    - 双向插值
    - 再用 0 补齐
    """
    series = pd.to_numeric(series, errors="coerce")
    series = series.interpolate(method="linear", limit_direction="both")
    series = series.fillna(0.0)
    values = series.to_numpy(dtype=np.float32)
    return values


def extract_speed_value(
    df: pd.DataFrame,
    column_mapping: Dict[str, Optional[str]],
    file_path: str,
    logger: Optional[logging.Logger] = None
) -> Optional[float]:
    """
    尽量提取 speed：
    1. 若有 v / speed 相关列，优先使用该列均值
    2. 若文件名中出现 rpm 信息，则尝试解析
    3. 否则返回 None
    """
    logger = logger or LOGGER

    # 优先使用 v 通道
    speed_col = column_mapping.get("v")
    if speed_col is not None and speed_col in df.columns:
        values = clean_numeric_series(df[speed_col])
        if len(values) > 0:
            return float(np.nanmean(values))

    # 其次尝试其它速度别名
    other_speed_col = find_best_matching_column(df.columns, CONDITION_ALIASES["speed"])
    if other_speed_col is not None and other_speed_col in df.columns:
        values = clean_numeric_series(df[other_speed_col])
        if len(values) > 0:
            return float(np.nanmean(values))

    # 最后尝试从文件名中解析诸如 1500rpm 这种模式
    filename = os.path.basename(file_path)
    rpm_match = re.search(r"(?P<speed>\d+(?:\.\d+)?)\s*rpm", filename, re.IGNORECASE)
    if rpm_match:
        return float(rpm_match.group("speed"))

    logger.debug(f"[speed缺失] {file_path}")
    return None


def split_dataframe_by_fixed_blocks(
    df: pd.DataFrame,
    block_size: int,
    segment_speeds: Optional[Sequence[float]] = None,
    logger: Optional[logging.Logger] = None
) -> List[Tuple[Optional[float], pd.DataFrame]]:
    """
    按固定行块拆分 CSV。

    pandas.read_csv 会把第一行作为列名，因此 DataFrame 中：
    - 第 0 到 49999 行对应 CSV 第 2 到 50001 行，速度 100 rpm
    - 第 50000 到 99999 行对应 CSV 第 50002 到 100001 行，速度 200 rpm
    - 依此类推，切分出 100 到 1000 rpm 共 10 个转速段

    因此这里不再猜测 speed 列，而是直接按固定块切分。
    """
    logger = logger or LOGGER
    if block_size <= 0:
        raise ValueError(f"block_size 必须为正整数，但收到 {block_size}")

    num_full_blocks = len(df) // block_size
    if num_full_blocks <= 0:
        return [(None, df.reset_index(drop=True))]

    if segment_speeds is not None:
        num_blocks = min(num_full_blocks, len(segment_speeds))
        if num_full_blocks < len(segment_speeds):
            logger.warning(
                f"[固定分段] 数据不足以切出全部预设转速段: "
                f"available_blocks={num_full_blocks}, expected_blocks={len(segment_speeds)}"
            )
        elif num_full_blocks > len(segment_speeds):
            logger.warning(
                f"[固定分段] 检测到超过预设转速段的完整数据块，"
                f"仅使用前 {len(segment_speeds)} 个块"
            )
    else:
        num_blocks = num_full_blocks

    segments: List[Tuple[Optional[float], pd.DataFrame]] = []
    for idx in range(num_blocks):
        start = idx * block_size
        end = start + block_size
        sub_df = df.iloc[start:end].reset_index(drop=True)
        if sub_df.empty:
            continue

        speed_value: Optional[float] = None
        if segment_speeds is not None and idx < len(segment_speeds):
            speed_value = float(segment_speeds[idx])

        segments.append((speed_value, sub_df))

    used_rows = num_blocks * block_size
    remainder = len(df) - used_rows
    if remainder > 0:
        logger.warning(f"[固定分段] 忽略尾部未使用数据: rows={remainder}, block_size={block_size}")

    logger.debug(f"按固定块拆分出 {len(segments)} 个工况段，每段 {block_size} 行")
    return segments


def extract_load_value(
    df: pd.DataFrame,
    metadata: Dict[str, Any],
    logger: Optional[logging.Logger] = None
) -> Optional[float]:
    """
    按要求：
    1. load 必须优先从文件名解析
    2. 若文件名没有，再尝试从表格列中提取
    """
    logger = logger or LOGGER

    if metadata.get("load", None) is not None:
        return float(metadata["load"])

    load_col = find_best_matching_column(df.columns, CONDITION_ALIASES["load"])
    if load_col is not None and load_col in df.columns:
        values = clean_numeric_series(df[load_col])
        if len(values) > 0:
            return float(np.nanmean(values))

    logger.debug(f"[load缺失] {metadata.get('filename', 'unknown')}")
    return None


def build_feature_matrix(
    df: pd.DataFrame,
    column_mapping: Dict[str, Optional[str]],
    logger: Optional[logging.Logger] = None
) -> Tuple[np.ndarray, List[str]]:
    """
    将 DataFrame 转换为固定 13 通道顺序的特征矩阵 [T, C]。

    说明：
    - 不再使用 CSV 中的位置角列，也不再生成 theta_e_sin / theta_e_cos。
    - 仅按 FEATURE_CHANNELS 中定义的 13 个通道构建特征。
    - 不存在的列使用 0 填充，确保输入维度稳定。
    """
    logger = logger or LOGGER
    num_steps = len(df)
    num_channels = len(FEATURE_CHANNELS)

    feature_matrix = np.zeros((num_steps, num_channels), dtype=np.float32)
    available_signals = []

    for signal_name in FEATURE_CHANNELS:
        src_col = column_mapping.get(signal_name, None)
        dst_idx = FEATURE_CHANNELS.index(signal_name)

        if src_col is not None and src_col in df.columns:
            values = clean_numeric_series(df[src_col])
            feature_matrix[:, dst_idx] = values
            available_signals.append(signal_name)
        else:
            # 缺失信号全零填充，不抛异常，保证鲁棒性
            logger.debug(f"[通道缺失] {signal_name} 使用全零填充")

    return feature_matrix, available_signals


def compute_num_windows(num_steps: int, window_size: int, stride: int) -> int:
    """根据时序长度计算滑动窗口数量"""
    if num_steps < window_size:
        return 0
    return 1 + (num_steps - window_size) // stride


def process_single_file(
    file_path: str,
    window_size: int,
    stride: int,
    logger: Optional[logging.Logger] = None
) -> List[FileRecord]:
    """
    处理单个 CSV 文件：
    - 解析元信息
    - 读取 CSV
    - 自动适配列名
    - 按固定行块拆分为多个转速段
    - 每个转速段单独构建固定格式特征矩阵并计算窗口数

    返回 List[FileRecord]：一个 CSV 内每个转速段对应一个 FileRecord。
    """
    logger = logger or LOGGER

    # 1. 解析元信息
    try:
        metadata = safe_parse_metadata(file_path, logger=logger)
    except Exception as e:
        logger.warning(f"[元信息解析失败] {file_path} | {e}")
        return []

    # 2. 读取 CSV
    df = read_csv_robust(file_path, logger=logger)
    if df is None:
        return []

    # 3. 列名映射
    column_mapping = build_column_mapping(df)

    # 4. 新布局中每个 CSV 本身就是一个转速工况；旧布局才按固定 50000 行块拆分。
    if metadata.get("speed", None) is not None:
        speed_segments = [(float(metadata["speed"]), df.reset_index(drop=True))]
    else:
        # pandas.read_csv 会把第一行作为列名排除，所以 df.iloc[0:50000]
        # 对应 CSV 第 2-50001 行，即 100 rpm。
        default_segment_speeds = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
        speed_segments = split_dataframe_by_fixed_blocks(
            df=df,
            block_size=50000,
            segment_speeds=default_segment_speeds,
            logger=logger,
        )

    records: List[FileRecord] = []
    load = extract_load_value(df, metadata, logger=logger)

    # 5. 真实域训练标志
    is_real = metadata["domain_name"] == "real"
    is_known_real = is_real and (metadata["label_name"] in KNOWN_REAL_CLASSES)

    for speed_value, segment_df in speed_segments:
        # 5.1 构建当前转速段特征矩阵
        try:
            feature_matrix, available_signals = build_feature_matrix(segment_df, column_mapping, logger=logger)
        except Exception as e:
            logger.warning(f"[特征构建失败] {file_path} | speed={speed_value} | {e}")
            continue

        num_steps = feature_matrix.shape[0]
        num_windows = compute_num_windows(num_steps, window_size, stride)
        if num_windows <= 0:
            logger.warning(
                f"[样本太短无法切窗] {file_path} | speed={speed_value} | "
                f"num_steps={num_steps}, window_size={window_size}, stride={stride}"
            )
            continue

        speed = speed_value
        if speed is None:
            speed = extract_speed_value(segment_df, column_mapping, file_path, logger=logger)

        if speed is None:
            segment_name = metadata["filename"]
        elif is_new_layout_file(file_path):
            segment_name = (
                f"data_{metadata['domain_name']}_{metadata['label_name']}"
                f"_{load:g}Nm_{int(round(float(speed)))}.csv"
            )
        else:
            stem, ext = os.path.splitext(metadata["filename"])
            segment_name = f"{stem}_speed{int(round(float(speed)))}{ext}"

        record = FileRecord(
            file_path=file_path,
            filename=segment_name,
            load=load,
            speed=speed,
            domain_name=metadata["domain_name"],
            domain=metadata["domain"],
            label_name=metadata["label_name"],
            label=metadata["label"],
            known_real=int(is_known_real),
            trainable_in_real=int(is_known_real),  # 真实域中只有 known_real 的 4 类能用于监督训练
            num_steps=num_steps,
            num_windows=num_windows,
            feature_matrix=feature_matrix,
            available_signals=available_signals,
        )
        records.append(record)

    if len(records) == 0:
        logger.warning(f"[文件无有效转速段] {file_path}")

    return records


# =========================
# 标准化器
# =========================
class ChannelWiseScaler:
    """
    通道级 z-score 标准化器
    mean/std 形状均为 [C]
    """

    def __init__(self, mean: Optional[np.ndarray] = None, std: Optional[np.ndarray] = None, eps: float = 1e-6):
        self.mean = mean
        self.std = std
        self.eps = eps

    @property
    def fitted(self) -> bool:
        return self.mean is not None and self.std is not None

    def fit(self, records: Sequence[FileRecord]) -> "ChannelWiseScaler":
        """
        根据训练集记录拟合通道统计量。
        这里按“原始时序点”统计，而不是按窗口统计，计算更稳定也更高效。
        """
        if len(records) == 0:
            raise ValueError("fit scaler 时 records 为空")

        sum_x = None
        sum_x2 = None
        total_count = 0

        for record in records:
            x = record.feature_matrix.astype(np.float64)   # [T, C]
            if x.ndim != 2:
                continue

            if sum_x is None:
                sum_x = np.zeros((x.shape[1],), dtype=np.float64)
                sum_x2 = np.zeros((x.shape[1],), dtype=np.float64)

            sum_x += x.sum(axis=0)
            sum_x2 += (x ** 2).sum(axis=0)
            total_count += x.shape[0]

        if total_count == 0:
            raise ValueError("无法从空数据中拟合 scaler")

        mean = sum_x / total_count
        var = sum_x2 / total_count - mean ** 2
        var = np.maximum(var, self.eps ** 2)
        std = np.sqrt(var)

        self.mean = mean.astype(np.float32)
        self.std = std.astype(np.float32)
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        """
        对单个样本做标准化
        输入 x 形状为 [C, T]
        """
        if not self.fitted:
            return x

        mean = self.mean[:, None]
        std = np.maximum(self.std[:, None], self.eps)
        return (x - mean) / std

    def state_dict(self) -> Dict[str, Any]:
        return {
            "mean": None if self.mean is None else self.mean.tolist(),
            "std": None if self.std is None else self.std.tolist(),
            "eps": self.eps,
        }

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        mean = state_dict.get("mean", None)
        std = state_dict.get("std", None)
        self.mean = None if mean is None else np.asarray(mean, dtype=np.float32)
        self.std = None if std is None else np.asarray(std, dtype=np.float32)
        self.eps = float(state_dict.get("eps", 1e-6))

    def save_json(self, save_path: str) -> None:
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(self.state_dict(), f, ensure_ascii=False, indent=2)

    @classmethod
    def load_json(cls, load_path: str) -> "ChannelWiseScaler":
        with open(load_path, "r", encoding="utf-8") as f:
            state_dict = json.load(f)
        scaler = cls()
        scaler.load_state_dict(state_dict)
        return scaler


# =========================
# 数据划分
# =========================
def compute_split_counts(n: int, train_ratio: float, val_ratio: float, test_ratio: float) -> Tuple[int, int, int]:
    """
    给定组内样本数 n，计算 train/val/test 数量。
    尽量保证：
    - n>=3 时，优先留出 val/test
    - n 很小时不强行均分，避免空训练集
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "划分比例必须和为 1"

    if n <= 0:
        return 0, 0, 0
    if n == 1:
        return 1, 0, 0
    if n == 2:
        return 1, 0, 1

    n_train = max(1, int(round(n * train_ratio)))
    n_val = max(1, int(round(n * val_ratio)))
    n_test = n - n_train - n_val

    if n_test <= 0:
        n_test = 1
        if n_train >= n_val:
            n_train -= 1
        else:
            n_val -= 1

    # 兜底
    if n_train <= 0:
        n_train = 1
        if n_val > 1:
            n_val -= 1
        else:
            n_test = max(0, n_test - 1)

    return n_train, n_val, n_test


def stratified_split_records(
    records: Sequence[FileRecord],
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 3407
) -> Dict[str, List[FileRecord]]:
    """
    按 (domain_name, label_name, load) 分层划分转速段级 train/val/test。
    每个 FileRecord 现在对应一个 CSV 内部的单一转速段，因此划分单位是“文件 + 转速”。
    这样可以避免同一转速段的窗口同时出现在训练和测试中。
    """
    rng = random.Random(seed)

    grouped: Dict[Tuple[str, str, Optional[float]], List[FileRecord]] = {}
    for record in records:
        key = (record.domain_name, record.label_name, record.load)
        grouped.setdefault(key, []).append(record)

    train_records, val_records, test_records = [], [], []

    for key, group in grouped.items():
        group = list(group)
        rng.shuffle(group)

        n_train, n_val, n_test = compute_split_counts(
            len(group), train_ratio, val_ratio, test_ratio
        )

        train_part = group[:n_train]
        val_part = group[n_train:n_train + n_val]
        test_part = group[n_train + n_val:n_train + n_val + n_test]

        train_records.extend(train_part)
        val_records.extend(val_part)
        test_records.extend(test_part)

    return {
        "train": train_records,
        "val": val_records,
        "test": test_records,
    }


def summarize_speed_distribution(records: Sequence[FileRecord]) -> Dict[str, Dict[str, List[int]]]:
    """
    按 domain/label 汇总转速分布，便于检查退磁类高速过滤是否生效。
    """
    summary: Dict[str, Dict[str, set]] = {}
    for record in records:
        domain_summary = summary.setdefault(record.domain_name, {})
        speed_set = domain_summary.setdefault(record.label_name, set())
        if record.speed is not None:
            speed_set.add(int(round(float(record.speed))))

    return {
        domain_name: {
            label_name: sorted(speed_set)
            for label_name, speed_set in label_summary.items()
        }
        for domain_name, label_summary in summary.items()
    }


def filter_records_by_unknown_fault_speed(
    records: Sequence[FileRecord],
    filter_cfg: Optional[Dict[str, Any]] = None,
    logger: Optional[logging.Logger] = None
) -> List[FileRecord]:
    """
    按配置过滤未知/退磁故障的低速工况记录。

    典型配置：
    {
        "enabled": True,
        "labels": ["tuici"],
        "min_speed": 500,
        "apply_domains": ["sim", "real"],
    }

    仅对匹配 label/domain 的记录应用 speed >= min_speed；其他类别和域保持不变。
    """
    logger = logger or LOGGER
    filter_cfg = filter_cfg or {}
    if not bool(filter_cfg.get("enabled", False)):
        return list(records)

    target_labels = set(filter_cfg.get("labels", []))
    apply_domains = filter_cfg.get("apply_domains", None)
    apply_domains = None if apply_domains is None else set(apply_domains)
    min_speed = float(filter_cfg.get("min_speed", 500.0))

    if len(target_labels) == 0:
        logger.warning("[未知故障高速过滤] labels 为空，跳过过滤")
        return list(records)

    filtered: List[FileRecord] = []
    removed: List[FileRecord] = []

    for record in records:
        is_target_label = record.label_name in target_labels
        is_target_domain = apply_domains is None or record.domain_name in apply_domains

        if is_target_label and is_target_domain:
            if record.speed is None or float(record.speed) < min_speed:
                removed.append(record)
                continue

        filtered.append(record)

    logger.info(
        f"[未知故障高速过滤] enabled=True, labels={sorted(target_labels)}, "
        f"apply_domains={'all' if apply_domains is None else sorted(apply_domains)}, "
        f"min_speed={min_speed:g}, before={len(records)}, after={len(filtered)}, removed={len(removed)}"
    )
    logger.info(f"[未知故障高速过滤] 保留后转速分布: {summarize_speed_distribution(filtered)}")

    if len(removed) > 0:
        logger.info(f"[未知故障高速过滤] 被移除记录转速分布: {summarize_speed_distribution(removed)}")

    return filtered


def split_unknown_real_test_records(
    records: Sequence[FileRecord],
    unknown_cfg: Optional[Dict[str, Any]] = None,
    logger: Optional[logging.Logger] = None
) -> Dict[str, List[FileRecord]]:
    """
    将真实域未知故障记录从普通 train/val/test 划分前单独剥离出来。

    典型配置：
    {
        "enabled": True,
        "labels": ["tuici"],
        "min_speed": 500,
        "domain": "real",
    }

    返回：
    {
        "known_records": 参与普通划分的记录,
        "unknown_test_records": 真实未知故障全量测试记录,
    }
    """
    logger = logger or LOGGER
    unknown_cfg = unknown_cfg or {}
    if not bool(unknown_cfg.get("enabled", False)):
        return {
            "known_records": list(records),
            "unknown_test_records": [],
        }

    target_labels = set(unknown_cfg.get("labels", []))
    target_domain = str(unknown_cfg.get("domain", "real"))
    min_speed = float(unknown_cfg.get("min_speed", 500.0))

    if len(target_labels) == 0:
        logger.warning("[真实未知测试集] labels 为空，跳过未知测试集剥离")
        return {
            "known_records": list(records),
            "unknown_test_records": [],
        }

    known_records: List[FileRecord] = []
    unknown_test_records: List[FileRecord] = []

    for record in records:
        is_unknown_target = (
            record.domain_name == target_domain
            and record.label_name in target_labels
            and record.speed is not None
            and float(record.speed) >= min_speed
        )

        if is_unknown_target:
            unknown_test_records.append(record)
        else:
            known_records.append(record)

    logger.info(
        f"[真实未知测试集] enabled=True, domain={target_domain}, "
        f"labels={sorted(target_labels)}, min_speed={min_speed:g}, "
        f"known_records={len(known_records)}, unknown_test_records={len(unknown_test_records)}"
    )
    logger.info(f"[真实未知测试集] 未知测试转速分布: {summarize_speed_distribution(unknown_test_records)}")

    return {
        "known_records": known_records,
        "unknown_test_records": unknown_test_records,
    }


def filter_records(
    records: Sequence[FileRecord],
    domain_names: Optional[Sequence[str]] = None,
    label_names: Optional[Sequence[str]] = None,
    real_trainable_only: bool = False
) -> List[FileRecord]:
    """
    过滤文件记录：
    - domain_names: 仅保留指定域
    - label_names: 仅保留指定类别
    - real_trainable_only: 若为 True，则真实域中只保留 known_real 的 4 类；
                           仿真域 五类不受影响
    """
    domain_names = None if domain_names is None else set(domain_names)
    label_names = None if label_names is None else set(label_names)

    filtered = []
    for record in records:
        if domain_names is not None and record.domain_name not in domain_names:
            continue
        if label_names is not None and record.label_name not in label_names:
            continue
        if real_trainable_only and record.domain_name == "real" and record.trainable_in_real != 1:
            continue
        filtered.append(record)
    return filtered


def build_file_records(
    data_root: str,
    window_size: int,
    stride: int,
    recursive: bool = True,
    logger: Optional[logging.Logger] = None
) -> List[FileRecord]:
    """
    从 data_root 扫描并构建全部 FileRecord
    """
    logger = logger or LOGGER
    csv_files = scan_csv_files(data_root=data_root, recursive=recursive)
    logger.info(f"扫描到 CSV 文件数: {len(csv_files)}")

    records = []
    for file_path in csv_files:
        file_records = process_single_file(
            file_path=file_path,
            window_size=window_size,
            stride=stride,
            logger=logger
        )
        records.extend(file_records)

    logger.info(f"成功构建 FileRecord 数: {len(records)}")
    return records


# =========================
# PyTorch Dataset
# =========================
def _standardize_window(
    x_raw: np.ndarray,
    scaler: Optional[ChannelWiseScaler],
    standardize: bool,
) -> np.ndarray:
    """根据 scaler 对 [C, T] 窗口做标准化。"""
    if standardize and scaler is not None and scaler.fitted:
        return scaler.transform(x_raw)
    return x_raw


def _maybe_apply_train_augmentation(
    x_raw: np.ndarray,
    record: FileRecord,
    augmentor: Optional[Any],
    is_train: bool,
    stage_name: Optional[str],
) -> Tuple[np.ndarray, Optional[Dict[str, Any]]]:
    """只在训练集对原始窗口做增强，val/test 保持原样。"""
    if (not is_train) or augmentor is None:
        return x_raw, None

    x_tensor = torch.from_numpy(x_raw.astype(np.float32, copy=True))
    stage = "stage1" if stage_name is None else stage_name
    rpm = None if record.speed is None else float(record.speed)

    if hasattr(augmentor, "augment_with_meta"):
        x_aug, aug_meta = augmentor.augment_with_meta(
            x=x_tensor,
            label=int(record.label),
            domain=int(record.domain),
            stage=stage,
            rpm=rpm,
        )
    else:
        x_aug = augmentor(
            x_tensor,
            label=int(record.label),
            domain=int(record.domain),
            stage=stage,
            rpm=rpm,
        )
        aug_meta = {"applied": ["custom_augmentor"]}

    x_aug_np = x_aug.detach().cpu().numpy().astype(np.float32, copy=False)
    return x_aug_np, aug_meta


class WindowedFaultDataset(Dataset):
    """
    滑动窗口时序故障数据集

    返回格式：
    {
      "x": Tensor[C, T],
      "y": int,
      "domain": int,
      "known_real": int,
      "trainable_in_real": int,
      "speed": Tensor(float) 或 nan,
      "load": Tensor(float) 或 nan,
      "meta": dict
    }
    """

    def __init__(
        self,
        file_records: Sequence[FileRecord],
        window_size: int,
        stride: int,
        scaler: Optional[ChannelWiseScaler] = None,
        standardize: bool = False,
        augmentor: Optional[Any] = None,
        is_train: bool = False,
        stage_name: Optional[str] = None,
    ):
        super().__init__()
        self.file_records = list(file_records)
        self.window_size = int(window_size)
        self.stride = int(stride)
        self.scaler = scaler
        self.standardize = standardize
        self.augmentor = augmentor
        self.is_train = bool(is_train)
        self.stage_name = stage_name

        self.index_map: List[Tuple[int, int, int]] = []
        self._build_index()

    def _build_index(self) -> None:
        """
        建立窗口索引：
        每个元素为 (record_idx, start, end)
        """
        self.index_map.clear()
        for record_idx, record in enumerate(self.file_records):
            for win_idx in range(record.num_windows):
                start = win_idx * self.stride
                end = start + self.window_size
                if end <= record.num_steps:
                    self.index_map.append((record_idx, start, end))

    def __len__(self) -> int:
        return len(self.index_map)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        record_idx, start, end = self.index_map[index]
        record = self.file_records[record_idx]

        x_raw = record.feature_matrix[start:end].T.astype(np.float32)
        x_raw, aug_meta = _maybe_apply_train_augmentation(
            x_raw=x_raw,
            record=record,
            augmentor=self.augmentor,
            is_train=self.is_train,
            stage_name=self.stage_name,
        )
        x = _standardize_window(x_raw, scaler=self.scaler, standardize=self.standardize)

        meta = {
            "file_path": record.file_path,
            "filename": record.filename,
            "window_start": start,
            "window_end": end,
            "label_name": record.label_name,
            "domain_name": record.domain_name,
            "available_signals": record.available_signals,
            "speed_missing": bool(record.speed is None),
            "load_missing": bool(record.load is None),
        }
        if aug_meta is not None:
            meta["augmentation"] = aug_meta

        sample = {
            "x": torch.from_numpy(x),                        # [C, T]
            "x_raw": torch.from_numpy(x_raw),                # [C, T] (未标准化，训练时可为增强后窗口)
            "y": int(record.label),
            "domain": int(record.domain),
            "known_real": int(record.known_real),
            "trainable_in_real": int(record.trainable_in_real),
            "speed": torch.tensor(
                float("nan") if record.speed is None else float(record.speed),
                dtype=torch.float32
            ),
            "load": torch.tensor(
                float("nan") if record.load is None else float(record.load),
                dtype=torch.float32
            ),
            "meta": meta,
        }
        return sample

    @property
    def num_channels(self) -> int:
        return len(FEATURE_CHANNELS)

    def summary(self) -> Dict[str, Any]:
        """
        返回当前数据集的简要统计信息
        """
        label_counter = {}
        domain_counter = {}
        for record in self.file_records:
            label_counter[record.label_name] = label_counter.get(record.label_name, 0) + record.num_windows
            domain_counter[record.domain_name] = domain_counter.get(record.domain_name, 0) + record.num_windows

        return {
            "num_files": len(self.file_records),
            "num_windows": len(self.index_map),
            "label_counter_by_window": label_counter,
            "domain_counter_by_window": domain_counter,
            "window_size": self.window_size,
            "stride": self.stride,
            "standardize": self.standardize,
        }


class IndexedWindowFaultDataset(Dataset):
    """
    滑动窗口索引型故障数据集。

    与 WindowedFaultDataset 不同，本类只暴露显式指定的窗口索引。
    window_indices 中每个元素为 (record_idx, window_idx)。
    """

    def __init__(
        self,
        file_records: Sequence[FileRecord],
        window_indices: Sequence[WindowIndex],
        window_size: int,
        stride: int,
        scaler: Optional[ChannelWiseScaler] = None,
        standardize: bool = False,
        augmentor: Optional[Any] = None,
        is_train: bool = False,
        stage_name: Optional[str] = None,
    ):
        super().__init__()
        self.file_records = list(file_records)
        self.window_indices = [(int(record_idx), int(window_idx)) for record_idx, window_idx in window_indices]
        self.window_size = int(window_size)
        self.stride = int(stride)
        self.scaler = scaler
        self.standardize = standardize
        self.augmentor = augmentor
        self.is_train = bool(is_train)
        self.stage_name = stage_name

    def __len__(self) -> int:
        return len(self.window_indices)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        record_idx, window_idx = self.window_indices[index]
        record = self.file_records[record_idx]

        start = int(window_idx) * self.stride
        end = start + self.window_size
        if end > record.num_steps:
            raise IndexError(
                f"窗口越界: record_idx={record_idx}, window_idx={window_idx}, "
                f"start={start}, end={end}, num_steps={record.num_steps}"
            )

        x_raw = record.feature_matrix[start:end].T.astype(np.float32)
        x_raw, aug_meta = _maybe_apply_train_augmentation(
            x_raw=x_raw,
            record=record,
            augmentor=self.augmentor,
            is_train=self.is_train,
            stage_name=self.stage_name,
        )
        x = _standardize_window(x_raw, scaler=self.scaler, standardize=self.standardize)

        meta = {
            "file_path": record.file_path,
            "filename": record.filename,
            "window_idx": int(window_idx),
            "window_start": start,
            "window_end": end,
            "label_name": record.label_name,
            "domain_name": record.domain_name,
            "available_signals": record.available_signals,
            "speed_missing": bool(record.speed is None),
            "load_missing": bool(record.load is None),
        }
        if aug_meta is not None:
            meta["augmentation"] = aug_meta

        return {
            "x": torch.from_numpy(x),
            "x_raw": torch.from_numpy(x_raw),
            "y": int(record.label),
            "domain": int(record.domain),
            "known_real": int(record.known_real),
            "trainable_in_real": int(record.trainable_in_real),
            "speed": torch.tensor(
                float("nan") if record.speed is None else float(record.speed),
                dtype=torch.float32,
            ),
            "load": torch.tensor(
                float("nan") if record.load is None else float(record.load),
                dtype=torch.float32,
            ),
            "meta": meta,
        }

    @property
    def num_channels(self) -> int:
        return len(FEATURE_CHANNELS)

    def summary(self) -> Dict[str, Any]:
        label_counter: Dict[str, int] = {}
        domain_counter: Dict[str, int] = {}
        used_record_indices = set()

        for record_idx, _ in self.window_indices:
            record = self.file_records[record_idx]
            used_record_indices.add(record_idx)
            label_counter[record.label_name] = label_counter.get(record.label_name, 0) + 1
            domain_counter[record.domain_name] = domain_counter.get(record.domain_name, 0) + 1

        return {
            "num_files": len(used_record_indices),
            "num_windows": len(self.window_indices),
            "label_counter_by_window": label_counter,
            "domain_counter_by_window": domain_counter,
            "window_size": self.window_size,
            "stride": self.stride,
            "standardize": self.standardize,
        }


# =========================
# 高层构建函数
# =========================
def build_datasets_for_stage(
    data_root: str,
    window_size: int,
    stride: int,
    recursive: bool = True,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 3407,
    standardize: bool = True,
    scaler_eps: float = 1e-6,
    logger: Optional[logging.Logger] = None,
    unknown_fault_speed_filter: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    一次性构建：
    - 全部文件记录
    - train / val / test 文件划分
    - 基于 train 记录拟合 scaler
    - 各阶段常用的数据集视图

    返回结构示例：
    {
      "all_records": ...,
      "split_records": {"train": ..., "val": ..., "test": ...},
      "scaler": scaler,
      "datasets": {
          "stage1_train": ...,
          "stage1_val": ...,
          "stage2_train": ...,
          "stage2_val": ...,
          "sim_test": ...,
          "real_test_known4": ...,
          "real_test_all5": ...
      }
    }
    """
    logger = logger or LOGGER
    set_random_seed(seed)

    all_records = build_file_records(
        data_root=data_root,
        window_size=window_size,
        stride=stride,
        recursive=recursive,
        logger=logger
    )

    all_records = filter_records_by_unknown_fault_speed(
        records=all_records,
        filter_cfg=unknown_fault_speed_filter,
        logger=logger,
    )

    split_records = stratified_split_records(
        records=all_records,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        seed=seed
    )

    train_records = split_records["train"]
    val_records = split_records["val"]
    test_records = split_records["test"]

    # 训练集统计量仅允许来自训练数据
    scaler = ChannelWiseScaler(eps=scaler_eps)
    if standardize:
        scaler.fit(train_records)

    # Stage1：只使用仿真五类
    stage1_train_records = filter_records(train_records, domain_names=["sim"])
    stage1_val_records = filter_records(val_records, domain_names=["sim"])

    # Stage2 / Stage3：
    # 使用仿真五类 + 真实四类可训练样本
    stage2_train_records = filter_records(
        train_records,
        domain_names=["sim", "real"],
        real_trainable_only=True
    )
    stage2_val_records = filter_records(
        val_records,
        domain_names=["sim", "real"],
        real_trainable_only=True
    )

    # 测试集视图
    sim_test_records = filter_records(test_records, domain_names=["sim"])
    real_test_known4_records = filter_records(
        test_records,
        domain_names=["real"],
        label_names=list(KNOWN_REAL_CLASSES)
    )
    real_test_all5_records = filter_records(test_records, domain_names=["real"])

    datasets = {
        "stage1_train": WindowedFaultDataset(
            stage1_train_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "stage1_val": WindowedFaultDataset(
            stage1_val_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "stage2_train": WindowedFaultDataset(
            stage2_train_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "stage2_val": WindowedFaultDataset(
            stage2_val_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "stage3_train": WindowedFaultDataset(
            stage2_train_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "stage3_val": WindowedFaultDataset(
            stage2_val_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "sim_test": WindowedFaultDataset(
            sim_test_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "real_test_known4": WindowedFaultDataset(
            real_test_known4_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
        "real_test_all5": WindowedFaultDataset(
            real_test_all5_records, window_size, stride, scaler=scaler, standardize=standardize
        ),
    }

    logger.info("数据集构建完成：")
    for name, ds in datasets.items():
        logger.info(f"{name}: {ds.summary()}")

    return {
        "all_records": all_records,
        "split_records": split_records,
        "scaler": scaler,
        "datasets": datasets,
    }


if __name__ == "__main__":
    """
    本地快速自检示例：
    python dataset.py
    """
    logger = get_logger("dataset_debug")
    data_root = "./data"
    if not os.path.exists(data_root):
        logger.warning(f"未找到数据目录: {data_root}")
    else:
        result = build_datasets_for_stage(
            data_root=data_root,
            window_size=2000,
            stride=1000,
            recursive=True,
            train_ratio=0.7,
            val_ratio=0.15,
            test_ratio=0.15,
            seed=3407,
            standardize=True,
            scaler_eps=1e-6,
            logger=logger
        )
        logger.info("dataset.py 自检完成")