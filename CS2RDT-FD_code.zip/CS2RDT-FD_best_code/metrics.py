# metrics.py
# -*- coding: utf-8 -*-

"""
评估指标模块：
1. overall accuracy
2. per-class accuracy
3. confusion matrix
4. confusion matrix 可视化保存
"""

from typing import Dict, List, Optional, Sequence, Any

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def compute_confusion_matrix(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    num_classes: int
) -> np.ndarray:
    """
    计算混淆矩阵，返回形状 [num_classes, num_classes]
    行是真实类别，列是预测类别
    """
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        if 0 <= int(t) < num_classes and 0 <= int(p) < num_classes:
            cm[int(t), int(p)] += 1
    return cm


def compute_overall_accuracy(
    y_true: Sequence[int],
    y_pred: Sequence[int]
) -> float:
    """
    计算 overall accuracy
    """
    y_true = np.asarray(y_true, dtype=np.int64)
    y_pred = np.asarray(y_pred, dtype=np.int64)

    if y_true.size == 0:
        return 0.0
    return float((y_true == y_pred).mean())


def compute_per_class_accuracy_from_cm(
    confusion_matrix: np.ndarray
) -> Dict[int, Optional[float]]:
    """
    由混淆矩阵计算每类准确率
    若某一类在当前评估集合中没有样本，则返回 None
    """
    per_class = {}
    num_classes = confusion_matrix.shape[0]
    for cls_idx in range(num_classes):
        row_sum = confusion_matrix[cls_idx].sum()
        if row_sum <= 0:
            per_class[cls_idx] = None
        else:
            per_class[cls_idx] = float(confusion_matrix[cls_idx, cls_idx] / row_sum)
    return per_class


def compute_per_class_accuracy(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    num_classes: int
) -> Dict[int, Optional[float]]:
    """
    直接由标签计算每类准确率
    """
    cm = compute_confusion_matrix(y_true, y_pred, num_classes)
    return compute_per_class_accuracy_from_cm(cm)


def format_per_class_accuracy(
    per_class_accuracy: Dict[int, Optional[float]],
    idx_to_class: Dict[int, str]
) -> Dict[str, Optional[float]]:
    """
    将 {类别索引: acc} 转换成 {类别名: acc}
    """
    formatted = {}
    for idx, acc in per_class_accuracy.items():
        cls_name = idx_to_class.get(idx, str(idx))
        formatted[cls_name] = None if acc is None else float(acc)
    return formatted


def summarize_classification_metrics(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    num_classes: int,
    idx_to_class: Dict[int, str]
) -> Dict[str, Any]:
    """
    汇总分类指标
    """
    cm = compute_confusion_matrix(y_true, y_pred, num_classes)
    overall_acc = compute_overall_accuracy(y_true, y_pred)
    per_class_acc = compute_per_class_accuracy_from_cm(cm)
    per_class_acc_named = format_per_class_accuracy(per_class_acc, idx_to_class)

    return {
        "overall_accuracy": float(overall_acc),
        "per_class_accuracy": per_class_acc_named,
        "confusion_matrix": cm.tolist(),
    }


def save_confusion_matrix_figure(
    confusion_matrix: np.ndarray,
    class_names: List[str],
    save_path: str,
    normalize: bool = False,
    title: str = "Confusion Matrix"
) -> None:
    """
    保存混淆矩阵图像
    """
    cm = confusion_matrix.astype(np.float64)

    if normalize:
        row_sum = cm.sum(axis=1, keepdims=True)
        row_sum[row_sum == 0] = 1.0
        cm = cm / row_sum

    fig, ax = plt.subplots(figsize=(8, 6))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    ax.figure.colorbar(im, ax=ax)
    ax.set(
        xticks=np.arange(len(class_names)),
        yticks=np.arange(len(class_names)),
        xticklabels=class_names,
        yticklabels=class_names,
        ylabel="True Label",
        xlabel="Predicted Label",
        title=title,
    )

    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

    threshold = cm.max() / 2.0 if cm.size > 0 else 0.5
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if normalize:
                text = f"{cm[i, j]:.2f}"
            else:
                text = f"{int(cm[i, j])}"
            ax.text(
                j, i, text,
                ha="center", va="center",
                color="white" if cm[i, j] > threshold else "black"
            )

    fig.tight_layout()
    fig.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
