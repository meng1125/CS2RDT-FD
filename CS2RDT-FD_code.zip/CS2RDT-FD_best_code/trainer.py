# trainer.py
# -*- coding: utf-8 -*-

"""
训练器模块：
1. BaseTrainer：提供通用训练/验证/保存逻辑
2. Stage1Trainer：只训练仿真五类
3. Stage2Trainer：仿真五类 + 真实 4 类联合迁移训练
4. Stage3Trainer：冻结部分低层后继续精调

说明：
- 所有 trainer 都提供：
  - train_one_epoch
  - validate
  - save_checkpoint
  - load_checkpoint
  - fit（额外提供，方便直接训练多轮）
"""

import os
import time
import logging
from typing import Dict, Any, Optional, Sequence

import torch
from torch.nn.utils import clip_grad_norm_

from losses import total_loss
from local_mapping import CONDITION_FIELDS, build_reference
from metrics import (
    compute_confusion_matrix,
    compute_per_class_accuracy_from_cm,
    format_per_class_accuracy,
)
from dataset import IDX_TO_CLASS
from utils import (
    AverageMeter,
    detach_loss_dict,
    move_batch_to_device,
    ensure_dir,
    get_known_unknown_real_class_indices,
)


class BaseTrainer:
    """
    基础训练器
    """

    def __init__(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        train_loader,
        val_loader,
        device: torch.device,
        config: Dict[str, Any],
        logger: logging.Logger,
        checkpoint_dir: str,
        stage_name: str,
        teacher_model: Optional[torch.nn.Module] = None,
        known_real_class_indices: Optional[Sequence[int]] = None,
        anomaly_class_indices: Optional[Sequence[int]] = None,
    ):
        self.model = model
        self.optimizer = optimizer
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.config = config
        self.logger = logger
        self.checkpoint_dir = checkpoint_dir
        self.stage_name = stage_name
        self.teacher_model = teacher_model
        if known_real_class_indices is None or anomaly_class_indices is None:
            cfg_known, cfg_unknown = get_known_unknown_real_class_indices(config)
            self.known_real_class_indices = cfg_known if known_real_class_indices is None else tuple(known_real_class_indices)
            self.anomaly_class_indices = cfg_unknown if anomaly_class_indices is None else tuple(anomaly_class_indices)
        else:
            self.known_real_class_indices = tuple(known_real_class_indices)
            self.anomaly_class_indices = tuple(anomaly_class_indices)

        ensure_dir(self.checkpoint_dir)

        self.train_cfg = config["train"]
        self.loss_cfg = dict(config["loss"])
        self.loss_cfg["label_smoothing"] = float(config["train"].get("label_smoothing", 0.0))

        self.logging_cfg = config["logging"]
        self.max_grad_norm = float(config["train"]["max_grad_norm"])
        self.log_interval = int(config["logging"]["log_interval"])

        self.current_epoch = 0
        self.best_val_acc = -1.0
        self.best_selection_score = -float("inf")
        self.best_selection_tuple = None
        self._frozen_module_eval_logged = False

        self.model.to(self.device)
        if self.teacher_model is not None:
            self.teacher_model.to(self.device)
            self.teacher_model.eval()
            for p in self.teacher_model.parameters():
                p.requires_grad = False

    def _forward_model(self, batch: Dict[str, Any]) -> Dict[str, torch.Tensor]:
        """
        统一前向接口
        """
        outputs = self.model(
            x=batch["x"],
            x_raw=batch.get("x_raw", None),
            speed_rpm=batch.get("speed", None),
            class_condition=batch["y"],
            grl_lambda_domain=float(self.loss_cfg.get("grl_lambda_domain", 1.0)),
            grl_lambda_domain_global=float(self.loss_cfg.get("grl_lambda_domain_global", 0.0)),
        )
        return outputs

    @torch.no_grad()
    def _forward_teacher(self, batch: Dict[str, Any]) -> Optional[Dict[str, torch.Tensor]]:
        """
        teacher 前向，用于蒸馏
        """
        if self.teacher_model is None:
            return None

        teacher_outputs = self.teacher_model(
            x=batch["x"],
            x_raw=batch.get("x_raw", None),
            speed_rpm=batch.get("speed", None),
            class_condition=batch["y"],
            grl_lambda_domain=0.0,
            grl_lambda_domain_global=0.0,
        )
        return teacher_outputs

    @staticmethod
    def _compute_accuracy_from_logits(logits: torch.Tensor, y: torch.Tensor) -> float:
        """
        计算 batch 准确率
        """
        pred = torch.argmax(logits, dim=1)
        acc = (pred == y).float().mean().item()
        return float(acc)

    def _format_fusion_alpha(self) -> Optional[str]:
        logit_fusion = getattr(self.model, "logit_fusion", None)
        if logit_fusion is None or not hasattr(logit_fusion, "get_alpha"):
            return None
        alpha = logit_fusion.get_alpha().detach().cpu().tolist()
        alpha_dict = {
            IDX_TO_CLASS.get(i, str(i)): round(float(v), 4)
            for i, v in enumerate(alpha)
        }
        return str(alpha_dict)

    @staticmethod
    def _mean_present(values: Sequence[Optional[float]]) -> float:
        present = [float(v) for v in values if v is not None]
        if not present:
            return 0.0
        return float(sum(present) / len(present))

    def _selection_metric_name(self) -> str:
        stage_cfg = self.train_cfg.get(self.stage_name, {})
        return str(stage_cfg.get("selection_metric", "acc"))

    def _selection_tuple(self, val_metrics: Dict[str, Any]) -> tuple:
        metric_name = self._selection_metric_name()
        metric_value = float(val_metrics.get(metric_name, val_metrics.get("acc", 0.0)))
        acc = float(val_metrics.get("acc", 0.0))
        macro = float(val_metrics.get("val_macro_recall", 0.0))
        unknown_proxy = float(val_metrics.get("val_unknown_proxy_recall", 0.0))
        known_real_proxy = float(val_metrics.get("val_known_real_proxy_recall", 0.0))
        loss = float(val_metrics.get("loss", 0.0))
        return (metric_value, acc, macro, unknown_proxy, known_real_proxy, -loss)

    def _eval_frozen_modules_enabled(self) -> bool:
        stage_cfg = self.train_cfg.get(self.stage_name, {})
        return bool(stage_cfg.get("eval_frozen_modules", False))

    def _set_frozen_modules_eval(self) -> None:
        """Keep fully frozen submodules from updating BatchNorm/Dropout state."""
        if not self._eval_frozen_modules_enabled():
            return
        num_eval = 0
        for module in self.model.modules():
            if module is self.model:
                continue
            has_trainable = any(param.requires_grad for param in module.parameters(recurse=True))
            if not has_trainable:
                module.eval()
                num_eval += 1
        if not self._frozen_module_eval_logged:
            self.logger.info(
                f"[{self.stage_name}] eval_frozen_modules=true; "
                f"set {num_eval} fully frozen submodules to eval mode during training"
            )
            self._frozen_module_eval_logged = True

    def train_one_epoch(self, epoch: int) -> Dict[str, float]:
        """
        训练一个 epoch
        """
        self.model.train()
        self._set_frozen_modules_eval()
        epoch_start = time.time()

        meter_total = AverageMeter()
        meter_acc = AverageMeter()
        loss_meters: Dict[str, AverageMeter] = {}

        for batch_idx, batch in enumerate(self.train_loader):
            batch = move_batch_to_device(batch, self.device)
            if self.loss_cfg.get("lambda_map") is not None:
                batch["local_mapping_step"] = {"epoch": epoch, "batch": batch_idx + 1}

            self.optimizer.zero_grad()

            outputs = self._forward_model(batch)
            teacher_outputs = self._forward_teacher(batch)

            loss_dict = total_loss(
                outputs=outputs,
                batch=batch,
                model=self.model,
                loss_cfg=self.loss_cfg,
                teacher_outputs=teacher_outputs,
                known_real_class_indices=self.known_real_class_indices,
                anomaly_class_indices=self.anomaly_class_indices,
            )

            loss = loss_dict["total"]
            loss.backward()

            if self.max_grad_norm is not None and self.max_grad_norm > 0:
                clip_grad_norm_(self.model.parameters(), self.max_grad_norm)

            self.optimizer.step()

            batch_size = batch["x"].size(0)
            acc = self._compute_accuracy_from_logits(outputs["logits"], batch["y"])

            meter_total.update(loss.item(), batch_size)
            meter_acc.update(acc, batch_size)

            detached = detach_loss_dict(loss_dict)
            for k, v in detached.items():
                if k not in loss_meters:
                    loss_meters[k] = AverageMeter()
                loss_meters[k].update(v, batch_size)

            if (batch_idx + 1) % self.log_interval == 0 or (batch_idx + 1) == len(self.train_loader):
                msg = (
                    f"[{self.stage_name}] Train Epoch [{epoch}] "
                    f"Iter [{batch_idx + 1}/{len(self.train_loader)}] "
                    f"loss={meter_total.avg:.6f}, acc={meter_acc.avg:.4f}"
                )
                # 仅打印若干关键损失，避免日志过长
                key_terms = [
                    "L_sim_cls",
                    "L_real_cls",
                    "L_time_aux",
                    "L_freq_aux",
                    "L_freq_order_coral",
                    "freq_order_coral_mean",
                    "freq_order_coral_cov",
                    "freq_order_coral_num_groups",
                    "L_freq_unknown_shift",
                    "freq_unknown_shift_ce",
                    "freq_unknown_shift_boundary",
                    "freq_unknown_shift_compact",
                    "freq_unknown_shift_delta_norm",
                    "freq_unknown_shift_delta_bank_size",
                    "freq_unknown_shift_delta_bank_fallback",
                    "L_alpha",
                    "L_proto",
                    "L_domain",
                    "L_domain_global",
                    "L_anomaly",
                    "L_target_boundary",
                    "L_proxy_boundary",
                    "proxy_boundary_known_mass_regression",
                    "proxy_boundary_margin_regression",
                    "proxy_boundary_student_known_mass",
                    "proxy_boundary_teacher_known_mass",
                    "proxy_boundary_student_margin",
                    "proxy_boundary_teacher_margin",
                    "L_unknown_shift",
                    "unknown_shift_delta_norm",
                    "unknown_shift_raw_delta_norm",
                    "unknown_shift_scaled_delta_norm",
                    "unknown_shift_delta_bank_size",
                    "unknown_shift_delta_bank_fallback",
                    "L_unknown_proto_synthesis",
                    "unknown_proto_synthesis_ce",
                    "unknown_proto_synthesis_margin",
                    "unknown_proto_synthesis_num_classes",
                    "L_distill",
                    "L_sep",
                ]
                extra = []
                freq_input_source = outputs.get("freq_input_source", None)
                if freq_input_source is not None:
                    extra.append(f"freq_input_source={freq_input_source}")
                for key in key_terms:
                    if key in loss_meters:
                        extra.append(f"{key}={loss_meters[key].avg:.4f}")
                if len(extra) > 0:
                    msg += " | " + ", ".join(extra)
                self.logger.info(msg)

        epoch_time = time.time() - epoch_start

        result = {
            "loss": meter_total.avg,
            "acc": meter_acc.avg,
            "epoch_time_sec": float(epoch_time),
        }
        for k, meter in loss_meters.items():
            result[k] = meter.avg

        fusion_alpha_msg = self._format_fusion_alpha()
        if fusion_alpha_msg is not None:
            self.logger.info(f"[{self.stage_name}] Train Epoch [{epoch}] fusion_alpha={fusion_alpha_msg}")
        return result

    def _validation_mapping_reference(self):
        branches = {
            "time": ("unknown_shift", "z_fault"),
            "frequency": ("freq_unknown_shift", self.loss_cfg["freq_unknown_shift_feature_key"]),
        }
        metadata = {field: [] for field in ("y", "domain", "trainable_in_real", *CONDITION_FIELDS)}
        features = {branch: [] for branch in branches}
        # A second iterator draws a DataLoader seed even with num_workers=0.
        # Restore RNG state so the original validation/training sequence is preserved.
        devices = [self.device] if self.device.type == "cuda" else []
        with torch.random.fork_rng(devices=devices):
            for batch in self.val_loader:
                batch = move_batch_to_device(batch, self.device)
                outputs = self._forward_model(batch)
                for field in metadata:
                    metadata[field].append(batch[field])
                for branch, (_, feature_key) in branches.items():
                    features[branch].append(outputs[feature_key])
        metadata = {key: torch.cat(parts) for key, parts in metadata.items()}
        references = {}
        for branch, (prefix, _) in branches.items():
            references[branch] = build_reference(
                torch.cat(features[branch]), metadata, branch=branch,
                lambda_map=self.loss_cfg["lambda_map"],
                speed_bin_size=self.loss_cfg[f"{prefix}_speed_bin_size"],
                load_bin_size=self.loss_cfg[f"{prefix}_load_bin_size"],
                min_samples_per_bin=self.loss_cfg[f"{prefix}_min_samples_per_bin"],
                use_load=self.loss_cfg[f"{prefix}_use_load_in_condition"],
                known_labels=self.known_real_class_indices,
                target_labels=self.anomaly_class_indices,
                detach_delta=True,
            )
        return references

    @torch.no_grad()
    def validate(self, epoch: int) -> Dict[str, float]:
        """
        在验证集上评估一个 epoch
        """
        self.model.eval()
        epoch_start = time.time()

        meter_total = AverageMeter()
        meter_acc = AverageMeter()
        loss_meters: Dict[str, AverageMeter] = {}

        all_y_true = []
        all_y_pred = []
        all_domains = []

        mapping_reference = None
        if self.loss_cfg.get("lambda_map") is not None:
            mapping_reference = self._validation_mapping_reference()
        for batch_index, batch in enumerate(self.val_loader, 1):
            batch = move_batch_to_device(batch, self.device)
            if mapping_reference is not None:
                batch["local_mapping_reference"] = mapping_reference
                batch["local_mapping_step"] = {"epoch": epoch, "batch": batch_index}

            outputs = self._forward_model(batch)
            teacher_outputs = self._forward_teacher(batch)

            loss_dict = total_loss(
                outputs=outputs,
                batch=batch,
                model=self.model,
                loss_cfg=self.loss_cfg,
                teacher_outputs=teacher_outputs,
                known_real_class_indices=self.known_real_class_indices,
                anomaly_class_indices=self.anomaly_class_indices,
            )

            loss = loss_dict["total"]
            batch_size = batch["x"].size(0)
            pred = torch.argmax(outputs["logits"], dim=1)
            acc = (pred == batch["y"]).float().mean().item()

            all_y_true.extend(batch["y"].detach().cpu().tolist())
            all_y_pred.extend(pred.detach().cpu().tolist())
            all_domains.extend(batch["domain"].detach().cpu().tolist())

            meter_total.update(loss.item(), batch_size)
            meter_acc.update(acc, batch_size)

            detached = detach_loss_dict(loss_dict)
            for k, v in detached.items():
                if k not in loss_meters:
                    loss_meters[k] = AverageMeter()
                loss_meters[k].update(v, batch_size)

        epoch_time = time.time() - epoch_start

        result = {
            "loss": meter_total.avg,
            "acc": meter_acc.avg,
            "epoch_time_sec": float(epoch_time),
        }
        for k, meter in loss_meters.items():
            result[k] = meter.avg

        if len(all_y_true) > 0:
            observed = [
                int(actual == predicted) for actual, predicted, domain in zip(all_y_true, all_y_pred, all_domains)
                if domain == 1 and actual in self.known_real_class_indices
            ]
            sim_unknown = [
                int(actual == predicted) for actual, predicted, domain in zip(all_y_true, all_y_pred, all_domains)
                if domain == 0 and IDX_TO_CLASS[actual] in ("ITSC", "tuici")
            ]
            result["known_real_accuracy"] = sum(observed) / len(observed)
            result["sim_unknown_recall"] = sum(sim_unknown) / len(sim_unknown)
            num_classes = int(self.config["model"]["num_classes"])
            cm = compute_confusion_matrix(all_y_true, all_y_pred, num_classes=num_classes)
            per_class_raw = compute_per_class_accuracy_from_cm(cm)
            per_class_acc = format_per_class_accuracy(
                per_class_raw,
                IDX_TO_CLASS
            )
            macro_recall = self._mean_present(per_class_raw.values())
            unknown_proxy_recall = self._mean_present(
                per_class_raw.get(cls_idx) for cls_idx in self.anomaly_class_indices
            )
            known_real_proxy_recall = self._mean_present(
                per_class_raw.get(cls_idx) for cls_idx in self.known_real_class_indices
            )
            result["val_macro_recall"] = macro_recall
            result["val_unknown_proxy_recall"] = unknown_proxy_recall
            result["val_known_real_proxy_recall"] = known_real_proxy_recall
            result["selection_score"] = (
                0.50 * macro_recall
                + 0.35 * unknown_proxy_recall
                + 0.15 * known_real_proxy_recall
            )
            true_distribution = {
                IDX_TO_CLASS.get(i, str(i)): int(cm[i, :].sum())
                for i in range(num_classes)
            }
            pred_distribution = {
                IDX_TO_CLASS.get(i, str(i)): int(cm[:, i].sum())
                for i in range(num_classes)
            }
            self.logger.info(f"[{self.stage_name}] Val true_distribution={true_distribution}")
            self.logger.info(f"[{self.stage_name}] Val pred_distribution={pred_distribution}")
            self.logger.info(f"[{self.stage_name}] Val per_class_accuracy={per_class_acc}")
            self.logger.info(
                f"[{self.stage_name}] Val selection_metrics="
                f"macro={macro_recall:.4f}, "
                f"unknown_proxy={unknown_proxy_recall:.4f}, "
                f"known_real_proxy={known_real_proxy_recall:.4f}, "
                f"selection_score={result['selection_score']:.4f}"
            )
            self.logger.info(f"[{self.stage_name}] Val confusion_matrix={cm.tolist()}")

        fusion_alpha_msg = self._format_fusion_alpha()
        if fusion_alpha_msg is not None:
            self.logger.info(f"[{self.stage_name}] Val Epoch [{epoch}] fusion_alpha={fusion_alpha_msg}")

        self.logger.info(
            f"[{self.stage_name}] Val Epoch [{epoch}] "
            f"loss={result['loss']:.6f}, acc={result['acc']:.4f}, "
            f"time={result['epoch_time_sec']:.2f}s"
        )
        return result

    def save_checkpoint(
        self,
        epoch: int,
        save_path: str,
        best_val_acc: Optional[float] = None,
        extra_state: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        保存 checkpoint
        """
        ensure_dir(os.path.dirname(save_path) if os.path.dirname(save_path) else ".")

        state = {
            "epoch": int(epoch),
            "stage_name": self.stage_name,
            "best_val_acc": float(self.best_val_acc if best_val_acc is None else best_val_acc),
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "config": self.config,
        }

        if extra_state is not None:
            state["extra_state"] = extra_state

        torch.save(state, save_path)
        self.logger.info(f"[{self.stage_name}] checkpoint 已保存: {save_path}")

    def load_checkpoint(
        self,
        ckpt_path: str,
        load_optimizer: bool = True,
        strict: bool = True
    ) -> Dict[str, Any]:
        """
        从 checkpoint 恢复训练
        """
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"checkpoint 不存在: {ckpt_path}")

        ckpt = torch.load(ckpt_path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state_dict"], strict=strict)

        if load_optimizer and "optimizer_state_dict" in ckpt:
            self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])

        self.current_epoch = int(ckpt.get("epoch", 0))
        self.best_val_acc = float(ckpt.get("best_val_acc", -1.0))
        extra_state = ckpt.get("extra_state", {})
        if isinstance(extra_state, dict):
            self.best_selection_score = float(extra_state.get("best_selection_score", self.best_val_acc))
            saved_tuple = extra_state.get("best_selection_tuple", None)
            if saved_tuple is not None:
                self.best_selection_tuple = tuple(saved_tuple)

        self.logger.info(
            f"[{self.stage_name}] 已恢复 checkpoint: {ckpt_path} | "
            f"epoch={self.current_epoch}, best_val_acc={self.best_val_acc:.4f}"
        )
        return ckpt

    def fit(
        self,
        num_epochs: int,
        save_name: str,
        latest_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        完整训练循环
        """
        best_ckpt_path = os.path.join(self.checkpoint_dir, save_name)
        history = {
            "train": [],
            "val": [],
        }
        selection_metric = self._selection_metric_name()

        start_epoch = self.current_epoch + 1

        for epoch in range(start_epoch, num_epochs + 1):
            self.current_epoch = epoch

            train_metrics = self.train_one_epoch(epoch)
            val_metrics = self.validate(epoch)
            selection_tuple = self._selection_tuple(val_metrics)
            val_metrics["selection_metric"] = selection_metric

            history["train"].append({"epoch": epoch, **train_metrics})
            history["val"].append({"epoch": epoch, **val_metrics})

            # 始终保存 latest
            latest_path = os.path.join(self.checkpoint_dir, latest_name or f"{self.stage_name}_latest.pth")
            self.save_checkpoint(epoch=epoch, save_path=latest_path)

            # 按验证准确率保存 best
            if self.best_selection_tuple is None or selection_tuple > self.best_selection_tuple:
                self.best_val_acc = float(val_metrics["acc"])
                self.best_selection_score = float(selection_tuple[0])
                self.best_selection_tuple = selection_tuple
                self.save_checkpoint(
                    epoch=epoch,
                    save_path=best_ckpt_path,
                    best_val_acc=self.best_val_acc,
                    extra_state={
                        "selection_metric": selection_metric,
                        "best_selection_score": self.best_selection_score,
                        "best_selection_tuple": list(selection_tuple),
                        "best_val_metrics": val_metrics,
                    },
                )
                self.logger.info(
                    f"[{self.stage_name}] 新 best 模型已保存，val_acc={self.best_val_acc:.4f}"
                )

        return {
            "best_val_acc": self.best_val_acc,
            "best_selection_metric": selection_metric,
            "best_selection_score": self.best_selection_score,
            "best_selection_tuple": list(self.best_selection_tuple) if self.best_selection_tuple is not None else None,
            "best_ckpt_path": best_ckpt_path,
            "history": history,
        }


class Stage1Trainer(BaseTrainer):
    """
    Stage1：仿真预训练
    - 只用仿真五类数据
    - teacher_model 一般为 None
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, stage_name="stage1", **kwargs)


class Stage2Trainer(BaseTrainer):
    """
    Stage2：联合迁移训练
    - 仿真五类 + 真实三类
    - 通常带有 Stage1 teacher 模型
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, stage_name="stage2", **kwargs)


class Stage3Trainer(BaseTrainer):
    """
    Stage3：冻结式精调
    - 在 Stage2 基础上，冻结部分底层特征层
    - 继续使用仿真五类 + 真实三类
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, stage_name="stage3", **kwargs)
