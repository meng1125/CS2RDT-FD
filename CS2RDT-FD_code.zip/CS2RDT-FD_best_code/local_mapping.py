"""Health-referenced domain shifts from one Student feature space."""

from dataclasses import dataclass
import json
import math
from typing import Optional

import torch


KNOWN_LABELS = (0, 1, 3)  # Health, OPF, Sensor
TARGET_LABELS = (2, 4)  # ITSC, Demag (tuici)
CONDITION_FIELDS = ("speed", "load")


@dataclass
class MappingReference:
    keys: torch.Tensor
    centers: torch.Tensor
    shifts: torch.Tensor
    diagnostics: torch.Tensor
    bin_sizes: tuple
    known_labels: tuple
    target_labels: tuple


def _conditions(batch, feature, use_load):
    fields = CONDITION_FIELDS if use_load else CONDITION_FIELDS[:1]
    return torch.stack([batch[key].to(feature).reshape(-1) for key in fields], dim=1)


def build_reference(
    feature, batch, *, branch, lambda_map, speed_bin_size, load_bin_size,
    min_samples_per_bin, use_load, known_labels, target_labels, detach_delta,
):
    known_labels = tuple(label for label in KNOWN_LABELS if label in known_labels)
    target_labels = tuple(sorted(target_labels))
    if (
        len(known_labels) not in (2, 3) or known_labels[0] != 0
        or set(known_labels) & set(target_labels)
        or set(known_labels + target_labels) != set(range(5))
    ):
        raise ValueError("Expected Health, one or both observed anchors, and remaining simulated targets")
    anchor_count = len(known_labels)
    group_count = 5 + anchor_count
    if not math.isfinite(lambda_map) or lambda_map <= 0:
        raise ValueError("lambda_map must be finite and strictly positive")
    if feature.ndim != 2 or feature.shape[0] != batch["y"].numel():
        raise ValueError(f"{branch}: expected one feature vector per window, got {feature.shape}")
    if detach_delta:
        feature = feature.detach()
    condition = _conditions(batch, feature, use_load)
    bin_sizes = (speed_bin_size, load_bin_size) if use_load else (speed_bin_size,)
    if any(not math.isfinite(size) or size <= 0 for size in bin_sizes):
        raise ValueError(f"{branch}: bin sizes must be finite and positive")
    sizes = condition.new_tensor(bin_sizes)
    labels = batch["y"].reshape(-1)
    domains = batch["domain"].reshape(-1)
    real = domains == 1
    lookup = labels.new_full((5,), -1)
    lookup[list(known_labels)] = torch.arange(5, group_count, device=labels.device)
    slots = torch.where(real, lookup[labels], labels)
    visible = (domains == 0) | (real & (slots >= 0) & (batch["trainable_in_real"].reshape(-1) == 1))
    if not visible.all().item():
        raise ValueError(f"{branch}: a window outside the Stage 2 fit policy reached the local mapping")
    if not (torch.isfinite(feature).all() & torch.isfinite(condition).all()).item():
        raise FloatingPointError(f"{branch}: non-finite feature or condition in local mapping inputs")

    keys, membership = torch.unique(
        torch.round(condition / sizes) * sizes, return_inverse=True, dim=0
    )
    group_ids = group_count * membership + slots
    counts = torch.bincount(group_ids, minlength=group_count * len(keys)).reshape(-1, group_count)
    complete = (counts >= min_samples_per_bin).all(dim=1)
    if not complete.any().item():
        raise ValueError(f"{branch}: no condition contains all required domain and class groups")

    # Accumulate and solve in float64, then return shifts in the branch's dtype.
    values = torch.cat((feature, condition), dim=1).double()
    totals = values.new_zeros((group_count * len(keys), values.shape[1])).index_add(0, group_ids, values)
    means = totals.reshape(len(keys), group_count, -1)[complete] / counts[complete].unsqueeze(-1)
    dim = feature.shape[1]
    sim = means[:, :5, :dim]
    real = means[:, 5:, :dim]
    anchor_shifts = real - sim[:, known_labels]
    health = anchor_shifts[:, 0]
    relative = anchor_shifts[:, 1:] - health[:, None]
    x = (sim[:, known_labels[1:]] - sim[:, 0:1]).transpose(1, 2)
    q = (sim[:, target_labels] - sim[:, 0:1]).transpose(1, 2)
    xt = x.transpose(1, 2)
    system = xt @ x + lambda_map * torch.eye(anchor_count - 1, dtype=x.dtype, device=x.device)
    rhs = xt @ q
    coefficients, info = torch.linalg.solve_ex(system, rhs)
    corrections = coefficients.transpose(1, 2).unsqueeze(-1) * relative.unsqueeze(1)
    shifts = health[:, None] + corrections.sum(dim=2)

    with torch.no_grad():
        residual = (system @ coefficients - rhs).norm(dim=(1, 2)) / rhs.norm(dim=(1, 2)).clamp_min(1.0)
        eig = torch.linalg.eigvalsh(system)
        diagnostics = torch.stack((
            anchor_shifts.norm(dim=2).amax(dim=1),
            health.norm(dim=1),
            relative.norm(dim=2).amax(dim=1),
            coefficients.abs().amax(dim=(1, 2)),
            shifts.norm(dim=2).amax(dim=1),
            eig[:, -1] / eig[:, 0],
            residual,
        ), dim=1)
        if not ((info == 0).all() & torch.isfinite(diagnostics).all() & (residual < 1e-10).all()).item():
            raise FloatingPointError(f"{branch}: invalid local mapping solve (lambda_map={lambda_map})")
    # Keep the original class-specific operating-point centers in the distance kernel.
    centers = 0.5 * (means[:, known_labels, dim:] + means[:, 5:, dim:])
    shifts = shifts.to(feature)
    if not torch.isfinite(shifts).all().item():
        raise FloatingPointError(f"{branch}: predicted shift overflow after casting to {feature.dtype}")
    return MappingReference(
        keys[complete], centers.to(feature), shifts, diagnostics, bin_sizes, known_labels, target_labels,
    )


DIAGNOSTIC_FIELDS = (
    "anchor_delta_norm_max", "health_delta_norm_max", "relative_anchor_norm_max",
    "coefficient_abs_max", "predicted_delta_norm_max", "condition_number_max", "solve_residual_max",
)


def estimate_shift(
    feature, batch, target_mask, *, branch, lambda_map, speed_bin_size,
    load_bin_size, min_samples_per_bin, use_load, known_labels, target_labels,
    detach_delta, temperature, eps, audit_path: Optional[str] = None,
):
    validation = batch.get("local_mapping_reference")
    reference = validation[branch] if validation is not None else build_reference(
        feature, batch, branch=branch, lambda_map=lambda_map,
        speed_bin_size=speed_bin_size, load_bin_size=load_bin_size,
        min_samples_per_bin=min_samples_per_bin, use_load=use_load,
        known_labels=known_labels, target_labels=target_labels, detach_delta=detach_delta,
    )
    selected = _conditions(batch, feature, use_load)[target_mask]
    centers = reference.centers.flatten(0, 1)
    norm_source = torch.cat((centers, selected), dim=0)
    center = norm_source.mean(dim=0)
    scale = norm_source.std(dim=0, unbiased=False).clamp_min(eps)
    distance = torch.cdist((selected - center) / scale, (centers - center) / scale).square()
    weights = torch.softmax(-distance / max(float(temperature), eps), dim=1)
    condition_weights = weights.reshape(len(selected), len(reference.keys), len(reference.known_labels)).sum(dim=2)
    target_ids = batch["y"].new_tensor(reference.target_labels)
    target_indices = torch.searchsorted(target_ids, batch["y"][target_mask])
    shifts_by_sample = reference.shifts.transpose(0, 1)[target_indices]
    shifted_delta = torch.bmm(condition_weights.unsqueeze(1), shifts_by_sample).squeeze(1)

    sizes = selected.new_tensor(reference.bin_sizes)
    selected_bins = torch.round(selected / sizes) * sizes
    matched = (selected_bins[:, None] == reference.keys[None]).all(dim=2).any(dim=1)
    if not (torch.isfinite(shifted_delta).all() & matched.all()).item():
        raise FloatingPointError(f"{branch}: non-finite weighted shift or missing complete query condition")

    if audit_path:
        with torch.no_grad():
            norm = shifted_delta.norm(dim=1)
            fields = DIAGNOSTIC_FIELDS + ("applied_delta_norm_mean", "applied_delta_norm_max", "weight_error")
            stats = torch.cat((
                reference.diagnostics.amax(dim=0).float(),
                torch.stack((norm.mean(), norm.max(), (condition_weights.sum(dim=1) - 1).abs().max())),
            )).cpu().tolist()
            event = {
                "branch": branch, "phase": "train" if validation is None else "val",
                "n_samples": len(selected), "n_conditions": len(reference.keys),
                **batch.get("local_mapping_step", {}),
                **dict(zip(fields, stats)),
            }
            with open(audit_path, "a", encoding="utf-8") as log:
                log.write(json.dumps(event, allow_nan=False) + "\n")

    return shifted_delta, feature.new_tensor(float(len(reference.keys)))
