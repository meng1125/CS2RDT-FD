# physics_fusion.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import copy
import json
import math
import os
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


CLASS_TO_IDX = {"health": 0, "OPF": 1, "ITSC": 2, "Sensor": 3, "tuici": 4}
IDX_TO_CLASS = {v: k for k, v in CLASS_TO_IDX.items()}
KNOWN_CLASS_NAMES = ("health", "OPF", "Sensor")
UNKNOWN_CLASS_NAMES = ("ITSC", "tuici")
INPUT_COLUMNS = ["v", "id", "iq", "ix", "iy", "ia", "ib", "id2", "ie", "ud", "uq", "ux", "uy"]
NOMINAL_FEATURE_NAMES = [
    "id_mean",
    "iq_mean",
    "ud_mean",
    "omega_e",
    "speed",
    "load",
    "omega_e_id_mean",
    "omega_e_iq_mean",
    "id_std",
    "iq_std",
]

DEFAULT_PHYSICS_CONFIG: Dict[str, Any] = {
    "enabled": True,
    "apply_correction": False,
    "reference_path": "checkpoints/physics_reference_stage2.json",
    "class_order": ["health", "OPF", "ITSC", "Sensor", "tuici"],
    "class_map": copy.deepcopy(CLASS_TO_IDX),
    "input_columns": list(INPUT_COLUMNS),
    "sampling_rate_hz": 10000.0,
    "pole_pairs": 5.0,
    "rs": 0.96,
    "ld": 0.0085,
    "eps": 1.0e-8,
    "residual_weight": 1.0,
    "psi_drop_weight": 1.0,
    "itsc_score_weights": {
        "local_nonuniformity_score": 0.35,
        "waveform_local_imbalance_score": 0.25,
        "freq_local_imbalance_score": 0.25,
        "dq24_score": 0.10,
        "ia3_score": 0.05,
    },
    "a_phase_structural_weights": {
        "ia3_excess_over_bc": 0.55,
        "ia_rms_excess_over_bc": 0.25,
        "a_phase_rms_asym": 0.20,
    },
    "condition_background": {
        "min_count": 8,
    },
    "boundary": {"alpha": 0.5, "gamma": 1.0},
    "thresholds": {
        "threshold_itsc_over_tuici": 1.0e9,
        "known_expert_conf": 1.0,
        "known_expert_margin": 1.0,
        "unknown_score_max": -1.0e9,
        "health_like_min": 1.0e9,
        "health_rescue_margin_max": -1.0e9,
        "i1_itsc_like_min": 1.0e9,
        "i1_itsc_over_tuici_min": 1.0e9,
        "i1_local_min": 1.0e9,
        "i1_local_max": 1.0e9,
        "i1_opf_f_zero_max": -1.0e9,
        "i1_freq_itsc_prob_min": 1.0,
        "i1_freq_margin_opf_min": 1.0,
        "i1_known_conf_max": -1.0e9,
        "thr_opf_f_zero_high": 1.0e9,
        "thr_if_to_de_low": -1.0e9,
        "thr_known_opf_conf_high": 1.0,
        "thr_known_opf_margin_high": 1.0,
        "thr_freq_opf_conf_high": 1.0,
        "thr_base_opf_conf_high": 1.0,
        "thr_freq_itsc_over_opf_max_for_opf": -1.0e9,
        "thr_base_itsc_over_opf_max_for_opf": -1.0e9,
        "thr_itsc_ultra": 1.0e9,
        "thr_margin_ultra": 1.0e9,
        "thr_freq_itsc_ultra": 1.0,
        "thr_freq_margin_opf_ultra": 1.0,
        "i2_itsc_like_min": 1.0e9,
        "i2_waveform_min": 1.0e9,
        "i2_itsc_over_tuici_min": 1.0e9,
        "i2_freq_itsc_prob_min": 1.0,
        "i2_known_conf_max": -1.0e9,
        "thr_tuici_bg_high": 1.0e9,
        "thr_psi_drop_bg_high": 1.0e9,
        "thr_itsc_veto_like": 1.0e9,
        "thr_itsc_veto_freq": 1.0,
        "thr_itsc_veto_margin": 1.0e9,
        "thr_opf_f_open_pattern_strong": 1.0e9,
        "thr_cond_h3_health_to_itsc": 1.0e9,
        "thr_cond_a_phase_health_to_itsc": 1.0e9,
        "thr_cond_waveform_health_to_itsc": 1.0e9,
        "thr_health_conf_max_for_itsc_override": -1.0e9,
        "thr_itsc_not_opf": 1.0e9,
        "thr_a_phase_structural": 1.0e9,
        "thr_freq_margin_relaxed": 1.0,
        "thr_i3b_struct_a_phase_high_safe": 1.0e9,
        "thr_i3b_struct_itsc_not_opf_high_safe": 1.0e9,
        "thr_i3b_struct_opf_open_max_safe": -1.0e9,
        "thr_i3b_struct_freq_opf_veto_high_safe": 1.0,
        "thr_i3b_struct_freq_itsc_veto_low_safe": 0.0,
        "thr_i3b_struct_a_phase_high_balanced": 1.0e9,
        "thr_i3b_struct_itsc_not_opf_high_balanced": 1.0e9,
        "thr_i3b_struct_opf_open_max_balanced": -1.0e9,
        "thr_i3b_struct_freq_opf_veto_high_balanced": 1.0,
        "thr_i3b_struct_freq_itsc_veto_low_balanced": 0.0,
        "thr_i3b_struct_a_phase_high_aggressive": 1.0e9,
        "thr_i3b_struct_itsc_not_opf_high_aggressive": 1.0e9,
        "thr_i3b_struct_opf_open_max_aggressive": -1.0e9,
        "thr_i3b_struct_freq_opf_veto_high_aggressive": 1.0,
        "thr_i3b_struct_freq_itsc_veto_low_aggressive": 0.0,
        "thr_segment_if_to_de_min": 1.0e9,
        "thr_segment_opf_f_zero_max": -1.0e9,
        "thr_segment_opf_open_max": -1.0e9,
        "thr_segment_itsc_vote_min": 1.0,
        "thr_segment_prob_itsc_min": 1.0,
        "thr_segment_prob_opf_max": -1.0e9,
        "thr_segment_a_phase_min": 1.0e9,
        "thr_segment_itsc_not_opf_min": 1.0e9,
    },
    "rules": {
        "enable_tuici_to_itsc": False,
        "enable_flux_demag_rescue": True,
        "enable_unknown_to_known_rescue": False,
        "enable_health_rescue": False,
        "enable_opf_to_itsc": True,
        "enable_health_to_itsc": True,
        "enable_a_phase_structural_itsc_rescue": True,
        "enable_i3a_health_to_itsc": False,
        "enable_i3b_freq_margin_rule": False,
        "enable_i3b_structural_override": False,
        "enable_segment_opf_itsc_refinement": True,
        "a_phase_structural_mode": "safe",
    },
    "known_expert": {
        "source": "prob_known_subset",
        "known_classes": ["health", "OPF", "Sensor"],
    },
    "leakage_policy": {
        "forbidden_for_selection": ["real_ITSC", "real_tuici"],
        "allowed_selection_sources": ["sim_train", "sim_val", "real_known_train", "real_known_val"],
    },
}

_REFERENCE_CACHE: Dict[str, Tuple[float, Dict[str, Any]]] = {}


def _deep_merge(base: Dict[str, Any], override: Mapping[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)  # type: ignore[arg-type]
        else:
            out[key] = copy.deepcopy(value)
    return out


def _project_root() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def _resolve_path(path: str) -> str:
    if os.path.isabs(path):
        return path
    return os.path.join(_project_root(), path)


def _load_reference(path: str) -> Dict[str, Any]:
    full_path = _resolve_path(path)
    if not os.path.exists(full_path):
        return {}
    mtime = os.path.getmtime(full_path)
    cached = _REFERENCE_CACHE.get(full_path)
    if cached is not None and cached[0] == mtime:
        return copy.deepcopy(cached[1])
    with open(full_path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    ref_cfg = obj.get("physics_fusion", obj)
    _REFERENCE_CACHE[full_path] = (mtime, copy.deepcopy(ref_cfg))
    return copy.deepcopy(ref_cfg)


def prepare_physics_config(config: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    root_cfg = config or {}
    user_cfg = root_cfg.get("physics_fusion", root_cfg) if isinstance(root_cfg, Mapping) else {}
    cfg = _deep_merge(DEFAULT_PHYSICS_CONFIG, user_cfg if isinstance(user_cfg, Mapping) else {})
    ref_path = str(cfg.get("reference_path", ""))
    if ref_path:
        ref_cfg = _load_reference(ref_path)
        if ref_cfg:
            # Reference files contain frozen fitted quantities. Runtime switches
            # must stay controlled by config.yaml, otherwise a reference fitted
            # with apply_correction=false silently disables deployment rules.
            ref_cfg = {
                k: v for k, v in ref_cfg.items()
                if k not in {"enabled", "apply_correction", "rules", "reference_path"}
            }
            cfg = _deep_merge(cfg, ref_cfg)
    return cfg


def _as_window_ct(x_raw: np.ndarray, input_columns: Sequence[str]) -> np.ndarray:
    arr = np.asarray(x_raw, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError(f"x_raw must be 2D, got shape={arr.shape}")
    n_ch = len(input_columns)
    if arr.shape[0] == n_ch:
        return arr
    if arr.shape[1] == n_ch:
        return arr.T
    raise ValueError(f"x_raw channel count mismatch, expected {n_ch}, got shape={arr.shape}")


def _ch(x_ct: np.ndarray, columns: Sequence[str], name: str) -> np.ndarray:
    if name not in columns:
        return np.zeros(x_ct.shape[1], dtype=np.float64)
    return x_ct[columns.index(name)].astype(np.float64, copy=False)


def _safe_mean(x: np.ndarray) -> float:
    return float(np.mean(np.asarray(x, dtype=np.float64)))


def _safe_std(x: np.ndarray) -> float:
    return float(np.std(np.asarray(x, dtype=np.float64)))


def _rms(x: np.ndarray, eps: float = 1.0e-12) -> float:
    arr = np.asarray(x, dtype=np.float64)
    return float(np.sqrt(np.mean(arr * arr) + eps))


def _robust_center_scale(values: Sequence[float], min_scale: float = 1.0e-8) -> Tuple[float, float]:
    arr = np.asarray(list(values), dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return 0.0, 1.0
    center = float(np.median(arr))
    mad = float(np.median(np.abs(arr - center)) * 1.4826)
    q_scale = float((np.percentile(arr, 75) - np.percentile(arr, 25)) / 1.349) if arr.size > 1 else 0.0
    scale = max(mad, q_scale, float(np.std(arr)), min_scale)
    return center, scale


def _z(value: float, center: float, scale: float, eps: float) -> float:
    return float((float(value) - float(center)) / (abs(float(scale)) + eps))


def _sigmoid(x: float) -> float:
    x = float(x)
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def _omega_e(speed_rpm: float, pole_pairs: float) -> float:
    return float(2.0 * math.pi * float(speed_rpm) / 60.0 * float(pole_pairs))


def _order_energy_ratio(signal: np.ndarray, sampling_rate_hz: float, speed: float, pole_pairs: float, order: float, band_hz: float = 5.0) -> float:
    x = np.asarray(signal, dtype=np.float64)
    if x.size < 8 or not np.isfinite(speed):
        return 0.0
    x = x - np.mean(x)
    spec = np.abs(np.fft.rfft(x * np.hanning(x.size))) ** 2
    freqs = np.fft.rfftfreq(x.size, d=1.0 / float(sampling_rate_hz))
    total = float(np.sum(spec) + 1.0e-12)
    f0 = abs(float(speed)) / 60.0 * float(pole_pairs)
    if f0 <= 1.0e-12:
        return 0.0
    center = float(order) * f0
    mask = (freqs >= max(0.0, center - band_hz)) & (freqs <= center + band_hz)
    return float(np.sum(spec[mask]) / total)


def _low_order_energy_ratio(signal: np.ndarray, sampling_rate_hz: float, speed: float, pole_pairs: float, max_order: int = 6) -> float:
    return float(sum(_order_energy_ratio(signal, sampling_rate_hz, speed, pole_pairs, order) for order in range(1, max_order + 1)))


def _nominal_features_from_basic(basic: Mapping[str, float], pole_pairs: float) -> Dict[str, float]:
    omega_e = _omega_e(float(basic["speed"]), pole_pairs)
    id_mean = float(basic["id_mean"])
    iq_mean = float(basic["iq_mean"])
    return {
        "id_mean": id_mean,
        "iq_mean": iq_mean,
        "ud_mean": float(basic["ud_mean"]),
        "omega_e": omega_e,
        "speed": float(basic["speed"]),
        "load": float(basic["load"]),
        "omega_e_id_mean": omega_e * id_mean,
        "omega_e_iq_mean": omega_e * iq_mean,
        "id_std": float(basic["id_std"]),
        "iq_std": float(basic["iq_std"]),
    }


def _predict_nominal_uq(nominal_features: Mapping[str, float], reference: Mapping[str, Any]) -> float:
    model = reference.get("nominal_uq_model", {})
    intercept = float(model.get("intercept", 0.0))
    coefficients = model.get("coefficients", {})
    pred = intercept
    for name in NOMINAL_FEATURE_NAMES:
        pred += float(coefficients.get(name, 0.0)) * float(nominal_features.get(name, 0.0))
    return float(pred)


def compute_window_physics_features(
    x_raw: np.ndarray,
    speed: float,
    load: float,
    config: Optional[Mapping[str, Any]] = None,
) -> Dict[str, float]:
    cfg = prepare_physics_config(config)
    columns = list(cfg["input_columns"])
    eps = float(cfg["eps"])
    x = _as_window_ct(np.asarray(x_raw), columns)

    id_ = _ch(x, columns, "id")
    iq = _ch(x, columns, "iq")
    ia = _ch(x, columns, "ia")
    ib = _ch(x, columns, "ib")
    id2 = _ch(x, columns, "id2")
    ie = _ch(x, columns, "ie")
    ud = _ch(x, columns, "ud")
    uq = _ch(x, columns, "uq")
    ux = _ch(x, columns, "ux")
    uy = _ch(x, columns, "uy")

    ic = -ia - ib
    if_current = -id2 - ie
    iab_diff = ia - ib
    ia_rms = _rms(ia)
    ib_rms = _rms(ib)
    ic_rms = _rms(ic)
    id2_rms = _rms(id2)
    ie_rms = _rms(ie)
    if_rms = _rms(if_current)
    de_f = np.asarray([id2_rms, ie_rms, if_rms], dtype=np.float64)
    abc = np.asarray([ia_rms, ib_rms, ic_rms], dtype=np.float64)
    phase_all = np.concatenate([abc, de_f])
    abc_mean = float(np.mean(abc) + eps)
    de_f_mean = float(np.mean(de_f) + eps)
    de_median = float(np.median([id2_rms, ie_rms]) + eps)
    if_to_de_median = float(if_rms / de_median)
    opf_f_zero_score = float(max(0.0, min(1.0, 1.0 - if_to_de_median)))

    sampling_rate_hz = float(cfg["sampling_rate_hz"])
    pole_pairs = float(cfg["pole_pairs"])
    id_order2 = _order_energy_ratio(id_, sampling_rate_hz, speed, pole_pairs, 2.0)
    iq_order2 = _order_energy_ratio(iq, sampling_rate_hz, speed, pole_pairs, 2.0)
    id_order4 = _order_energy_ratio(id_, sampling_rate_hz, speed, pole_pairs, 4.0)
    iq_order4 = _order_energy_ratio(iq, sampling_rate_hz, speed, pole_pairs, 4.0)
    ia_order3 = _order_energy_ratio(ia, sampling_rate_hz, speed, pole_pairs, 3.0)
    ib_order3 = _order_energy_ratio(ib, sampling_rate_hz, speed, pole_pairs, 3.0)
    ic_order3 = _order_energy_ratio(ic, sampling_rate_hz, speed, pole_pairs, 3.0)
    iab_low = _low_order_energy_ratio(iab_diff, sampling_rate_hz, speed, pole_pairs, 6)
    if_low = _low_order_energy_ratio(if_current, sampling_rate_hz, speed, pole_pairs, 6)

    omega_e = _omega_e(speed, pole_pairs)
    id_mean = _safe_mean(id_)
    iq_mean = _safe_mean(iq)
    uq_mean = _safe_mean(uq)
    psi_eff = (uq_mean - float(cfg["rs"]) * iq_mean - omega_e * float(cfg["ld"]) * id_mean) / (omega_e + eps)

    local_raw = float(np.std(phase_all) / (np.mean(phase_all) + eps) + np.std(de_f) / de_f_mean + 0.5 * if_to_de_median)
    waveform_raw = float(local_raw + 0.25 * _rms(iab_diff) / abc_mean + 0.25 * (np.ptp(if_current) / de_median))
    freq_raw = float(iab_low + if_low + ia_order3)
    dq24_raw = float(id_order2 + iq_order2 + id_order4 + iq_order4)
    sensor_raw = float((_safe_std(ud) + _safe_std(uq) + _safe_std(ux) + _safe_std(uy)) / (_rms(ud) + _rms(uq) + eps))
    bc_rms_median = float(np.median([ib_rms, ic_rms]) + eps)
    abc_rms_median = float(np.median([ia_rms, ib_rms, ic_rms]) + eps)
    ia3_excess_over_bc = float(ia_order3 - np.median([ib_order3, ic_order3]))
    ia_rms_excess_over_bc = float(ia_rms / bc_rms_median)
    a_phase_rms_asym = float(max(abs(ia_rms - ib_rms), abs(ia_rms - ic_rms)) / abc_rms_median)
    second_set_imbalance = float(np.std(de_f) / (float(np.mean(de_f)) + eps))

    return {
        "speed": float(speed),
        "load": float(load),
        "omega_e": float(omega_e),
        "id_mean": id_mean,
        "iq_mean": iq_mean,
        "ud_mean": _safe_mean(ud),
        "uq_mean": uq_mean,
        "id_std": _safe_std(id_),
        "iq_std": _safe_std(iq),
        "psi_eff": float(psi_eff),
        "ia_rms": float(ia_rms),
        "ib_rms": float(ib_rms),
        "ic_rms": float(ic_rms),
        "id2_rms": float(id2_rms),
        "ie_rms": float(ie_rms),
        "if_rms": float(if_rms),
        "phase_imbalance": float(np.std(abc) / abc_mean),
        "de_f_imbalance": float(np.std(de_f) / de_f_mean),
        "if_to_de_median": float(if_to_de_median),
        "opf_f_zero_score": float(opf_f_zero_score),
        "iab_diff_rms": float(_rms(iab_diff)),
        "if_current_rms": float(if_rms),
        "local_nonuniformity_raw": local_raw,
        "waveform_local_imbalance_raw": waveform_raw,
        "id_order2_ratio": float(id_order2),
        "iq_order2_ratio": float(iq_order2),
        "id_order4_ratio": float(id_order4),
        "iq_order4_ratio": float(iq_order4),
        "ia_order3_ratio": float(ia_order3),
        "ib_order3_ratio": float(ib_order3),
        "ic_order3_ratio": float(ic_order3),
        "ia3_excess_over_bc": float(ia3_excess_over_bc),
        "ia_rms_excess_over_bc": float(ia_rms_excess_over_bc),
        "a_phase_rms_asym": float(a_phase_rms_asym),
        "second_set_imbalance": float(second_set_imbalance),
        "iab_diff_low_order_energy_1_6": float(iab_low),
        "if_current_low_order_energy_1_6": float(if_low),
        "freq_local_imbalance_raw": freq_raw,
        "dq24_raw": dq24_raw,
        "ia3_raw": float(ia_order3),
        "sensor_raw": sensor_raw,
    }


def compute_tuici_like_score(features: Mapping[str, float], config: Optional[Mapping[str, Any]] = None) -> Dict[str, float]:
    cfg = prepare_physics_config(config)
    ref = cfg.get("reference", {})
    eps = float(cfg["eps"])
    nominal_features = _nominal_features_from_basic(features, float(cfg["pole_pairs"]))
    nominal_uq_pred = _predict_nominal_uq(nominal_features, ref)
    flux_residual = float(features["uq_mean"]) - nominal_uq_pred
    residual_center = float(ref.get("residual_center", 0.0))
    residual_scale = float(ref.get("residual_scale", 1.0))
    psi_eff_health_mean = float(ref.get("psi_eff_health_mean", 0.0))
    psi_eff_scale = float(ref.get("psi_eff_scale", 1.0))
    direction = float(ref.get("demag_residual_direction", 1.0))
    flux_residual_z = _z(flux_residual, residual_center, residual_scale, eps)
    psi_eff_drop_z = (psi_eff_health_mean - float(features["psi_eff"])) / (abs(psi_eff_scale) + eps)
    score = float(
        float(cfg.get("residual_weight", 1.0)) * direction * flux_residual_z
        + float(cfg.get("psi_drop_weight", 1.0)) * psi_eff_drop_z
    )
    return {
        "psi_eff": float(features["psi_eff"]),
        "nominal_uq_pred": float(nominal_uq_pred),
        "flux_residual": float(flux_residual),
        "flux_residual_z": float(flux_residual_z),
        "psi_eff_drop_z": float(psi_eff_drop_z),
        "tuici_like_score": score,
        "demag_residual_direction": direction,
    }


def compute_itsc_like_score(features: Mapping[str, float], config: Optional[Mapping[str, Any]] = None) -> Dict[str, float]:
    cfg = prepare_physics_config(config)
    ref = cfg.get("reference", {})
    score_ref = ref.get("score_reference", {})
    eps = float(cfg["eps"])
    local = _z(features["local_nonuniformity_raw"], score_ref.get("local_nonuniformity_center", 0.0), score_ref.get("local_nonuniformity_scale", 1.0), eps)
    waveform = _z(features["waveform_local_imbalance_raw"], score_ref.get("waveform_center", 0.0), score_ref.get("waveform_scale", 1.0), eps)
    freq = _z(features["freq_local_imbalance_raw"], score_ref.get("freq_center", 0.0), score_ref.get("freq_scale", 1.0), eps)
    dq24 = _z(features["dq24_raw"], score_ref.get("dq24_center", 0.0), score_ref.get("dq24_scale", 1.0), eps)
    ia3 = _z(features["ia3_raw"], score_ref.get("ia3_center", 0.0), score_ref.get("ia3_scale", 1.0), eps)
    weights = cfg["itsc_score_weights"]
    itsc_like = float(
        float(weights["local_nonuniformity_score"]) * local
        + float(weights["waveform_local_imbalance_score"]) * waveform
        + float(weights["freq_local_imbalance_score"]) * freq
        + float(weights["dq24_score"]) * dq24
        + float(weights["ia3_score"]) * ia3
    )
    health_abnormal_raw = abs(float(features.get("flux_residual_z", 0.0))) + max(0.0, local) + max(0.0, freq)
    health_like = -_z(health_abnormal_raw, score_ref.get("health_abnormal_center", 0.0), score_ref.get("health_abnormal_scale", 1.0), eps)
    sensor_like = _z(features["sensor_raw"], score_ref.get("sensor_like_center", 0.0), score_ref.get("sensor_like_scale", 1.0), eps)
    return {
        "local_nonuniformity_score": float(local),
        "waveform_local_imbalance_score": float(waveform),
        "freq_local_imbalance_score": float(freq),
        "dq24_score": float(dq24),
        "ia3_score": float(ia3),
        "itsc_like_score": itsc_like,
        "health_like_score": float(health_like),
        "sensor_like_score": float(sensor_like),
    }


def compute_a_phase_structural_score(features: Mapping[str, float], config: Optional[Mapping[str, Any]] = None) -> Dict[str, float]:
    cfg = prepare_physics_config(config)
    ref = cfg.get("reference", {})
    score_ref = ref.get("score_reference", {})
    eps = float(cfg["eps"])
    ia3_excess_z = _z(
        features.get("ia3_excess_over_bc", 0.0),
        score_ref.get("ia3_excess_over_bc_center", 0.0),
        score_ref.get("ia3_excess_over_bc_scale", 1.0),
        eps,
    )
    ia_rms_excess_z = _z(
        features.get("ia_rms_excess_over_bc", 1.0),
        score_ref.get("ia_rms_excess_over_bc_center", 1.0),
        score_ref.get("ia_rms_excess_over_bc_scale", 1.0),
        eps,
    )
    a_phase_rms_asym_z = _z(
        features.get("a_phase_rms_asym", 0.0),
        score_ref.get("a_phase_rms_asym_center", 0.0),
        score_ref.get("a_phase_rms_asym_scale", 1.0),
        eps,
    )
    opf_f_zero_z = _z(
        features.get("opf_f_zero_score", 0.0),
        score_ref.get("opf_f_zero_score_center", 0.0),
        score_ref.get("opf_f_zero_score_scale", 1.0),
        eps,
    )
    second_set_imbalance_z = _z(
        features.get("second_set_imbalance", 0.0),
        score_ref.get("second_set_imbalance_center", 0.0),
        score_ref.get("second_set_imbalance_scale", 1.0),
        eps,
    )
    if_to_de_median_z = _z(
        features.get("if_to_de_median", 1.0),
        score_ref.get("if_to_de_median_center", 1.0),
        score_ref.get("if_to_de_median_scale", 1.0),
        eps,
    )
    weights = cfg.get("a_phase_structural_weights", {})
    a_phase_local = float(
        float(weights.get("ia3_excess_over_bc", 0.55)) * ia3_excess_z
        + float(weights.get("ia_rms_excess_over_bc", 0.25)) * ia_rms_excess_z
        + float(weights.get("a_phase_rms_asym", 0.20)) * a_phase_rms_asym_z
    )
    opf_f_open = float(opf_f_zero_z + second_set_imbalance_z - if_to_de_median_z)
    itsc_not_opf = float(
        a_phase_local
        + float(features.get("local_nonuniformity_score", 0.0))
        - opf_f_open
    )
    return {
        "ia3_excess_over_bc_z": float(ia3_excess_z),
        "ia_rms_excess_over_bc_z": float(ia_rms_excess_z),
        "a_phase_rms_asym_z": float(a_phase_rms_asym_z),
        "opf_f_zero_score_z": float(opf_f_zero_z),
        "second_set_imbalance_z": float(second_set_imbalance_z),
        "if_to_de_median_z": float(if_to_de_median_z),
        "a_phase_local_harmonic_score": float(a_phase_local),
        "opf_f_open_pattern_score": float(opf_f_open),
        "itsc_not_opf_score": float(itsc_not_opf),
    }


def _condition_key(speed: float, load: float) -> str:
    return f"{float(speed):.6g}|{float(load):.6g}"


def _condition_neighbor_keys(speed: float, load: float, condition_reference: Mapping[str, Any]) -> List[Tuple[str, str]]:
    conditions = condition_reference.get("conditions", {})
    speeds = sorted(float(v) for v in condition_reference.get("speeds", []))
    loads = sorted(float(v) for v in condition_reference.get("loads", []))
    speed_f = float(speed)
    load_f = float(load)
    keys: List[Tuple[str, str]] = [("same_load_speed", _condition_key(speed_f, load_f))]
    if speeds:
        nearby_speeds = sorted(speeds, key=lambda v: abs(v - speed_f))
        for sp in nearby_speeds[:3]:
            key = _condition_key(sp, load_f)
            if key in conditions and key not in [k for _, k in keys]:
                keys.append(("nearby_speed_same_load", key))
    if loads:
        nearby_loads = sorted(loads, key=lambda v: abs(v - load_f))
        for ld in nearby_loads[:3]:
            key = _condition_key(speed_f, ld)
            if key in conditions and key not in [k for _, k in keys]:
                keys.append(("same_speed_nearby_load", key))
    if speeds:
        for sp in sorted(speeds, key=lambda v: abs(v - speed_f))[:3]:
            for ld in loads:
                key = _condition_key(sp, ld)
                if key in conditions and key not in [k for _, k in keys]:
                    keys.append(("same_speed_group", key))
    keys.append(("global_real_known_health", "__global__"))
    return keys


def compute_condition_background_scores(features: Mapping[str, float], config: Optional[Mapping[str, Any]] = None) -> Dict[str, float]:
    cfg = prepare_physics_config(config)
    ref = cfg.get("reference", {})
    cond_ref = ref.get("condition_health_reference", {})
    global_ref = cond_ref.get("global", {})
    conditions = cond_ref.get("conditions", {})
    eps = float(cfg["eps"])
    selected: Mapping[str, Any] = global_ref
    selected_scope = "global_real_known_health"
    selected_key = "__global__"
    min_count = int(cfg.get("condition_background", {}).get("min_count", 8))
    for scope, key in _condition_neighbor_keys(float(features.get("speed", 0.0)), float(features.get("load", 0.0)), cond_ref):
        candidate = global_ref if key == "__global__" else conditions.get(key, {})
        if int(candidate.get("count", 0)) >= min_count:
            selected = candidate
            selected_scope = scope
            selected_key = key
            break

    def cz(field: str, value: float) -> float:
        center = float(selected.get(f"{field}_center", global_ref.get(f"{field}_center", 0.0)))
        scale = float(selected.get(f"{field}_scale", global_ref.get(f"{field}_scale", 1.0)))
        return _z(value, center, scale, eps)

    return {
        "a_phase_h3_excess_z_cond": cz("ia3_excess_over_bc", float(features.get("ia3_excess_over_bc", 0.0))),
        "a_phase_local_harmonic_z_cond": cz("a_phase_local_harmonic_score", float(features.get("a_phase_local_harmonic_score", 0.0))),
        "local_nonuniformity_z_cond": cz("local_nonuniformity_score", float(features.get("local_nonuniformity_score", 0.0))),
        "waveform_z_cond": cz("waveform_local_imbalance_score", float(features.get("waveform_local_imbalance_score", 0.0))),
        "condition_background_count": float(selected.get("count", 0)),
        "condition_background_scope_id": float({
            "same_load_speed": 0,
            "nearby_speed_same_load": 1,
            "same_speed_nearby_load": 2,
            "same_speed_group": 3,
            "global_real_known_health": 4,
        }.get(selected_scope, 4)),
        "condition_background_key_hash": float(abs(hash(str(selected_key))) % 1000000),
    }


def _row_value(row: Mapping[str, Any], key: str, default: float = float("nan")) -> float:
    if key in row:
        try:
            return float(row.get(key, default))
        except (TypeError, ValueError):
            return float(default)
    scores = row.get("scores", {})
    if isinstance(scores, Mapping) and key in scores:
        try:
            return float(scores.get(key, default))
        except (TypeError, ValueError):
            return float(default)
    return float(default)


def _row_group_key(row: Mapping[str, Any]) -> str:
    scope_parts: List[str] = []
    for scope_key in ("source", "domain_name"):
        scope_value = row.get(scope_key)
        if scope_value not in (None, ""):
            scope_parts.append(f"{scope_key}={scope_value}")
    for key in ("record_id", "record_idx", "file_path", "filename"):
        value = row.get(key)
        if value not in (None, ""):
            return "::".join([*scope_parts, f"{key}={value}"])
    if scope_parts:
        return "::".join([*scope_parts, "unknown_record"])
    return "__unknown__"


def _row_window_idx(row: Mapping[str, Any]) -> int:
    value = row.get("window_idx", row.get("sample_index", 0))
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _segment_summaries_from_rows(
    rows: Sequence[Mapping[str, Any]],
    pred_key: str = "physics_pred_idx",
) -> List[Dict[str, Any]]:
    by_group: Dict[str, List[Mapping[str, Any]]] = {}
    for row in rows:
        by_group.setdefault(_row_group_key(row), []).append(row)

    segments: List[Dict[str, Any]] = []
    for group_key, group_rows in by_group.items():
        ordered = sorted(group_rows, key=_row_window_idx)
        current: List[Mapping[str, Any]] = []
        last_idx: Optional[int] = None
        segment_ordinal = 0
        for row in ordered:
            idx = _row_window_idx(row)
            if current and last_idx is not None and idx > last_idx + 1:
                segments.append(_summarize_segment(group_key, segment_ordinal, current, pred_key))
                segment_ordinal += 1
                current = []
            current.append(row)
            last_idx = idx
        if current:
            segments.append(_summarize_segment(group_key, segment_ordinal, current, pred_key))
    return segments


def _median_row_value(rows: Sequence[Mapping[str, Any]], key: str, default: float = 0.0) -> float:
    vals = [_row_value(row, key) for row in rows]
    vals = [v for v in vals if np.isfinite(v)]
    if not vals:
        return float(default)
    return float(np.median(np.asarray(vals, dtype=np.float64)))


def _summarize_segment(
    group_key: str,
    segment_ordinal: int,
    rows: Sequence[Mapping[str, Any]],
    pred_key: str,
) -> Dict[str, Any]:
    preds = []
    for row in rows:
        try:
            preds.append(int(row.get(pred_key, row.get("base_pred_idx", -1))))
        except (TypeError, ValueError):
            preds.append(-1)
    prob_itsc_key = "base_prob_itsc"
    prob_opf_key = "base_prob_opf"
    summary = {
        "segment_group_key": str(group_key),
        "segment_id": f"{group_key}#{segment_ordinal}",
        "segment_ordinal": int(segment_ordinal),
        "source": str(rows[0].get("source", "")),
        "domain_name": str(rows[0].get("domain_name", "")),
        "label_name": str(rows[0].get("label_name", rows[0].get("true_label_name", ""))),
        "segment_start_window_idx": int(min(_row_window_idx(row) for row in rows)),
        "segment_end_window_idx": int(max(_row_window_idx(row) for row in rows)),
        "segment_num_windows": int(len(rows)),
        "segment_if_to_de_median": _median_row_value(rows, "if_to_de_median"),
        "segment_opf_f_zero_score_median": _median_row_value(rows, "opf_f_zero_score"),
        "segment_opf_f_open_pattern_score_median": _median_row_value(rows, "opf_f_open_pattern_score"),
        "segment_itsc_vote_ratio": float(sum(1 for p in preds if p == CLASS_TO_IDX["ITSC"]) / max(len(preds), 1)),
        "segment_prob_itsc_median": _median_row_value(rows, prob_itsc_key),
        "segment_prob_opf_median": _median_row_value(rows, prob_opf_key),
        "segment_a_phase_local_harmonic_median": _median_row_value(rows, "a_phase_local_harmonic_score"),
        "segment_itsc_not_opf_median": _median_row_value(rows, "itsc_not_opf_score"),
        "rows": list(rows),
    }
    return summary


def _segment_opf_to_itsc_ok(segment: Mapping[str, Any], thresholds: Mapping[str, Any]) -> bool:
    return bool(
        float(segment.get("segment_if_to_de_median", -1.0e9)) >= float(thresholds["thr_segment_if_to_de_min"])
        and float(segment.get("segment_opf_f_zero_score_median", 1.0e9)) <= float(thresholds["thr_segment_opf_f_zero_max"])
        and float(segment.get("segment_opf_f_open_pattern_score_median", 1.0e9)) <= float(thresholds["thr_segment_opf_open_max"])
        and float(segment.get("segment_itsc_vote_ratio", 0.0)) >= float(thresholds["thr_segment_itsc_vote_min"])
        and float(segment.get("segment_prob_itsc_median", 0.0)) >= float(thresholds["thr_segment_prob_itsc_min"])
        and float(segment.get("segment_prob_opf_median", 1.0e9)) <= float(thresholds["thr_segment_prob_opf_max"])
        and float(segment.get("segment_a_phase_local_harmonic_median", -1.0e9)) >= float(thresholds["thr_segment_a_phase_min"])
        and float(segment.get("segment_itsc_not_opf_median", -1.0e9)) >= float(thresholds["thr_segment_itsc_not_opf_min"])
    )


def apply_segment_opf_itsc_refinement(
    rows: Sequence[Dict[str, Any]],
    config: Optional[Mapping[str, Any]] = None,
) -> List[Dict[str, Any]]:
    cfg = prepare_physics_config(config)
    rules = cfg.get("rules", {})
    if not bool(rules.get("enable_segment_opf_itsc_refinement", True)):
        return [dict(row) for row in rows]
    thresholds = cfg.get("thresholds", {})
    out_rows = [dict(row) for row in rows]
    segments = _segment_summaries_from_rows(out_rows, pred_key="physics_pred_idx")
    row_by_identity = {id(row): row for row in out_rows}

    for segment in segments:
        segment_ok = _segment_opf_to_itsc_ok(segment, thresholds)
        segment_fields = {
            key: value for key, value in segment.items()
            if key != "rows" and isinstance(value, (int, float, str))
        }
        segment_fields["segment_rule_opf_to_itsc_ok"] = float(int(segment_ok))
        for original_row in segment["rows"]:
            row = row_by_identity.get(id(original_row))
            if row is None:
                continue
            row.update(segment_fields)
            if segment_ok and int(row.get("physics_pred_idx", -1)) == CLASS_TO_IDX["OPF"]:
                row["physics_pred_idx"] = CLASS_TO_IDX["ITSC"]
                row["physics_pred_name"] = IDX_TO_CLASS[CLASS_TO_IDX["ITSC"]]
                row["changed"] = int(int(row.get("base_pred_idx", -1)) != CLASS_TO_IDX["ITSC"])
                applied = str(row.get("applied_rules", ""))
                rule_name = "RuleS_segment_OPF_to_ITSC"
                if applied:
                    if rule_name not in applied.split("|"):
                        row["applied_rules"] = f"{applied}|{rule_name}"
                else:
                    row["applied_rules"] = rule_name
    return out_rows


def build_known_expert_from_prob(prob: np.ndarray, config: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    cfg = prepare_physics_config(config)
    p = np.asarray(prob, dtype=np.float64).reshape(-1)
    p = p / max(float(np.sum(p)), float(cfg["eps"]))
    known_names = list(cfg["known_expert"].get("known_classes", list(KNOWN_CLASS_NAMES)))
    known_indices = [int(cfg["class_map"][name]) for name in known_names]
    known_raw = p[known_indices]
    known_prob = known_raw / max(float(np.sum(known_raw)), float(cfg["eps"]))
    order = np.argsort(-known_prob)
    top = int(order[0])
    second = int(order[1]) if len(order) > 1 else top
    pred = int(known_indices[top])
    return {
        "known_expert_pred": pred,
        "known_expert_pred_name": IDX_TO_CLASS[pred],
        "known_expert_conf": float(known_prob[top]),
        "known_expert_margin": float(known_prob[top] - known_prob[second]),
        "known_expert_prob": {name: float(v) for name, v in zip(known_names, known_prob)},
        "source": str(cfg["known_expert"].get("source", "prob_known_subset")),
    }


def compute_neural_frequency_support(
    prob_freq: Optional[np.ndarray] = None,
    pred_freq: Optional[int] = None,
    config: Optional[Mapping[str, Any]] = None,
) -> Dict[str, float]:
    cfg = prepare_physics_config(config)
    class_map = cfg["class_map"]
    out = {
        "freq_itsc_prob": float("nan"),
        "freq_opf_prob": float("nan"),
        "freq_tuici_prob": float("nan"),
        "freq_itsc_margin_over_opf": float("nan"),
        "freq_itsc_margin_over_tuici": float("nan"),
        "freq_pred_is_itsc": 0.0,
    }
    if prob_freq is not None:
        pf = np.asarray(prob_freq, dtype=np.float64).reshape(-1)
        if pf.size >= 5 and np.isfinite(pf).all():
            total = float(np.sum(pf))
            if total > float(cfg["eps"]):
                pf = pf / total
            itsc = int(class_map["ITSC"])
            opf = int(class_map["OPF"])
            tuici = int(class_map["tuici"])
            out["freq_itsc_prob"] = float(pf[itsc])
            out["freq_opf_prob"] = float(pf[opf])
            out["freq_tuici_prob"] = float(pf[tuici])
            out["freq_itsc_margin_over_opf"] = float(pf[itsc] - pf[opf])
            out["freq_itsc_margin_over_tuici"] = float(pf[itsc] - pf[tuici])
    if pred_freq is not None:
        out["freq_pred_is_itsc"] = float(int(int(pred_freq) == int(class_map["ITSC"])))
    return out


def _softmax(logits: np.ndarray) -> np.ndarray:
    x = np.asarray(logits, dtype=np.float64).reshape(-1)
    x = x - np.max(x)
    e = np.exp(x)
    return e / max(float(np.sum(e)), 1.0e-12)


def _percentile_value(values: Sequence[float], percentile: float, default: float) -> float:
    arr = np.asarray([float(v) for v in values if np.isfinite(float(v))], dtype=np.float64)
    if arr.size == 0:
        return float(default)
    return float(np.percentile(arr, percentile))


def _scores_from_window(x_raw: np.ndarray, speed: float, load: float, config: Optional[Mapping[str, Any]]) -> Dict[str, float]:
    features = compute_window_physics_features(x_raw=x_raw, speed=speed, load=load, config=config)
    tuici_scores = compute_tuici_like_score(features, config=config)
    merged = dict(features)
    merged.update(tuici_scores)
    itsc_scores = compute_itsc_like_score(merged, config=config)
    merged.update(itsc_scores)
    structural_scores = compute_a_phase_structural_score(merged, config=config)
    merged.update(structural_scores)
    condition_scores = compute_condition_background_scores(merged, config=config)
    merged.update(condition_scores)
    cfg = prepare_physics_config(config)
    alpha = float(cfg["boundary"].get("alpha", 0.5))
    gamma = float(cfg["boundary"].get("gamma", 1.0))
    uniform_demag_score = float(merged["tuici_like_score"] * _sigmoid(-gamma * merged["local_nonuniformity_score"]))
    itsc_over_tuici_margin = float(merged["itsc_like_score"] - alpha * uniform_demag_score)
    merged["uniform_demag_score"] = uniform_demag_score
    merged["itsc_over_tuici_margin"] = itsc_over_tuici_margin
    return merged


def physics_informed_postprocess(
    pred: int,
    prob: np.ndarray,
    logits: np.ndarray,
    x_raw: np.ndarray,
    speed: float,
    load: float,
    domain: str,
    config: dict,
    prob_time: Optional[np.ndarray] = None,
    prob_freq: Optional[np.ndarray] = None,
    logits_time: Optional[np.ndarray] = None,
    logits_freq: Optional[np.ndarray] = None,
    pred_time: Optional[int] = None,
    pred_freq: Optional[int] = None,
    time_freq_prediction_agreement: Optional[float] = None,
    fusion_alpha: Optional[np.ndarray] = None,
    reliability_score: Optional[float] = None,
    logit_margin: Optional[float] = None,
    predictive_entropy: Optional[float] = None,
) -> dict:
    cfg = prepare_physics_config(config)
    prob_arr = np.asarray(prob, dtype=np.float64).reshape(-1)
    if prob_arr.size == 0 or np.sum(prob_arr) <= 0:
        prob_arr = _softmax(np.asarray(logits, dtype=np.float64))
    else:
        prob_arr = prob_arr / np.sum(prob_arr)

    scores = _scores_from_window(x_raw=x_raw, speed=speed, load=load, config=cfg)
    scores.update(compute_neural_frequency_support(prob_freq=prob_freq, pred_freq=pred_freq, config=cfg))
    if time_freq_prediction_agreement is not None:
        scores["time_freq_prediction_agreement"] = float(time_freq_prediction_agreement)
    if reliability_score is not None:
        scores["reliability_score"] = float(reliability_score)
    if logit_margin is not None:
        scores["logit_margin"] = float(logit_margin)
    if predictive_entropy is not None:
        scores["predictive_entropy"] = float(predictive_entropy)
    if pred_time is not None:
        scores["pred_time"] = float(pred_time)
    if pred_freq is not None:
        scores["pred_freq"] = float(pred_freq)
    if fusion_alpha is not None:
        alpha_arr = np.asarray(fusion_alpha, dtype=np.float64).reshape(-1)
        class_map = cfg["class_map"]
        for name, idx in class_map.items():
            if int(idx) < alpha_arr.size:
                scores[f"fusion_alpha_{name}"] = float(alpha_arr[int(idx)])
    known_expert = build_known_expert_from_prob(prob_arr, cfg)
    base_pred = int(pred)
    final_pred = base_pred
    applied_rules: List[str] = []

    thresholds = cfg.get("thresholds", {})
    class_map = cfg["class_map"]
    rules = cfg.get("rules", {})
    unknown_set = {int(class_map["ITSC"]), int(class_map["tuici"])}
    health_idx = int(class_map["health"])
    opf_idx = int(class_map["OPF"])
    itsc_idx = int(class_map["ITSC"])
    tuici_idx = int(class_map["tuici"])
    base_prob_opf = float(prob_arr[opf_idx]) if opf_idx < prob_arr.size else float("nan")
    base_prob_itsc = float(prob_arr[itsc_idx]) if itsc_idx < prob_arr.size else float("nan")
    time_prob_opf = float("nan")
    if prob_time is not None:
        pt = np.asarray(prob_time, dtype=np.float64).reshape(-1)
        if pt.size > opf_idx and np.isfinite(pt).all():
            total = float(np.sum(pt))
            if total > float(cfg["eps"]):
                pt = pt / total
            time_prob_opf = float(pt[opf_idx])
    freq_prob_opf = float(scores.get("freq_opf_prob", float("nan")))
    freq_prob_itsc = float(scores.get("freq_itsc_prob", float("nan")))
    freq_itsc_margin_over_opf = float(scores.get("freq_itsc_margin_over_opf", float("nan")))
    base_itsc_margin_over_opf = float(base_prob_itsc - base_prob_opf)
    freq_support_i1 = (
        float(freq_prob_itsc) >= float(thresholds["i1_freq_itsc_prob_min"])
        or int(scores.get("freq_pred_is_itsc", 0.0)) == 1
        or float(freq_itsc_margin_over_opf) >= float(thresholds["i1_freq_margin_opf_min"])
    )
    rule_i1_itsc_phys_evidence_ok = (
        float(scores["itsc_like_score"]) >= float(thresholds["i1_itsc_like_min"])
        and float(scores["itsc_over_tuici_margin"]) >= float(thresholds["i1_itsc_over_tuici_min"])
        and float(thresholds["i1_local_min"]) <= float(scores["local_nonuniformity_score"]) <= float(thresholds["i1_local_max"])
        and float(scores["opf_f_zero_score"]) <= float(thresholds["i1_opf_f_zero_max"])
        and float(known_expert["known_expert_conf"]) <= float(thresholds["i1_known_conf_max"])
    )
    opf_f_strong = (
        float(scores["opf_f_zero_score"]) >= float(thresholds["thr_opf_f_zero_high"])
        and float(scores["if_to_de_median"]) <= float(thresholds["thr_if_to_de_low"])
    )
    opf_f_open_pattern_strong = (
        bool(opf_f_strong)
        or float(scores.get("opf_f_open_pattern_score", -1.0e9)) >= float(thresholds["thr_opf_f_open_pattern_strong"])
    )
    known_opf_strong = (
        int(known_expert["known_expert_pred"]) == opf_idx
        and float(known_expert["known_expert_conf"]) >= float(thresholds["thr_known_opf_conf_high"])
        and float(known_expert["known_expert_margin"]) >= float(thresholds["thr_known_opf_margin_high"])
    )
    freq_opf_strong = (
        float(freq_prob_opf) >= float(thresholds["thr_freq_opf_conf_high"])
        and float(freq_itsc_margin_over_opf) <= float(thresholds["thr_freq_itsc_over_opf_max_for_opf"])
    )
    base_opf_strong = (
        float(base_prob_opf) >= float(thresholds["thr_base_opf_conf_high"])
        and float(base_itsc_margin_over_opf) <= float(thresholds["thr_base_itsc_over_opf_max_for_opf"])
    )
    opf_like_strong = bool(known_opf_strong or freq_opf_strong or base_opf_strong)
    ultra_strong_itsc = (
        float(scores["itsc_like_score"]) >= float(thresholds["thr_itsc_ultra"])
        and float(scores["itsc_over_tuici_margin"]) >= float(thresholds["thr_margin_ultra"])
        and float(freq_prob_itsc) >= float(thresholds["thr_freq_itsc_ultra"])
        and float(freq_itsc_margin_over_opf) >= float(thresholds["thr_freq_margin_opf_ultra"])
    )
    rule_i1_blocked_by_opf_f = bool(opf_f_strong)
    rule_i1_blocked_by_opf_like = bool(opf_like_strong and not ultra_strong_itsc)
    rule_i1_phys_ok = bool(rule_i1_itsc_phys_evidence_ok and not rule_i1_blocked_by_opf_f and not rule_i1_blocked_by_opf_like)
    freq_support_i2 = (
        float(scores.get("freq_itsc_prob", float("nan"))) >= float(thresholds["i2_freq_itsc_prob_min"])
        or int(scores.get("freq_pred_is_itsc", 0.0)) == 1
    )
    rule_i2_phys_ok = (
        float(scores["itsc_like_score"]) >= float(thresholds["i2_itsc_like_min"])
        and float(scores["waveform_local_imbalance_score"]) >= float(thresholds["i2_waveform_min"])
        and float(scores["itsc_over_tuici_margin"]) >= float(thresholds["i2_itsc_over_tuici_min"])
        and float(known_expert["known_expert_conf"]) <= float(thresholds["i2_known_conf_max"])
    )
    known_class_set = {health_idx, opf_idx, int(class_map["Sensor"])}
    itsc_veto_for_flux_demag = (
        float(scores["itsc_like_score"]) >= float(thresholds["thr_itsc_veto_like"])
        and float(freq_prob_itsc) >= float(thresholds["thr_itsc_veto_freq"])
        and float(scores["itsc_over_tuici_margin"]) >= float(thresholds["thr_itsc_veto_margin"])
    )
    flux_demag_rescue_ok = (
        base_pred in known_class_set
        and float(scores["tuici_like_score"]) >= float(thresholds["thr_tuici_bg_high"])
        and float(scores["psi_eff_drop_z"]) >= float(thresholds["thr_psi_drop_bg_high"])
        and not itsc_veto_for_flux_demag
    )
    rule_i3a_phys_ok = (
        float(scores.get("a_phase_h3_excess_z_cond", -1.0e9)) >= float(thresholds["thr_cond_h3_health_to_itsc"])
        and float(scores.get("a_phase_local_harmonic_z_cond", -1.0e9)) >= float(thresholds["thr_cond_a_phase_health_to_itsc"])
        and float(scores.get("waveform_z_cond", -1.0e9)) >= float(thresholds["thr_cond_waveform_health_to_itsc"])
        and not opf_f_open_pattern_strong
        and float(known_expert["known_expert_conf"]) <= float(thresholds["thr_health_conf_max_for_itsc_override"])
    )
    rule_i3b_phys_ok = (
        not opf_f_open_pattern_strong
        and float(scores.get("itsc_not_opf_score", -1.0e9)) >= float(thresholds["thr_itsc_not_opf"])
        and float(scores.get("a_phase_local_harmonic_score", -1.0e9)) >= float(thresholds["thr_a_phase_structural"])
        and float(freq_itsc_margin_over_opf) >= float(thresholds["thr_freq_margin_relaxed"])
    )
    structural_mode = str(rules.get("a_phase_structural_mode", "safe")).lower()
    if structural_mode not in {"safe", "balanced", "aggressive"}:
        structural_mode = "safe"
    mode_suffix = structural_mode
    i3b_struct_a_phase_thr = float(thresholds[f"thr_i3b_struct_a_phase_high_{mode_suffix}"])
    i3b_struct_not_opf_thr = float(thresholds[f"thr_i3b_struct_itsc_not_opf_high_{mode_suffix}"])
    i3b_struct_open_max = float(thresholds[f"thr_i3b_struct_opf_open_max_{mode_suffix}"])
    i3b_struct_freq_opf_veto_high = float(thresholds[f"thr_i3b_struct_freq_opf_veto_high_{mode_suffix}"])
    i3b_struct_freq_itsc_veto_low = float(thresholds[f"thr_i3b_struct_freq_itsc_veto_low_{mode_suffix}"])
    i3b_struct_freq_veto = (
        float(freq_prob_opf) >= i3b_struct_freq_opf_veto_high
        and float(freq_prob_itsc) <= i3b_struct_freq_itsc_veto_low
    )
    rule_i3b_structural_override_ok = (
        base_pred == opf_idx
        and not opf_f_strong
        and not flux_demag_rescue_ok
        and float(scores.get("a_phase_local_harmonic_score", -1.0e9)) >= i3b_struct_a_phase_thr
        and float(scores.get("itsc_not_opf_score", -1.0e9)) >= i3b_struct_not_opf_thr
        and float(scores.get("opf_f_open_pattern_score", 1.0e9)) <= i3b_struct_open_max
        and not i3b_struct_freq_veto
    )
    scores["apply_correction_flag"] = float(int(bool(cfg.get("apply_correction", False))))
    scores["rules_enable_opf_to_itsc"] = float(int(bool(rules.get("enable_opf_to_itsc", True))))
    scores["rules_enable_health_to_itsc"] = float(int(bool(rules.get("enable_health_to_itsc", True))))
    scores["base_prob_opf"] = float(base_prob_opf)
    scores["base_prob_itsc"] = float(base_prob_itsc)
    scores["time_prob_opf"] = float(time_prob_opf)
    scores["freq_prob_opf"] = float(freq_prob_opf)
    scores["freq_prob_itsc"] = float(freq_prob_itsc)
    scores["base_itsc_margin_over_opf"] = float(base_itsc_margin_over_opf)
    scores["known_expert_pred_idx"] = float(int(known_expert["known_expert_pred"]))
    scores["known_expert_conf_score"] = float(known_expert["known_expert_conf"])
    scores["known_expert_margin_score"] = float(known_expert["known_expert_margin"])
    scores["known_opf_strong"] = float(int(known_opf_strong))
    scores["freq_opf_strong"] = float(int(freq_opf_strong))
    scores["base_opf_strong"] = float(int(base_opf_strong))
    scores["opf_like_strong"] = float(int(opf_like_strong))
    scores["ultra_strong_itsc"] = float(int(ultra_strong_itsc))
    scores["rule_i1_candidate"] = float(int(base_pred == opf_idx))
    scores["opf_f_strong"] = float(int(opf_f_strong))
    scores["opf_f_open_pattern_strong"] = float(int(opf_f_open_pattern_strong))
    scores["opf_f_safety_triggered"] = float(int(base_pred == opf_idx and opf_f_strong))
    scores["opf_like_safety_triggered"] = float(int(base_pred == opf_idx and opf_like_strong and not ultra_strong_itsc))
    scores["rule_i1_safety_blocked"] = float(int(
        base_pred == opf_idx
        and bool(rule_i1_itsc_phys_evidence_ok)
        and bool(freq_support_i1)
        and bool(rule_i1_blocked_by_opf_f or rule_i1_blocked_by_opf_like)
    ))
    scores["rule_i1_opf_f_safety_blocked"] = float(int(
        base_pred == opf_idx
        and bool(rule_i1_itsc_phys_evidence_ok)
        and bool(freq_support_i1)
        and bool(rule_i1_blocked_by_opf_f)
    ))
    scores["rule_i1_opf_like_safety_blocked"] = float(int(
        base_pred == opf_idx
        and bool(rule_i1_itsc_phys_evidence_ok)
        and bool(freq_support_i1)
        and bool(rule_i1_blocked_by_opf_like)
    ))
    blocked_reason = ""
    if base_pred == opf_idx and bool(rule_i1_itsc_phys_evidence_ok) and bool(freq_support_i1):
        if rule_i1_blocked_by_opf_f:
            blocked_reason = "opf_f_zero_safety"
        elif rule_i1_blocked_by_opf_like:
            blocked_reason = "opf_like_safety"
    scores["blocked_reason"] = blocked_reason
    scores["rule_i1_itsc_phys_evidence_ok"] = float(int(rule_i1_itsc_phys_evidence_ok))
    scores["rule_i1_phys_ok"] = float(int(rule_i1_phys_ok))
    scores["rule_i1_freq_ok"] = float(int(freq_support_i1))
    scores["rule_i1_all_ok"] = float(int(
        bool(rules.get("enable_opf_to_itsc", True))
        and base_pred == opf_idx
        and rule_i1_phys_ok
        and freq_support_i1
    ))
    scores["rule_i2_candidate"] = float(int(base_pred == health_idx))
    scores["rule_i2_phys_ok"] = float(int(rule_i2_phys_ok))
    scores["rule_i2_freq_ok"] = float(int(freq_support_i2))
    scores["rule_i2_all_ok"] = float(int(
        bool(rules.get("enable_health_to_itsc", True))
        and base_pred == int(class_map["health"])
        and rule_i2_phys_ok
        and freq_support_i2
    ))
    scores["rule_flux_demag_rescue_candidate"] = float(int(base_pred in known_class_set))
    scores["itsc_veto_for_flux_demag"] = float(int(itsc_veto_for_flux_demag))
    scores["rule_flux_demag_rescue_ok"] = float(int(flux_demag_rescue_ok))
    scores["rule_i3a_candidate"] = float(int(base_pred == health_idx))
    scores["rule_i3a_phys_ok"] = float(int(rule_i3a_phys_ok))
    scores["rule_i3a_all_ok"] = float(int(
        bool(rules.get("enable_a_phase_structural_itsc_rescue", True))
        and bool(rules.get("enable_i3a_health_to_itsc", False))
        and base_pred == health_idx
        and rule_i3a_phys_ok
    ))
    scores["rule_i3b_candidate"] = float(int(base_pred == opf_idx))
    scores["rule_i3b_phys_ok"] = float(int(rule_i3b_phys_ok))
    scores["rule_i3b_overrides_opf_like_safety"] = float(int(
        base_pred == opf_idx
        and rule_i1_blocked_by_opf_like
        and rule_i3b_phys_ok
    ))
    scores["rule_i3b_all_ok"] = float(int(
        bool(rules.get("enable_a_phase_structural_itsc_rescue", True))
        and bool(rules.get("enable_i3b_freq_margin_rule", False))
        and base_pred == opf_idx
        and rule_i3b_phys_ok
    ))
    scores["rule_i3b_structural_mode_id"] = float({"safe": 0, "balanced": 1, "aggressive": 2}[structural_mode])
    scores["rule_i3b_struct_a_phase_thr"] = float(i3b_struct_a_phase_thr)
    scores["rule_i3b_struct_itsc_not_opf_thr"] = float(i3b_struct_not_opf_thr)
    scores["rule_i3b_struct_opf_open_max"] = float(i3b_struct_open_max)
    scores["rule_i3b_struct_freq_opf_veto_high"] = float(i3b_struct_freq_opf_veto_high)
    scores["rule_i3b_struct_freq_itsc_veto_low"] = float(i3b_struct_freq_itsc_veto_low)
    scores["rule_i3b_struct_pass_a_phase_high"] = float(int(
        float(scores.get("a_phase_local_harmonic_score", -1.0e9)) >= i3b_struct_a_phase_thr
    ))
    scores["rule_i3b_struct_pass_itsc_not_opf_high"] = float(int(
        float(scores.get("itsc_not_opf_score", -1.0e9)) >= i3b_struct_not_opf_thr
    ))
    scores["rule_i3b_struct_pass_opf_open_max"] = float(int(
        float(scores.get("opf_f_open_pattern_score", 1.0e9)) <= i3b_struct_open_max and not opf_f_strong
    ))
    scores["rule_i3b_struct_freq_veto"] = float(int(i3b_struct_freq_veto))
    scores["rule_i3b_structural_override_ok"] = float(int(rule_i3b_structural_override_ok))

    if bool(cfg.get("apply_correction", False)):
        if (
            bool(rules.get("enable_tuici_to_itsc", False))
            and base_pred == int(class_map["tuici"])
            and scores["itsc_over_tuici_margin"] >= float(thresholds["threshold_itsc_over_tuici"])
        ):
            final_pred = int(class_map["ITSC"])
            applied_rules.append("RuleA_tuici_to_ITSC")

        if (
            final_pred == opf_idx
            and bool(rule_i1_itsc_phys_evidence_ok)
            and freq_support_i1
            and rule_i1_blocked_by_opf_f
        ):
            applied_rules.append("RuleI1_blocked_by_OPF_F_safety")

        if (
            final_pred == opf_idx
            and bool(rule_i1_itsc_phys_evidence_ok)
            and freq_support_i1
            and not rule_i1_blocked_by_opf_f
            and rule_i1_blocked_by_opf_like
        ):
            applied_rules.append("RuleI1_blocked_by_OPF_like_safety")

        if (
            bool(rules.get("enable_opf_to_itsc", True))
            and final_pred == opf_idx
            and rule_i1_phys_ok
            and freq_support_i1
        ):
            final_pred = itsc_idx
            applied_rules.append("RuleI1_OPF_to_ITSC")

        if (
            bool(rules.get("enable_a_phase_structural_itsc_rescue", True))
            and bool(rules.get("enable_i3b_freq_margin_rule", False))
            and final_pred == opf_idx
            and rule_i3b_phys_ok
        ):
            final_pred = itsc_idx
            applied_rules.append("RuleI3b_Aphase_structural_OPF_to_ITSC")

        if (
            bool(rules.get("enable_a_phase_structural_itsc_rescue", True))
            and bool(rules.get("enable_i3b_structural_override", False))
            and base_pred == opf_idx
            and final_pred == opf_idx
            and rule_i3b_structural_override_ok
        ):
            final_pred = itsc_idx
            applied_rules.append(f"RuleI3b_structural_override_{structural_mode}")

        if (
            bool(rules.get("enable_health_to_itsc", True))
            and final_pred == health_idx
            and rule_i2_phys_ok
            and freq_support_i2
        ):
            final_pred = itsc_idx
            applied_rules.append("RuleI2_health_to_ITSC")

        if (
            bool(rules.get("enable_a_phase_structural_itsc_rescue", True))
            and bool(rules.get("enable_i3a_health_to_itsc", False))
            and final_pred == health_idx
            and rule_i3a_phys_ok
        ):
            final_pred = itsc_idx
            applied_rules.append("RuleI3a_Aphase_structural_health_to_ITSC")

        if (
            bool(rules.get("enable_flux_demag_rescue", True))
            and final_pred in known_class_set
            and flux_demag_rescue_ok
        ):
            final_pred = tuici_idx
            applied_rules.append("RuleT_flux_demag_rescue")

        unknown_evidence = max(float(scores["itsc_like_score"]), float(scores["tuici_like_score"]))
        if bool(rules.get("enable_unknown_to_known_rescue", False)) and final_pred in unknown_set:
            if (
                float(known_expert["known_expert_conf"]) >= float(thresholds["known_expert_conf"])
                and float(known_expert["known_expert_margin"]) >= float(thresholds["known_expert_margin"])
                and unknown_evidence <= float(thresholds["unknown_score_max"])
            ):
                final_pred = int(known_expert["known_expert_pred"])
                applied_rules.append("RuleB_unknown_to_known_rescue")

        if bool(rules.get("enable_health_rescue", False)) and final_pred == int(class_map["ITSC"]):
            if (
                int(known_expert["known_expert_pred"]) == int(class_map["health"])
                and float(known_expert["known_expert_conf"]) >= float(thresholds["known_expert_conf"])
                and float(known_expert["known_expert_margin"]) >= float(thresholds["known_expert_margin"])
                and float(scores["health_like_score"]) >= float(thresholds["health_like_min"])
                and float(scores["itsc_like_score"]) <= float(thresholds["unknown_score_max"])
                and float(scores["itsc_over_tuici_margin"]) <= float(thresholds["health_rescue_margin_max"])
            ):
                final_pred = int(class_map["health"])
                applied_rules.append("RuleC_ITSC_to_health_rescue")

    return {
        "base_pred": base_pred,
        "final_pred": int(final_pred),
        "scores": scores,
        "known_expert": known_expert,
        "applied_rules": applied_rules,
    }


def validate_no_real_unknown_for_selection(records: Iterable[Mapping[str, Any]]) -> Dict[str, Any]:
    checked = 0
    for i, row in enumerate(records):
        checked += 1
        domain = str(row.get("domain_name", row.get("domain", "")))
        label = str(row.get("label_name", row.get("label", "")))
        if domain == "real" and label in set(UNKNOWN_CLASS_NAMES):
            raise ValueError(f"real unknown sample entered physics selection set at index={i}: {domain}_{label}")
    return {"checked": checked, "forbidden_found": 0, "passed": True}


def _estimate_opf_like_thresholds(
    scored_rows: Sequence[Mapping[str, Any]],
    base_thresholds: Mapping[str, float],
    class_map: Mapping[str, int],
) -> Tuple[Dict[str, float], Dict[str, Any]]:
    opf_idx = int(class_map["OPF"])
    real_val_opf = [r for r in scored_rows if r.get("source") == "real_known_val" and r.get("label_name") == "OPF"]
    sim_val_itsc = [r for r in scored_rows if r.get("source") == "sim_val" and r.get("label_name") == "ITSC"]

    def values(rows: Sequence[Mapping[str, Any]], key: str) -> List[float]:
        out: List[float] = []
        for row in rows:
            value = float(row["scores"].get(key, np.nan))
            if np.isfinite(value):
                out.append(value)
        return out

    def pct(rows: Sequence[Mapping[str, Any]], key: str, percentile: float, default: float) -> float:
        return _percentile_value(values(rows, key), percentile, default)

    defaults = {
        "thr_known_opf_conf_high": pct(real_val_opf, "known_expert_conf", 5, 1.0),
        "thr_known_opf_margin_high": pct(real_val_opf, "known_expert_margin", 5, 1.0),
        "thr_freq_opf_conf_high": pct(real_val_opf, "freq_opf_prob", 75, 1.0),
        "thr_base_opf_conf_high": pct(real_val_opf, "base_prob_opf", 5, 1.0),
        "thr_freq_itsc_over_opf_max_for_opf": pct(real_val_opf, "freq_itsc_margin_over_opf", 95, -1.0e9),
        "thr_base_itsc_over_opf_max_for_opf": pct(real_val_opf, "base_itsc_margin_over_opf", 95, -1.0e9),
        "thr_itsc_ultra": pct(sim_val_itsc, "itsc_like_score", 90, 1.0e9),
        "thr_margin_ultra": pct(sim_val_itsc, "itsc_over_tuici_margin", 90, 1.0e9),
        "thr_freq_itsc_ultra": pct(sim_val_itsc, "freq_itsc_prob", 90, 1.0),
        "thr_freq_margin_opf_ultra": pct(sim_val_itsc, "freq_itsc_margin_over_opf", 90, 1.0),
    }

    def candidates(rows: Sequence[Mapping[str, Any]], key: str, percentiles: Sequence[float], default: float) -> List[float]:
        vals = sorted(set(pct(rows, key, p, default) for p in percentiles))
        return [v for v in vals if np.isfinite(v)]

    conf_candidates = candidates(real_val_opf, "known_expert_conf", [1, 5, 10, 20], defaults["thr_known_opf_conf_high"])
    margin_candidates = candidates(real_val_opf, "known_expert_margin", [1, 5, 10, 20], defaults["thr_known_opf_margin_high"])
    freq_opf_candidates = candidates(real_val_opf, "freq_opf_prob", [50, 75, 90], defaults["thr_freq_opf_conf_high"])
    base_opf_candidates = candidates(real_val_opf, "base_prob_opf", [1, 5, 10], defaults["thr_base_opf_conf_high"])
    freq_margin_candidates = candidates(real_val_opf, "freq_itsc_margin_over_opf", [90, 95, 99], defaults["thr_freq_itsc_over_opf_max_for_opf"])
    base_margin_candidates = candidates(real_val_opf, "base_itsc_margin_over_opf", [90, 95, 99], defaults["thr_base_itsc_over_opf_max_for_opf"])
    ultra_itsc_candidates = candidates(sim_val_itsc, "itsc_like_score", [75, 90, 95], defaults["thr_itsc_ultra"])
    ultra_margin_candidates = candidates(sim_val_itsc, "itsc_over_tuici_margin", [75, 90, 95], defaults["thr_margin_ultra"])
    ultra_freq_candidates = candidates(sim_val_itsc, "freq_itsc_prob", [75, 90, 95], defaults["thr_freq_itsc_ultra"])
    ultra_freq_margin_candidates = candidates(sim_val_itsc, "freq_itsc_margin_over_opf", [75, 90, 95], defaults["thr_freq_margin_opf_ultra"])

    def i1_candidate(row: Mapping[str, Any]) -> bool:
        s = row["scores"]
        return bool(
            float(s["itsc_like_score"]) >= float(base_thresholds["i1_itsc_like_min"])
            and float(s["itsc_over_tuici_margin"]) >= float(base_thresholds["i1_itsc_over_tuici_min"])
            and float(base_thresholds["i1_local_min"]) <= float(s["local_nonuniformity_score"]) <= float(base_thresholds["i1_local_max"])
            and float(s["opf_f_zero_score"]) <= float(base_thresholds["i1_opf_f_zero_max"])
            and float(s.get("known_expert_conf", np.nan)) <= float(base_thresholds["i1_known_conf_max"])
            and (
                float(s.get("freq_itsc_prob", np.nan)) >= float(base_thresholds["i1_freq_itsc_prob_min"])
                or int(s.get("freq_pred_is_itsc", 0.0)) == 1
                or float(s.get("freq_itsc_margin_over_opf", np.nan)) >= float(base_thresholds["i1_freq_margin_opf_min"])
            )
        )

    def blocked(row: Mapping[str, Any], th: Mapping[str, float]) -> bool:
        s = row["scores"]
        opf_f_strong = (
            float(s["opf_f_zero_score"]) >= float(base_thresholds["thr_opf_f_zero_high"])
            and float(s["if_to_de_median"]) <= float(base_thresholds["thr_if_to_de_low"])
        )
        known_opf_strong = (
            int(s.get("known_expert_pred", -1)) == opf_idx
            and float(s.get("known_expert_conf", np.nan)) >= float(th["thr_known_opf_conf_high"])
            and float(s.get("known_expert_margin", np.nan)) >= float(th["thr_known_opf_margin_high"])
        )
        freq_opf_strong = (
            float(s.get("freq_opf_prob", np.nan)) >= float(th["thr_freq_opf_conf_high"])
            and float(s.get("freq_itsc_margin_over_opf", np.nan)) <= float(th["thr_freq_itsc_over_opf_max_for_opf"])
        )
        base_opf_strong = (
            float(s.get("base_prob_opf", np.nan)) >= float(th["thr_base_opf_conf_high"])
            and float(s.get("base_itsc_margin_over_opf", np.nan)) <= float(th["thr_base_itsc_over_opf_max_for_opf"])
        )
        opf_like_strong = bool(known_opf_strong or freq_opf_strong or base_opf_strong)
        ultra_strong_itsc = (
            float(s["itsc_like_score"]) >= float(th["thr_itsc_ultra"])
            and float(s["itsc_over_tuici_margin"]) >= float(th["thr_margin_ultra"])
            and float(s.get("freq_itsc_prob", np.nan)) >= float(th["thr_freq_itsc_ultra"])
            and float(s.get("freq_itsc_margin_over_opf", np.nan)) >= float(th["thr_freq_margin_opf_ultra"])
        )
        return bool(opf_f_strong or (opf_like_strong and not ultra_strong_itsc))

    opf_candidates = [r for r in real_val_opf if i1_candidate(r)]
    itsc_candidates = [r for r in sim_val_itsc if i1_candidate(r)]
    best_thresholds = dict(defaults)
    best_score: Tuple[float, float, float, float] = (-1.0e18, -1.0, -1.0, -1.0e18)
    searched = 0
    for kc in conf_candidates:
        for km in margin_candidates:
            for foc in freq_opf_candidates:
                for boc in base_opf_candidates:
                    for fmm in freq_margin_candidates:
                        for bmm in base_margin_candidates:
                            for ui in ultra_itsc_candidates:
                                for um in ultra_margin_candidates:
                                    for uf in ultra_freq_candidates:
                                        for ufm in ultra_freq_margin_candidates:
                                            th = {
                                                "thr_known_opf_conf_high": float(kc),
                                                "thr_known_opf_margin_high": float(km),
                                                "thr_freq_opf_conf_high": float(foc),
                                                "thr_base_opf_conf_high": float(boc),
                                                "thr_freq_itsc_over_opf_max_for_opf": float(fmm),
                                                "thr_base_itsc_over_opf_max_for_opf": float(bmm),
                                                "thr_itsc_ultra": float(ui),
                                                "thr_margin_ultra": float(um),
                                                "thr_freq_itsc_ultra": float(uf),
                                                "thr_freq_margin_opf_ultra": float(ufm),
                                            }
                                            searched += 1
                                            opf_blocked = sum(1 for r in opf_candidates if blocked(r, th))
                                            itsc_blocked = sum(1 for r in itsc_candidates if blocked(r, th))
                                            opf_false_left = len(opf_candidates) - opf_blocked
                                            opf_recall_proxy = 1.0 - opf_false_left / max(len(real_val_opf), 1)
                                            itsc_keep_rate = (len(itsc_candidates) - itsc_blocked) / max(len(itsc_candidates), 1)
                                            score = (-1000.0 * opf_false_left, opf_recall_proxy, itsc_keep_rate, -0.001 * itsc_blocked)
                                            if score > best_score:
                                                best_score = score
                                                best_thresholds = th

    audit = {
        "proxy_search_candidates": int(searched),
        "real_known_val_opf_count": int(len(real_val_opf)),
        "real_known_val_opf_rule_i1_candidates_before_safety": int(len(opf_candidates)),
        "sim_val_itsc_count": int(len(sim_val_itsc)),
        "sim_val_itsc_rule_i1_candidates_before_safety": int(len(itsc_candidates)),
        "real_known_val_opf_candidates_blocked_by_selected_safety": int(sum(1 for r in opf_candidates if blocked(r, best_thresholds))),
        "sim_val_itsc_candidates_blocked_by_selected_safety": int(sum(1 for r in itsc_candidates if blocked(r, best_thresholds))),
        "selection_objective": "minimize_real_known_val_OPF_RuleI1_false_left_then_keep_sim_val_ITSC_proxy",
    }
    return best_thresholds, audit


def _estimate_flux_demag_rescue_thresholds(
    scored_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Dict[str, float], Dict[str, Any]]:
    real_known_val = [
        r for r in scored_rows
        if r.get("source") == "real_known_val" and r.get("label_name") in KNOWN_CLASS_NAMES
    ]
    sim_known_val = [
        r for r in scored_rows
        if r.get("source") == "sim_val" and r.get("label_name") in KNOWN_CLASS_NAMES
    ]
    sim_val_tuici = [
        r for r in scored_rows
        if r.get("source") == "sim_val" and r.get("label_name") == "tuici"
    ]

    def values(rows: Sequence[Mapping[str, Any]], key: str) -> List[float]:
        out: List[float] = []
        for row in rows:
            value = float(row["scores"].get(key, np.nan))
            if np.isfinite(value):
                out.append(value)
        return out

    def pct(rows: Sequence[Mapping[str, Any]], key: str, percentile: float, default: float) -> float:
        return _percentile_value(values(rows, key), percentile, default)

    tuici_bg_real_q99 = pct(real_known_val, "tuici_like_score", 99.0, 1.0e9)
    tuici_bg_real_q995 = pct(real_known_val, "tuici_like_score", 99.5, tuici_bg_real_q99)
    tuici_bg_sim_q99 = pct(sim_known_val, "tuici_like_score", 99.0, 1.0e9)
    tuici_bg_sim_q995 = pct(sim_known_val, "tuici_like_score", 99.5, tuici_bg_sim_q99)
    psi_drop_real_q99 = pct(real_known_val, "psi_eff_drop_z", 99.0, 1.0e9)
    psi_drop_real_q995 = pct(real_known_val, "psi_eff_drop_z", 99.5, psi_drop_real_q99)
    psi_drop_sim_q99 = pct(sim_known_val, "psi_eff_drop_z", 99.0, 1.0e9)
    psi_drop_sim_q995 = pct(sim_known_val, "psi_eff_drop_z", 99.5, psi_drop_sim_q99)

    # RuleT is a deployment-time rescue for real-domain demagnetization misses.
    # Use real-known validation background as the trigger boundary; sim-known
    # background is kept for audit instead of binding the real trigger.
    tuici_bg_high = tuici_bg_real_q995
    psi_drop_bg_high = psi_drop_real_q995
    tuici_bg_high_995 = max(
        tuici_bg_real_q995,
        tuici_bg_sim_q995,
    )
    psi_drop_bg_high_995 = max(
        psi_drop_real_q995,
        psi_drop_sim_q995,
    )
    # Use the more permissive q99 background by default; q99.5 is recorded in audit.
    itsc_veto_like = pct([r for r in scored_rows if r.get("source") == "sim_val" and r.get("label_name") == "ITSC"], "itsc_like_score", 75, 1.0e9)
    itsc_veto_freq = pct([r for r in scored_rows if r.get("source") == "sim_val" and r.get("label_name") == "ITSC"], "freq_itsc_prob", 75, 1.0)
    itsc_veto_margin = pct([r for r in scored_rows if r.get("source") == "sim_val" and r.get("label_name") == "ITSC"], "itsc_over_tuici_margin", 75, 1.0e9)

    def fires(row: Mapping[str, Any], th: Mapping[str, float]) -> bool:
        s = row["scores"]
        itsc_veto = (
            float(s["itsc_like_score"]) >= float(th["thr_itsc_veto_like"])
            and float(s.get("freq_itsc_prob", np.nan)) >= float(th["thr_itsc_veto_freq"])
            and float(s["itsc_over_tuici_margin"]) >= float(th["thr_itsc_veto_margin"])
        )
        return bool(
            float(s["tuici_like_score"]) >= float(th["thr_tuici_bg_high"])
            and float(s["psi_eff_drop_z"]) >= float(th["thr_psi_drop_bg_high"])
            and not itsc_veto
        )

    best_thresholds = {
        "thr_tuici_bg_high": float(tuici_bg_high),
        "thr_psi_drop_bg_high": float(psi_drop_bg_high),
        "thr_itsc_veto_like": float(itsc_veto_like),
        "thr_itsc_veto_freq": float(itsc_veto_freq),
        "thr_itsc_veto_margin": float(itsc_veto_margin),
    }

    audit = {
        "threshold_strategy": "real_known_val_q99_5_background_with_sim_known_audit",
        "real_known_val_count": int(len(real_known_val)),
        "sim_known_val_count": int(len(sim_known_val)),
        "known_background_count": int(len(real_known_val) + len(sim_known_val)),
        "sim_val_tuici_count": int(len(sim_val_tuici)),
        "real_known_val_fired_by_selected_rule": int(sum(1 for r in real_known_val if fires(r, best_thresholds))),
        "sim_known_val_fired_by_selected_rule": int(sum(1 for r in sim_known_val if fires(r, best_thresholds))),
        "sim_val_tuici_fired_by_selected_rule": int(sum(1 for r in sim_val_tuici if fires(r, best_thresholds))),
        "tuici_like_score_real_known_val_q99": float(tuici_bg_real_q99),
        "tuici_like_score_real_known_val_q995": float(tuici_bg_real_q995),
        "tuici_like_score_sim_known_val_q99": float(tuici_bg_sim_q99),
        "tuici_like_score_sim_known_val_q995": float(tuici_bg_sim_q995),
        "tuici_like_score_known_bg_q995_max": float(tuici_bg_high_995),
        "psi_eff_drop_z_real_known_val_q99": float(psi_drop_real_q99),
        "psi_eff_drop_z_real_known_val_q995": float(psi_drop_real_q995),
        "psi_eff_drop_z_sim_known_val_q99": float(psi_drop_sim_q99),
        "psi_eff_drop_z_sim_known_val_q995": float(psi_drop_sim_q995),
        "psi_eff_drop_z_known_bg_q995_max": float(psi_drop_bg_high_995),
        "sim_val_tuici_direction_check_median_tuici_like": float(pct(sim_val_tuici, "tuici_like_score", 50, 0.0)),
        "sim_val_tuici_direction_check_median_psi_drop": float(pct(sim_val_tuici, "psi_eff_drop_z", 50, 0.0)),
    }
    return best_thresholds, audit


def _estimate_segment_opf_itsc_thresholds(
    scored_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Dict[str, float], Dict[str, Any]]:
    segments = _segment_summaries_from_rows(scored_rows, pred_key="base_pred_idx")
    real_val_opf = [
        s for s in segments
        if s.get("source") == "real_known_val" and s.get("label_name") == "OPF"
    ]
    sim_val_itsc = [
        s for s in segments
        if s.get("source") == "sim_val" and s.get("label_name") == "ITSC"
    ]

    def vals(items: Sequence[Mapping[str, Any]], key: str) -> List[float]:
        out: List[float] = []
        for item in items:
            try:
                value = float(item.get(key, np.nan))
            except (TypeError, ValueError):
                value = float("nan")
            if np.isfinite(value):
                out.append(value)
        return out

    def pct(items: Sequence[Mapping[str, Any]], key: str, percentile: float, default: float) -> float:
        return _percentile_value(vals(items, key), percentile, default)

    def candidate_values(items_a: Sequence[Mapping[str, Any]], items_b: Sequence[Mapping[str, Any]], key: str, percentiles: Sequence[float]) -> List[float]:
        values: List[float] = []
        for items in (items_a, items_b):
            for percentile in percentiles:
                value = pct(items, key, percentile, float("nan"))
                if np.isfinite(value):
                    values.append(float(value))
        return sorted(set(values))

    if_min_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_if_to_de_median", [50, 75, 90, 95, 5, 10, 25])
    zero_max_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_opf_f_zero_score_median", [5, 10, 25, 50, 75, 90, 95])
    open_max_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_opf_f_open_pattern_score_median", [5, 10, 25, 50, 75, 90, 95])
    vote_min_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_itsc_vote_ratio", [0, 1, 5, 10, 25, 50])
    prob_itsc_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_prob_itsc_median", [90, 95, 99, 100, 1, 5, 10, 25])
    prob_opf_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_prob_opf_median", [0, 1, 5, 10, 25, 50, 90])
    a_phase_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_a_phase_local_harmonic_median", [90, 95, 99, 100, 1, 5, 10, 25])
    not_opf_candidates = candidate_values(real_val_opf, sim_val_itsc, "segment_itsc_not_opf_median", [90, 95, 99, 100, 1, 5, 10, 25])

    # Add deliberately mild support thresholds. Real OPF segments have no ITSC
    # votes and very low ITSC posterior, so these usually keep false repair at 0.
    vote_min_candidates.extend([0.05, 0.10, 0.25, 0.50])
    prob_itsc_candidates.extend([0.04, 0.08, 0.12, 0.20])
    prob_opf_candidates.extend([0.70, 0.80, 0.90, 0.95, 1.0])
    if_min_candidates.extend([0.30, 0.50, 0.70])
    zero_max_candidates.extend([0.30, 0.50, 0.70])
    open_max_candidates.extend([0.80, 1.00, 1.50, 2.00])
    a_phase_candidates.extend([0.30, 0.50, 0.75, 1.00])
    not_opf_candidates.extend([0.00, 0.20, 0.40, 0.60])

    if_min_candidates = sorted(set(v for v in if_min_candidates if np.isfinite(v)))
    zero_max_candidates = sorted(set(v for v in zero_max_candidates if np.isfinite(v)))
    open_max_candidates = sorted(set(v for v in open_max_candidates if np.isfinite(v)))
    vote_min_candidates = sorted(set(v for v in vote_min_candidates if np.isfinite(v)))
    prob_itsc_candidates = sorted(set(v for v in prob_itsc_candidates if np.isfinite(v)))
    prob_opf_candidates = sorted(set(v for v in prob_opf_candidates if np.isfinite(v)))
    a_phase_candidates = sorted(set(v for v in a_phase_candidates if np.isfinite(v)))
    not_opf_candidates = sorted(set(v for v in not_opf_candidates if np.isfinite(v)))

    # Keep the segment search intentionally small. The segment rule is protected
    # mainly by ITSC segment consistency and posterior support, while the OPF-F
    # physics gates only confirm that the segment is not a sustained F-open fault.
    if_min_candidates = sorted(set([
        max(0.0, min(0.50, pct(sim_val_itsc, "segment_if_to_de_median", 10, 0.50))),
        max(0.0, min(0.70, pct(sim_val_itsc, "segment_if_to_de_median", 25, 0.70))),
    ]))
    zero_max_candidates = sorted(set([
        max(0.30, pct(sim_val_itsc, "segment_opf_f_zero_score_median", 75, 0.30)),
        max(0.50, pct(sim_val_itsc, "segment_opf_f_zero_score_median", 90, 0.50)),
    ]))
    open_max_candidates = sorted(set([
        max(0.80, min(pct(real_val_opf, "segment_opf_f_open_pattern_score_median", 5, 1.0), pct(sim_val_itsc, "segment_opf_f_open_pattern_score_median", 90, 1.0))),
        max(1.00, min(pct(real_val_opf, "segment_opf_f_open_pattern_score_median", 10, 1.5), pct(sim_val_itsc, "segment_opf_f_open_pattern_score_median", 95, 1.5))),
    ]))
    vote_min_candidates = sorted(set([
        max(0.05, pct(real_val_opf, "segment_itsc_vote_ratio", 100, 0.0) + 1.0e-6),
        max(0.25, pct(sim_val_itsc, "segment_itsc_vote_ratio", 10, 0.25)),
    ]))
    prob_itsc_candidates = sorted(set([
        max(0.04, pct(real_val_opf, "segment_prob_itsc_median", 100, 0.0) + 1.0e-6),
        max(0.08, pct(sim_val_itsc, "segment_prob_itsc_median", 10, 0.08)),
    ]))
    # Segment refinement is meant for windows whose network/known expert often
    # still favors OPF. Do not use high OPF posterior as a hard veto here; safety
    # is controlled by OPF-F structure, ITSC segment consistency, and A-phase
    # structural evidence.
    prob_opf_candidates = [1.000001]
    a_phase_candidates = sorted(set([
        max(0.30, pct(real_val_opf, "segment_a_phase_local_harmonic_median", 90, 0.30)),
        max(0.50, pct(sim_val_itsc, "segment_a_phase_local_harmonic_median", 10, 0.50)),
    ]))
    not_opf_candidates = sorted(set([
        max(0.00, pct(real_val_opf, "segment_itsc_not_opf_median", 95, 0.00)),
        max(0.20, pct(sim_val_itsc, "segment_itsc_not_opf_median", 10, 0.20)),
    ]))

    def fires(segment: Mapping[str, Any], th: Mapping[str, float]) -> bool:
        return _segment_opf_to_itsc_ok(segment, {
            "thr_segment_if_to_de_min": th["if_min"],
            "thr_segment_opf_f_zero_max": th["zero_max"],
            "thr_segment_opf_open_max": th["open_max"],
            "thr_segment_itsc_vote_min": th["vote_min"],
            "thr_segment_prob_itsc_min": th["prob_itsc_min"],
            "thr_segment_prob_opf_max": th["prob_opf_max"],
            "thr_segment_a_phase_min": th["a_phase_min"],
            "thr_segment_itsc_not_opf_min": th["not_opf_min"],
        })

    best: Optional[Dict[str, float]] = None
    best_score = (-1.0e18, -1.0e18, -1.0e18)
    searched = 0
    # Coarse but bounded search. Probability and vote gates do most false
    # protection; physics gates ensure the segment is not a sustained OPF-F.
    for vote_min in vote_min_candidates:
        for prob_itsc_min in prob_itsc_candidates:
            for prob_opf_max in prob_opf_candidates:
                for if_min in if_min_candidates:
                    for zero_max in zero_max_candidates:
                        for open_max in open_max_candidates:
                            for a_phase_min in a_phase_candidates:
                                for not_opf_min in not_opf_candidates:
                                    th = {
                                        "if_min": float(if_min),
                                        "zero_max": float(zero_max),
                                        "open_max": float(open_max),
                                        "vote_min": float(vote_min),
                                        "prob_itsc_min": float(prob_itsc_min),
                                        "prob_opf_max": float(prob_opf_max),
                                        "a_phase_min": float(a_phase_min),
                                        "not_opf_min": float(not_opf_min),
                                    }
                                    searched += 1
                                    opf_false = sum(1 for s in real_val_opf if fires(s, th))
                                    sim_hits = sum(1 for s in sim_val_itsc if fires(s, th))
                                    if opf_false == 0:
                                        # Prefer high sim ITSC coverage, then more
                                        # permissive OPF-open ceiling to generalize.
                                        score = (float(sim_hits), float(open_max), -float(vote_min + prob_itsc_min + a_phase_min + not_opf_min))
                                    else:
                                        score = (-100000.0 * float(opf_false), float(sim_hits), -float(opf_false))
                                    if score > best_score:
                                        best_score = score
                                        best = th

    if best is None:
        best = {
            "if_min": 1.0e9,
            "zero_max": -1.0e9,
            "open_max": -1.0e9,
            "vote_min": 1.0,
            "prob_itsc_min": 1.0,
            "prob_opf_max": -1.0e9,
            "a_phase_min": 1.0e9,
            "not_opf_min": 1.0e9,
        }

    thresholds = {
        "thr_segment_if_to_de_min": float(best["if_min"]),
        "thr_segment_opf_f_zero_max": float(best["zero_max"]),
        "thr_segment_opf_open_max": float(best["open_max"]),
        "thr_segment_itsc_vote_min": float(best["vote_min"]),
        "thr_segment_prob_itsc_min": float(best["prob_itsc_min"]),
        "thr_segment_prob_opf_max": float(best["prob_opf_max"]),
        "thr_segment_a_phase_min": float(best["a_phase_min"]),
        "thr_segment_itsc_not_opf_min": float(best["not_opf_min"]),
    }
    audit = {
        "threshold_strategy": "segment_safe_zero_real_known_val_OPF_false_prefer_sim_val_ITSC_segments",
        "search_candidates": int(searched),
        "real_known_val_opf_segments": int(len(real_val_opf)),
        "sim_val_itsc_segments": int(len(sim_val_itsc)),
        "real_known_val_opf_fired": int(sum(1 for s in real_val_opf if _segment_opf_to_itsc_ok(s, thresholds))),
        "sim_val_itsc_fired": int(sum(1 for s in sim_val_itsc if _segment_opf_to_itsc_ok(s, thresholds))),
        "selected_thresholds": {k: float(v) for k, v in thresholds.items()},
    }
    return thresholds, audit


def _estimate_a_phase_structural_thresholds(
    scored_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Dict[str, float], Dict[str, Any]]:
    real_val_health = [
        r for r in scored_rows
        if r.get("source") == "real_known_val" and r.get("label_name") == "health"
    ]
    real_val_opf = [
        r for r in scored_rows
        if r.get("source") == "real_known_val" and r.get("label_name") == "OPF"
    ]
    sim_val_itsc = [
        r for r in scored_rows
        if r.get("source") == "sim_val" and r.get("label_name") == "ITSC"
    ]

    def values(rows: Sequence[Mapping[str, Any]], key: str) -> List[float]:
        out: List[float] = []
        for row in rows:
            value = float(row["scores"].get(key, np.nan))
            if np.isfinite(value):
                out.append(value)
        return out

    def pct(rows: Sequence[Mapping[str, Any]], key: str, percentile: float, default: float) -> float:
        return _percentile_value(values(rows, key), percentile, default)

    opf_open_strong = max(
        pct(real_val_opf, "opf_f_open_pattern_score", 20, 1.0e9),
        pct([r for r in scored_rows if r.get("source") in {"real_known_val", "sim_val"} and r.get("label_name") in {"health", "Sensor", "ITSC"}], "opf_f_open_pattern_score", 99, -1.0e9),
    )

    h3_candidates = [
        pct(real_val_health, "a_phase_h3_excess_z_cond", 99.0, 1.0e9),
        pct(real_val_health, "a_phase_h3_excess_z_cond", 99.5, 1.0e9),
        pct(sim_val_itsc, "a_phase_h3_excess_z_cond", 20, 1.0e9),
        pct(sim_val_itsc, "a_phase_h3_excess_z_cond", 35, 1.0e9),
        pct(sim_val_itsc, "a_phase_h3_excess_z_cond", 50, 1.0e9),
    ]
    a_phase_candidates = [
        pct(real_val_health, "a_phase_local_harmonic_z_cond", 99.0, 1.0e9),
        pct(real_val_health, "a_phase_local_harmonic_z_cond", 99.5, 1.0e9),
        pct(sim_val_itsc, "a_phase_local_harmonic_z_cond", 20, 1.0e9),
        pct(sim_val_itsc, "a_phase_local_harmonic_z_cond", 35, 1.0e9),
        pct(sim_val_itsc, "a_phase_local_harmonic_z_cond", 50, 1.0e9),
    ]
    waveform_candidates = [
        pct(real_val_health, "waveform_z_cond", 99.0, 1.0e9),
        pct(real_val_health, "waveform_z_cond", 99.5, 1.0e9),
        pct(sim_val_itsc, "waveform_z_cond", 20, 1.0e9),
        pct(sim_val_itsc, "waveform_z_cond", 35, 1.0e9),
        pct(sim_val_itsc, "waveform_z_cond", 50, 1.0e9),
    ]
    health_conf_candidates = [
        pct([r for r in scored_rows if r.get("source") == "real_known_val" and r.get("label_name") in KNOWN_CLASS_NAMES], "known_expert_conf", 90, -1.0e9),
        pct([r for r in scored_rows if r.get("source") == "real_known_val" and r.get("label_name") in KNOWN_CLASS_NAMES], "known_expert_conf", 95, -1.0e9),
        pct([r for r in scored_rows if r.get("source") == "real_known_val" and r.get("label_name") in KNOWN_CLASS_NAMES], "known_expert_conf", 99, -1.0e9),
    ]

    def i3a_fires(row: Mapping[str, Any], th: Mapping[str, float]) -> bool:
        s = row["scores"]
        return bool(
            float(s.get("a_phase_h3_excess_z_cond", -1.0e9)) >= float(th["thr_cond_h3_health_to_itsc"])
            and float(s.get("a_phase_local_harmonic_z_cond", -1.0e9)) >= float(th["thr_cond_a_phase_health_to_itsc"])
            and float(s.get("waveform_z_cond", -1.0e9)) >= float(th["thr_cond_waveform_health_to_itsc"])
            and float(s.get("opf_f_open_pattern_score", 1.0e9)) < float(th["thr_opf_f_open_pattern_strong"])
            and float(s.get("known_expert_conf", 1.0)) <= float(th["thr_health_conf_max_for_itsc_override"])
        )

    best_i3a = {
        "thr_cond_h3_health_to_itsc": pct(real_val_health, "a_phase_h3_excess_z_cond", 99.5, 1.0e9),
        "thr_cond_a_phase_health_to_itsc": pct(real_val_health, "a_phase_local_harmonic_z_cond", 99.5, 1.0e9),
        "thr_cond_waveform_health_to_itsc": pct(real_val_health, "waveform_z_cond", 99.5, 1.0e9),
        "thr_health_conf_max_for_itsc_override": pct([r for r in scored_rows if r.get("source") == "real_known_val" and r.get("label_name") in KNOWN_CLASS_NAMES], "known_expert_conf", 95, -1.0e9),
    }
    best_i3a_score = (-1.0e9, -1.0e9, -1.0e9)
    searched_i3a = 0
    for h3 in sorted(set(v for v in h3_candidates if np.isfinite(v))):
        for aph in sorted(set(v for v in a_phase_candidates if np.isfinite(v))):
            for wav in sorted(set(v for v in waveform_candidates if np.isfinite(v))):
                for conf in sorted(set(v for v in health_conf_candidates if np.isfinite(v))):
                    th = {
                        "thr_cond_h3_health_to_itsc": float(h3),
                        "thr_cond_a_phase_health_to_itsc": float(aph),
                        "thr_cond_waveform_health_to_itsc": float(wav),
                        "thr_opf_f_open_pattern_strong": float(opf_open_strong),
                        "thr_health_conf_max_for_itsc_override": float(conf),
                    }
                    searched_i3a += 1
                    health_false = sum(1 for r in real_val_health if i3a_fires(r, th))
                    sim_hits = sum(1 for r in sim_val_itsc if i3a_fires(r, th))
                    score = (-1000.0 * health_false, float(sim_hits), -float(h3 + aph + wav))
                    if score > best_i3a_score:
                        best_i3a_score = score
                        best_i3a = {k: float(v) for k, v in th.items() if k != "thr_opf_f_open_pattern_strong"}

    structural_candidates = [
        pct(real_val_opf, "a_phase_local_harmonic_score", 99.0, 1.0e9),
        pct(real_val_opf, "a_phase_local_harmonic_score", 99.5, 1.0e9),
        pct(sim_val_itsc, "a_phase_local_harmonic_score", 15, 1.0e9),
        pct(sim_val_itsc, "a_phase_local_harmonic_score", 25, 1.0e9),
        pct(sim_val_itsc, "a_phase_local_harmonic_score", 40, 1.0e9),
    ]
    not_opf_candidates = [
        pct(real_val_opf, "itsc_not_opf_score", 99.0, 1.0e9),
        pct(real_val_opf, "itsc_not_opf_score", 99.5, 1.0e9),
        pct(sim_val_itsc, "itsc_not_opf_score", 15, 1.0e9),
        pct(sim_val_itsc, "itsc_not_opf_score", 25, 1.0e9),
        pct(sim_val_itsc, "itsc_not_opf_score", 40, 1.0e9),
    ]
    freq_margin_candidates = [
        pct(real_val_opf, "freq_itsc_margin_over_opf", 99.0, 1.0),
        pct(real_val_opf, "freq_itsc_margin_over_opf", 99.5, 1.0),
        pct(sim_val_itsc, "freq_itsc_margin_over_opf", 10, 1.0),
        pct(sim_val_itsc, "freq_itsc_margin_over_opf", 25, 1.0),
        pct(sim_val_itsc, "freq_itsc_margin_over_opf", 40, 1.0),
    ]

    def i3b_fires(row: Mapping[str, Any], th: Mapping[str, float]) -> bool:
        s = row["scores"]
        return bool(
            float(s.get("opf_f_open_pattern_score", 1.0e9)) < float(th["thr_opf_f_open_pattern_strong"])
            and float(s.get("itsc_not_opf_score", -1.0e9)) >= float(th["thr_itsc_not_opf"])
            and float(s.get("a_phase_local_harmonic_score", -1.0e9)) >= float(th["thr_a_phase_structural"])
            and float(s.get("freq_itsc_margin_over_opf", -1.0e9)) >= float(th["thr_freq_margin_relaxed"])
        )

    best_i3b = {
        "thr_itsc_not_opf": pct(real_val_opf, "itsc_not_opf_score", 99.5, 1.0e9),
        "thr_a_phase_structural": pct(real_val_opf, "a_phase_local_harmonic_score", 99.5, 1.0e9),
        "thr_freq_margin_relaxed": pct(real_val_opf, "freq_itsc_margin_over_opf", 99.5, 1.0),
    }
    best_i3b_score = (-1.0e9, -1.0e9, -1.0e9)
    searched_i3b = 0
    for not_opf in sorted(set(v for v in not_opf_candidates if np.isfinite(v))):
        for structural in sorted(set(v for v in structural_candidates if np.isfinite(v))):
            for freq_margin in sorted(set(v for v in freq_margin_candidates if np.isfinite(v))):
                th = {
                    "thr_opf_f_open_pattern_strong": float(opf_open_strong),
                    "thr_itsc_not_opf": float(not_opf),
                    "thr_a_phase_structural": float(structural),
                    "thr_freq_margin_relaxed": float(freq_margin),
                }
                searched_i3b += 1
                opf_false = sum(1 for r in real_val_opf if i3b_fires(r, th))
                sim_hits = sum(1 for r in sim_val_itsc if i3b_fires(r, th))
                score = (-1000.0 * opf_false, float(sim_hits), -float(not_opf + structural + max(freq_margin, -1.0)))
                if score > best_i3b_score:
                    best_i3b_score = score
                    best_i3b = {k: float(v) for k, v in th.items() if k != "thr_opf_f_open_pattern_strong"}

    def base_is_opf(row: Mapping[str, Any]) -> bool:
        return int(row.get("base_pred_idx", CLASS_TO_IDX["OPF"])) == CLASS_TO_IDX["OPF"]

    def candidate_values(rows_a: Sequence[Mapping[str, Any]], rows_b: Sequence[Mapping[str, Any]], key: str, pcts: Sequence[float]) -> List[float]:
        vals: List[float] = []
        for rows in (rows_a, rows_b):
            for percentile in pcts:
                value = pct(rows, key, percentile, float("nan"))
                if np.isfinite(value):
                    vals.append(float(value))
        return sorted(set(vals))

    struct_a_phase_candidates = candidate_values(
        real_val_opf,
        sim_val_itsc,
        "a_phase_local_harmonic_score",
        [95, 97.5, 99, 99.5, 100, 5, 15, 25, 35, 50],
    )
    struct_not_opf_candidates = candidate_values(
        real_val_opf,
        sim_val_itsc,
        "itsc_not_opf_score",
        [95, 97.5, 99, 99.5, 100, 5, 15, 25, 35, 50],
    )

    def i3b_structural_override_fires(row: Mapping[str, Any], th: Mapping[str, float], require_base_opf: bool = False) -> bool:
        if require_base_opf and not base_is_opf(row):
            return False
        s = row["scores"]
        freq_veto = (
            float(s.get("freq_opf_prob", np.nan)) >= float(th["freq_opf_veto_high"])
            and float(s.get("freq_itsc_prob", np.nan)) <= float(th["freq_itsc_veto_low"])
        )
        return bool(
            float(s.get("a_phase_local_harmonic_score", -1.0e9)) >= float(th["a_phase_high"])
            and float(s.get("itsc_not_opf_score", -1.0e9)) >= float(th["itsc_not_opf_high"])
            and float(s.get("opf_f_open_pattern_score", 1.0e9)) <= float(th["opf_open_max"])
            and not freq_veto
        )

    def select_structural_profile(false_limit: int, false_weight: float, open_percentile: float) -> Tuple[Dict[str, float], Dict[str, Any]]:
        best: Optional[Dict[str, float]] = None
        best_score = (-1.0e18, -1.0e18, -1.0e18)
        searched = 0
        opf_open_max = min(
            float(opf_open_strong),
            pct(sim_val_itsc, "opf_f_open_pattern_score", open_percentile, float(opf_open_strong)),
        )
        # Frequency is only a veto for extreme OPF-like neural evidence. The
        # structural rule should not be blocked by ordinary OPF-vs-ITSC margin.
        freq_opf_veto_high = max(
            0.98,
            pct(real_val_opf, "freq_opf_prob", 99.5, 0.98),
            pct(sim_val_itsc, "freq_opf_prob", 99.5, 0.98),
        )
        freq_itsc_veto_low = min(
            0.02,
            pct(real_val_opf, "freq_itsc_prob", 0.5, 0.02),
            pct(sim_val_itsc, "freq_itsc_prob", 0.5, 0.02),
        )
        for a_phase in struct_a_phase_candidates:
            for not_opf in struct_not_opf_candidates:
                th = {
                    "a_phase_high": float(a_phase),
                    "itsc_not_opf_high": float(not_opf),
                    "opf_open_max": float(opf_open_max),
                    "freq_opf_veto_high": float(freq_opf_veto_high),
                    "freq_itsc_veto_low": float(freq_itsc_veto_low),
                }
                searched += 1
                opf_false = sum(1 for r in real_val_opf if i3b_structural_override_fires(r, th, require_base_opf=True))
                sim_hits = sum(1 for r in sim_val_itsc if i3b_structural_override_fires(r, th, require_base_opf=False))
                if opf_false <= false_limit:
                    score = (float(sim_hits), -float(opf_false), -0.001 * float(a_phase + not_opf))
                else:
                    score = (-false_weight * float(opf_false - false_limit), float(sim_hits), -float(opf_false))
                if score > best_score:
                    best_score = score
                    best = th
        if best is None:
            best = {
                "a_phase_high": 1.0e9,
                "itsc_not_opf_high": 1.0e9,
                "opf_open_max": -1.0e9,
                "freq_opf_veto_high": 1.0,
                "freq_itsc_veto_low": 0.0,
            }
        audit_profile = {
            "search_candidates": int(searched),
            "false_limit": int(false_limit),
            "real_known_val_opf_fired": int(sum(1 for r in real_val_opf if i3b_structural_override_fires(r, best, require_base_opf=True))),
            "sim_val_itsc_fired": int(sum(1 for r in sim_val_itsc if i3b_structural_override_fires(r, best, require_base_opf=False))),
        }
        return best, audit_profile

    safe_struct, safe_struct_audit = select_structural_profile(false_limit=0, false_weight=100000.0, open_percentile=95.0)
    balanced_struct, balanced_struct_audit = select_structural_profile(false_limit=1, false_weight=10000.0, open_percentile=97.5)
    aggressive_struct, aggressive_struct_audit = select_structural_profile(false_limit=max(5, int(math.ceil(0.01 * max(len(real_val_opf), 1)))), false_weight=1000.0, open_percentile=99.0)

    thresholds = {
        "thr_opf_f_open_pattern_strong": float(opf_open_strong),
        **best_i3a,
        **best_i3b,
        "thr_i3b_struct_a_phase_high_safe": float(safe_struct["a_phase_high"]),
        "thr_i3b_struct_itsc_not_opf_high_safe": float(safe_struct["itsc_not_opf_high"]),
        "thr_i3b_struct_opf_open_max_safe": float(safe_struct["opf_open_max"]),
        "thr_i3b_struct_freq_opf_veto_high_safe": float(safe_struct["freq_opf_veto_high"]),
        "thr_i3b_struct_freq_itsc_veto_low_safe": float(safe_struct["freq_itsc_veto_low"]),
        "thr_i3b_struct_a_phase_high_balanced": float(balanced_struct["a_phase_high"]),
        "thr_i3b_struct_itsc_not_opf_high_balanced": float(balanced_struct["itsc_not_opf_high"]),
        "thr_i3b_struct_opf_open_max_balanced": float(balanced_struct["opf_open_max"]),
        "thr_i3b_struct_freq_opf_veto_high_balanced": float(balanced_struct["freq_opf_veto_high"]),
        "thr_i3b_struct_freq_itsc_veto_low_balanced": float(balanced_struct["freq_itsc_veto_low"]),
        "thr_i3b_struct_a_phase_high_aggressive": float(aggressive_struct["a_phase_high"]),
        "thr_i3b_struct_itsc_not_opf_high_aggressive": float(aggressive_struct["itsc_not_opf_high"]),
        "thr_i3b_struct_opf_open_max_aggressive": float(aggressive_struct["opf_open_max"]),
        "thr_i3b_struct_freq_opf_veto_high_aggressive": float(aggressive_struct["freq_opf_veto_high"]),
        "thr_i3b_struct_freq_itsc_veto_low_aggressive": float(aggressive_struct["freq_itsc_veto_low"]),
    }
    audit = {
        "threshold_strategy": "safe_proxy_search_real_known_val_false_zero_preferred_sim_val_ITSC_direction",
        "real_known_val_health_count": int(len(real_val_health)),
        "real_known_val_opf_count": int(len(real_val_opf)),
        "sim_val_itsc_count": int(len(sim_val_itsc)),
        "rule_i3a_search_candidates": int(searched_i3a),
        "rule_i3b_search_candidates": int(searched_i3b),
        "rule_i3a_real_known_val_health_fired": int(sum(1 for r in real_val_health if i3a_fires(r, thresholds))),
        "rule_i3a_sim_val_itsc_fired": int(sum(1 for r in sim_val_itsc if i3a_fires(r, thresholds))),
        "rule_i3b_real_known_val_opf_fired": int(sum(1 for r in real_val_opf if i3b_fires(r, thresholds))),
        "rule_i3b_sim_val_itsc_fired": int(sum(1 for r in sim_val_itsc if i3b_fires(r, thresholds))),
        "rule_i3b_structural_override_safe": safe_struct_audit,
        "rule_i3b_structural_override_balanced": balanced_struct_audit,
        "rule_i3b_structural_override_aggressive": aggressive_struct_audit,
        "opf_f_open_pattern_score_real_known_val_opf_q20": float(pct(real_val_opf, "opf_f_open_pattern_score", 20, 1.0e9)),
        "opf_f_open_pattern_score_selected_strong": float(opf_open_strong),
    }
    return thresholds, audit


def _solve_small_linear_system(A: np.ndarray, b: np.ndarray, eps: float = 1.0e-12) -> np.ndarray:
    """Solve a small dense system without calling platform BLAS/LAPACK."""
    mat = [[float(v) for v in row] for row in np.asarray(A, dtype=np.float64)]
    rhs = [float(v) for v in np.asarray(b, dtype=np.float64).reshape(-1)]
    n = len(rhs)
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(mat[r][col]))
        if abs(mat[pivot][col]) < eps:
            mat[pivot][col] = eps
        if pivot != col:
            mat[col], mat[pivot] = mat[pivot], mat[col]
            rhs[col], rhs[pivot] = rhs[pivot], rhs[col]
        pivot_value = mat[col][col]
        for j in range(col, n):
            mat[col][j] /= pivot_value
        rhs[col] /= pivot_value
        for r in range(n):
            if r == col:
                continue
            factor = mat[r][col]
            if factor == 0.0:
                continue
            for j in range(col, n):
                mat[r][j] -= factor * mat[col][j]
            rhs[r] -= factor * rhs[col]
    return np.asarray(rhs, dtype=np.float64)


def _fit_ridge(X: np.ndarray, y: np.ndarray, alpha: float = 1.0e-3) -> Tuple[float, np.ndarray]:
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64).reshape(-1)
    mean = X.mean(axis=0)
    std = X.std(axis=0)
    std[std < 1.0e-12] = 1.0
    Xn = (X - mean) / std
    n_samples, n_features = Xn.shape
    A = np.zeros((n_features, n_features), dtype=np.float64)
    b = np.zeros(n_features, dtype=np.float64)
    for i in range(n_samples):
        yi = float(y[i])
        row = [float(v) for v in Xn[i]]
        for j in range(n_features):
            b[j] += row[j] * yi
            for k in range(n_features):
                A[j, k] += row[j] * row[k]
    for j in range(n_features):
        A[j, j] += float(alpha)
    coef_n = _solve_small_linear_system(A, b)
    coef = coef_n / std
    intercept = float(y.mean() - sum(float(mean[i]) * float(coef[i]) for i in range(len(coef))))
    return intercept, coef


def fit_physics_reference(samples: Sequence[Mapping[str, Any]], config: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    cfg = prepare_physics_config(config)
    validate_no_real_unknown_for_selection(samples)
    nominal_rows = [
        s for s in samples
        if str(s["label_name"]) in KNOWN_CLASS_NAMES and str(s["source"]) in {"sim_train", "sim_val", "real_known_train", "real_known_val"}
    ]
    if len(nominal_rows) < len(NOMINAL_FEATURE_NAMES) + 1:
        raise ValueError(f"physics nominal fit needs more allowed samples, got {len(nominal_rows)}")

    X = []
    y = []
    for row in nominal_rows:
        features = row["features"]
        nf = _nominal_features_from_basic(features, float(cfg["pole_pairs"]))
        X.append([nf[name] for name in NOMINAL_FEATURE_NAMES])
        y.append(float(features["uq_mean"]))
    intercept, coef = _fit_ridge(np.asarray(X), np.asarray(y), alpha=1.0e-3)
    nominal_model = {
        "intercept": float(intercept),
        "coefficients": {name: float(value) for name, value in zip(NOMINAL_FEATURE_NAMES, coef)},
        "feature_names": list(NOMINAL_FEATURE_NAMES),
        "model_type": "ridge_linear_numpy",
    }

    residuals = []
    psi_health = []
    for row in nominal_rows:
        features = row["features"]
        nf = _nominal_features_from_basic(features, float(cfg["pole_pairs"]))
        pred = float(intercept + np.dot(coef, np.asarray([nf[name] for name in NOMINAL_FEATURE_NAMES], dtype=np.float64)))
        residuals.append(float(features["uq_mean"]) - pred)
        if row["label_name"] == "health":
            psi_health.append(float(features["psi_eff"]))
    residual_center, residual_scale = _robust_center_scale(residuals)
    psi_eff_health_mean, psi_eff_scale = _robust_center_scale(psi_health)

    def residual_for(row: Mapping[str, Any]) -> float:
        nf = _nominal_features_from_basic(row["features"], float(cfg["pole_pairs"]))
        pred = float(intercept + np.dot(coef, np.asarray([nf[name] for name in NOMINAL_FEATURE_NAMES], dtype=np.float64)))
        return float(row["features"]["uq_mean"]) - pred

    sim_health_resid = [residual_for(s) for s in samples if s["source"] in {"sim_train", "sim_val"} and s["label_name"] == "health"]
    sim_tuici_resid = [residual_for(s) for s in samples if s["source"] in {"sim_train", "sim_val"} and s["label_name"] == "tuici"]
    health_center = float(np.median(sim_health_resid)) if sim_health_resid else residual_center
    tuici_center = float(np.median(sim_tuici_resid)) if sim_tuici_resid else health_center
    demag_residual_direction = 1.0 if (tuici_center - health_center) >= 0.0 else -1.0

    raw_ref: Dict[str, Tuple[str, str]] = {
        "local_nonuniformity": ("local_nonuniformity_raw", "local_nonuniformity"),
        "waveform": ("waveform_local_imbalance_raw", "waveform"),
        "freq": ("freq_local_imbalance_raw", "freq"),
        "dq24": ("dq24_raw", "dq24"),
        "ia3": ("ia3_raw", "ia3"),
        "ia3_excess_over_bc": ("ia3_excess_over_bc", "ia3_excess_over_bc"),
        "ia_rms_excess_over_bc": ("ia_rms_excess_over_bc", "ia_rms_excess_over_bc"),
        "a_phase_rms_asym": ("a_phase_rms_asym", "a_phase_rms_asym"),
        "opf_f_zero_score": ("opf_f_zero_score", "opf_f_zero_score"),
        "second_set_imbalance": ("second_set_imbalance", "second_set_imbalance"),
        "if_to_de_median": ("if_to_de_median", "if_to_de_median"),
        "sensor_like": ("sensor_raw", "sensor_like"),
    }
    score_reference: Dict[str, float] = {}
    for prefix, (field, _) in raw_ref.items():
        center, scale = _robust_center_scale([float(s["features"][field]) for s in nominal_rows])
        score_reference[f"{prefix}_center"] = center
        score_reference[f"{prefix}_scale"] = scale

    tmp_cfg = _deep_merge(cfg, {
        "reference": {
            "nominal_uq_model": nominal_model,
            "residual_center": residual_center,
            "residual_scale": residual_scale,
            "psi_eff_health_mean": psi_eff_health_mean,
            "psi_eff_scale": psi_eff_scale,
            "demag_residual_direction": demag_residual_direction,
            "score_reference": score_reference,
        }
    })
    pre_scored_rows = []
    for row in samples:
        features = dict(row["features"])
        tuici_scores = compute_tuici_like_score(features, tmp_cfg)
        features.update(tuici_scores)
        itsc_scores = compute_itsc_like_score(features, tmp_cfg)
        features.update(itsc_scores)
        structural_scores = compute_a_phase_structural_score(features, tmp_cfg)
        features.update(structural_scores)
        row2 = dict(row)
        row2["scores"] = features
        pre_scored_rows.append(row2)

    def build_condition_health_reference(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
        condition_fields = [
            "ia3_excess_over_bc",
            "a_phase_local_harmonic_score",
            "local_nonuniformity_score",
            "waveform_local_imbalance_score",
        ]
        health_rows = [
            r for r in rows
            if r.get("source") == "real_known_val" and r.get("label_name") == "health"
        ]
        speeds = sorted({float(r.get("speed", 0.0)) for r in health_rows})
        loads = sorted({float(r.get("load", 0.0)) for r in health_rows})

        def stats(items: Sequence[Mapping[str, Any]]) -> Dict[str, float]:
            out: Dict[str, float] = {"count": float(len(items))}
            for field in condition_fields:
                center, scale = _robust_center_scale([float(r["scores"].get(field, np.nan)) for r in items])
                out[f"{field}_center"] = float(center)
                out[f"{field}_scale"] = float(scale)
            return out

        grouped: Dict[str, List[Mapping[str, Any]]] = {}
        for row in health_rows:
            grouped.setdefault(_condition_key(float(row.get("speed", 0.0)), float(row.get("load", 0.0))), []).append(row)
        return {
            "source": "real_known_val_health_only",
            "min_count": int(cfg.get("condition_background", {}).get("min_count", 8)),
            "speeds": speeds,
            "loads": loads,
            "global": stats(health_rows),
            "conditions": {key: stats(items) for key, items in grouped.items()},
        }

    condition_health_reference = build_condition_health_reference(pre_scored_rows)
    tmp_cfg = _deep_merge(tmp_cfg, {"reference": {"condition_health_reference": condition_health_reference}})
    scored_rows = []
    health_abnormal_values = []
    for row in pre_scored_rows:
        features = dict(row["scores"])
        condition_scores = compute_condition_background_scores(features, tmp_cfg)
        features.update(condition_scores)
        for key, value in row.get("neural_freq", {}).items():
            features[key] = float(value)
        features["known_expert_conf"] = float(row.get("known_expert_conf", np.nan))
        features["known_expert_margin"] = float(row.get("known_expert_margin", np.nan))
        features["known_expert_pred"] = float(row.get("known_expert_pred", -1))
        features["base_pred_idx"] = float(row.get("base_pred_idx", -1))
        for key in ("base_prob_opf", "base_prob_itsc", "base_itsc_margin_over_opf"):
            if key not in features:
                features[key] = float(row.get("neural_freq", {}).get(key, np.nan))
        alpha = float(cfg["boundary"].get("alpha", 0.5))
        gamma = float(cfg["boundary"].get("gamma", 1.0))
        features["uniform_demag_score"] = float(features["tuici_like_score"] * _sigmoid(-gamma * features["local_nonuniformity_score"]))
        features["itsc_over_tuici_margin"] = float(features["itsc_like_score"] - alpha * features["uniform_demag_score"])
        row2 = dict(row)
        row2["scores"] = features
        scored_rows.append(row2)
        if row["label_name"] in KNOWN_CLASS_NAMES:
            health_abnormal_values.append(abs(features["flux_residual_z"]) + max(0.0, features["local_nonuniformity_score"]) + max(0.0, features["freq_local_imbalance_score"]))

    health_abnormal_center, health_abnormal_scale = _robust_center_scale(health_abnormal_values)
    score_reference["health_abnormal_center"] = health_abnormal_center
    score_reference["health_abnormal_scale"] = health_abnormal_scale

    sim_tuici_margins = [r["scores"]["itsc_over_tuici_margin"] for r in scored_rows if r["source"] == "sim_val" and r["label_name"] == "tuici"]
    known_conf = [r.get("known_expert_conf", 0.0) for r in scored_rows if r["source"] in {"sim_val", "real_known_val"} and r["label_name"] in KNOWN_CLASS_NAMES]
    known_margin = [r.get("known_expert_margin", 0.0) for r in scored_rows if r["source"] in {"sim_val", "real_known_val"} and r["label_name"] in KNOWN_CLASS_NAMES]
    unknown_evidence_known = [
        max(r["scores"]["itsc_like_score"], r["scores"]["tuici_like_score"])
        for r in scored_rows
        if r["source"] in {"sim_val", "real_known_val"} and r["label_name"] in KNOWN_CLASS_NAMES
    ]
    health_like = [r["scores"]["health_like_score"] for r in scored_rows if r["source"] in {"sim_val", "real_known_val"} and r["label_name"] == "health"]
    health_margins = [r["scores"]["itsc_over_tuici_margin"] for r in scored_rows if r["source"] in {"sim_val", "real_known_val"} and r["label_name"] == "health"]
    sim_val_itsc = [r for r in scored_rows if r["source"] == "sim_val" and r["label_name"] == "ITSC"]
    real_known_val = [r for r in scored_rows if r["source"] == "real_known_val" and r["label_name"] in KNOWN_CLASS_NAMES]
    opf_gate_opf = [
        r for r in scored_rows
        if r["label_name"] == "OPF" and r["source"] in {"sim_train", "sim_val", "real_known_train", "real_known_val"}
    ]
    opf_gate_real_opf = [
        r for r in scored_rows
        if r["label_name"] == "OPF" and r["source"] in {"real_known_train", "real_known_val"}
    ]
    opf_gate_exclusion = [
        r for r in scored_rows
        if (r["source"] in {"sim_train", "sim_val"} and r["label_name"] == "ITSC")
        or (r["source"] in {"real_known_train", "real_known_val"} and r["label_name"] in {"health", "Sensor"})
    ]

    def q(rows: Sequence[Mapping[str, Any]], key: str, percentile: float, default: float) -> float:
        values = [float(r["scores"].get(key, np.nan)) for r in rows]
        values = [v for v in values if np.isfinite(v)]
        return float(np.percentile(values, percentile)) if values else float(default)

    opf_f_zero_from_opf = q(opf_gate_real_opf or opf_gate_opf, "opf_f_zero_score", 20, 1.0e9)
    opf_f_zero_from_exclusion = q(opf_gate_exclusion, "opf_f_zero_score", 99, -1.0e9)
    thr_opf_f_zero_high = float(max(opf_f_zero_from_opf, opf_f_zero_from_exclusion))
    if_to_de_from_opf = q(opf_gate_real_opf or opf_gate_opf, "if_to_de_median", 80, -1.0e9)
    if_to_de_from_exclusion = q(opf_gate_exclusion, "if_to_de_median", 1, 1.0e9)
    thr_if_to_de_low = float(min(if_to_de_from_opf, if_to_de_from_exclusion))

    thresholds = {
        "threshold_itsc_over_tuici": float(np.percentile(sim_tuici_margins, 95)) if sim_tuici_margins else 1.0e9,
        "known_expert_conf": float(np.percentile(known_conf, 10)) if known_conf else 1.0,
        "known_expert_margin": float(np.percentile(known_margin, 10)) if known_margin else 1.0,
        "unknown_score_max": float(np.percentile(unknown_evidence_known, 90)) if unknown_evidence_known else -1.0e9,
        "health_like_min": float(np.percentile(health_like, 10)) if health_like else 1.0e9,
        "health_rescue_margin_max": float(np.percentile(health_margins, 90)) if health_margins else -1.0e9,
        "i1_itsc_like_min": q(sim_val_itsc, "itsc_like_score", 25, 1.0e9),
        "i1_itsc_over_tuici_min": q(sim_val_itsc, "itsc_over_tuici_margin", 25, 1.0e9),
        "i1_local_min": q(sim_val_itsc, "local_nonuniformity_score", 5, 1.0e9),
        "i1_local_max": q(sim_val_itsc, "local_nonuniformity_score", 98, 1.0e9),
        "i1_opf_f_zero_max": q(real_known_val, "opf_f_zero_score", 90, -1.0e9),
        "i1_freq_itsc_prob_min": q(sim_val_itsc, "freq_itsc_prob", 25, 1.0),
        "i1_freq_margin_opf_min": q(sim_val_itsc, "freq_itsc_margin_over_opf", 25, 1.0),
        "i1_known_conf_max": q(real_known_val, "known_expert_conf", 90, -1.0e9),
        "thr_opf_f_zero_high": thr_opf_f_zero_high,
        "thr_if_to_de_low": thr_if_to_de_low,
        "i2_itsc_like_min": q(sim_val_itsc, "itsc_like_score", 50, 1.0e9),
        "i2_waveform_min": q(sim_val_itsc, "waveform_local_imbalance_score", 50, 1.0e9),
        "i2_itsc_over_tuici_min": q(sim_val_itsc, "itsc_over_tuici_margin", 50, 1.0e9),
        "i2_freq_itsc_prob_min": q(sim_val_itsc, "freq_itsc_prob", 50, 1.0),
        "i2_known_conf_max": q(real_known_val, "known_expert_conf", 90, -1.0e9),
    }
    opf_like_thresholds, opf_like_audit = _estimate_opf_like_thresholds(scored_rows, thresholds, cfg["class_map"])
    thresholds.update(opf_like_thresholds)
    flux_demag_thresholds, flux_demag_audit = _estimate_flux_demag_rescue_thresholds(scored_rows)
    thresholds.update(flux_demag_thresholds)
    a_phase_thresholds, a_phase_audit = _estimate_a_phase_structural_thresholds(scored_rows)
    thresholds.update(a_phase_thresholds)
    segment_thresholds, segment_audit = _estimate_segment_opf_itsc_thresholds(scored_rows)
    thresholds.update(segment_thresholds)

    return {
        "enabled": True,
        "apply_correction": bool(cfg.get("apply_correction", False)),
        "reference": {
            "nominal_uq_model": nominal_model,
            "residual_center": float(residual_center),
            "residual_scale": float(residual_scale),
            "psi_eff_health_mean": float(psi_eff_health_mean),
            "psi_eff_scale": float(psi_eff_scale),
            "demag_residual_direction": float(demag_residual_direction),
            "score_reference": {k: float(v) for k, v in score_reference.items()},
            "condition_health_reference": condition_health_reference,
        },
        "thresholds": thresholds,
        "audit": {
            "selection_sample_count": int(len(samples)),
            "nominal_sample_count": int(len(nominal_rows)),
            "forbidden_real_unknown_used": False,
            "forbidden_for_selection": list(cfg["leakage_policy"]["forbidden_for_selection"]),
            "allowed_selection_sources": list(cfg["leakage_policy"]["allowed_selection_sources"]),
            "demag_direction_source": "sim_train_val_tuici_minus_sim_train_val_health",
            "threshold_source": "sim_val_and_real_known_val_only",
            "opf_safety_gate_source": "sim_OPF_real_known_OPF_sim_ITSC_real_known_non_OPF",
            "opf_like_safety_proxy_search": opf_like_audit,
            "flux_demag_rescue_threshold_audit": flux_demag_audit,
            "a_phase_structural_itsc_rescue_audit": a_phase_audit,
            "segment_opf_itsc_refinement_audit": segment_audit,
        },
    }


__all__ = [
    "compute_window_physics_features",
    "fit_physics_reference",
    "compute_tuici_like_score",
    "compute_itsc_like_score",
    "build_known_expert_from_prob",
    "physics_informed_postprocess",
    "validate_no_real_unknown_for_selection",
    "prepare_physics_config",
]
