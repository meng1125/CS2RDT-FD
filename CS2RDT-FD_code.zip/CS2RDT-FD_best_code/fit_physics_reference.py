# fit_physics_reference.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import json
import os
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

from dataset import IDX_TO_CLASS
from physics_fusion import (
    CLASS_TO_IDX,
    KNOWN_CLASS_NAMES,
    compute_window_physics_features,
    fit_physics_reference,
    build_known_expert_from_prob,
    validate_no_real_unknown_for_selection,
)
from utils import (
    load_config,
    ensure_dir,
    setup_logger,
    set_random_seed,
    get_device,
    build_model,
    build_dataloader,
    load_model_weights,
    get_or_create_split_records,
    load_scaler,
    save_json,
    move_batch_to_device,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fit physics reference for Stage2 posterior correction")
    parser.add_argument("--config", type=str, default="config.yaml")
    parser.add_argument("--ckpt", type=str, default=None)
    parser.add_argument("--scaler", type=str, default=None)
    parser.add_argument("--output", type=str, default=None)
    parser.add_argument("--max-samples-per-source", type=int, default=0)
    return parser.parse_args()


def _take_indices(indices: Sequence[Tuple[int, int]], max_count: int) -> List[Tuple[int, int]]:
    values = list(indices)
    if max_count and max_count > 0 and len(values) > max_count:
        step = max(len(values) // max_count, 1)
        values = values[::step][:max_count]
    return values


def collect_samples(
    *,
    config: Dict[str, Any],
    split_records: Dict[str, Any],
    logger,
    max_samples_per_source: int = 0,
    model=None,
    device=None,
    scaler=None,
) -> List[Dict[str, Any]]:
    all_records = split_records["all_records"]
    window_size = int(config["data"]["window_size"])
    stride = int(config["data"]["stride"])
    known_set = set(KNOWN_CLASS_NAMES)
    sources = {
        "sim_train": [
            idx for idx in split_records["train"]
            if all_records[int(idx[0])].domain_name == "sim"
        ],
        "sim_val": [
            idx for idx in split_records["val"]
            if all_records[int(idx[0])].domain_name == "sim"
        ],
        "real_known_train": [
            idx for idx in split_records["train"]
            if all_records[int(idx[0])].domain_name == "real" and all_records[int(idx[0])].label_name in known_set
        ],
        "real_known_val": [
            idx for idx in split_records["val"]
            if all_records[int(idx[0])].domain_name == "real" and all_records[int(idx[0])].label_name in known_set
        ],
    }
    samples: List[Dict[str, Any]] = []
    model_lookup: Dict[Tuple[int, int], Dict[str, float]] = {}
    if model is not None and device is not None and scaler is not None:
        import torch
        from dataset import IndexedWindowFaultDataset

        all_selected: List[Tuple[int, int]] = []
        for indices in sources.values():
            all_selected.extend(_take_indices(indices, max_samples_per_source))
        ds = IndexedWindowFaultDataset(
            file_records=all_records,
            window_indices=all_selected,
            window_size=window_size,
            stride=stride,
            scaler=scaler,
            standardize=bool(config["data"].get("standardize", True)),
            augmentor=None,
            is_train=False,
            stage_name="physics_reference_forward",
        )
        loader = build_dataloader(
            dataset=ds,
            batch_size=int(config["data"]["batch_size"]),
            num_workers=0,
            pin_memory=False,
            shuffle=False,
            drop_last=False,
        )
        logger.info("[physics_reference] collecting neural frequency evidence, windows=%d", len(ds))
        model.eval()
        offset = 0
        with torch.no_grad():
            for batch in loader:
                batch_size = int(batch["y"].shape[0])
                batch_indices = all_selected[offset:offset + batch_size]
                offset += batch_size
                batch = move_batch_to_device(batch, device)
                outputs = model(
                    x=batch["x"],
                    x_raw=batch.get("x_raw", None),
                    speed_rpm=batch.get("speed", None),
                    class_condition=batch["y"],
                    grl_lambda_domain=0.0,
                    grl_lambda_domain_global=0.0,
                )
                logits = outputs["logits"]
                logits_freq = outputs.get("logits_freq", torch.zeros_like(logits))
                probs = torch.softmax(logits, dim=1).detach().cpu().numpy()
                probs_freq = torch.softmax(logits_freq, dim=1).detach().cpu().numpy()
                pred_freq = torch.argmax(torch.softmax(logits_freq, dim=1), dim=1).detach().cpu().numpy()
                for i, key in enumerate(batch_indices):
                    known_raw = probs[i, [CLASS_TO_IDX["health"], CLASS_TO_IDX["OPF"], CLASS_TO_IDX["Sensor"]]]
                    known_prob = known_raw / max(float(np.sum(known_raw)), 1.0e-12)
                    known_sorted = np.sort(known_prob)
                    known_local_pred = int(np.argmax(known_prob))
                    known_indices = [CLASS_TO_IDX["health"], CLASS_TO_IDX["OPF"], CLASS_TO_IDX["Sensor"]]
                    known_expert_pred = int(known_indices[known_local_pred])
                    model_lookup[(int(key[0]), int(key[1]))] = {
                        "known_expert_pred": known_expert_pred,
                        "known_expert_conf": float(known_sorted[-1]),
                        "known_expert_margin": float(known_sorted[-1] - known_sorted[-2]),
                        "base_prob_opf": float(probs[i, CLASS_TO_IDX["OPF"]]),
                        "base_prob_itsc": float(probs[i, CLASS_TO_IDX["ITSC"]]),
                        "base_pred_idx": int(np.argmax(probs[i])),
                        "base_itsc_margin_over_opf": float(probs[i, CLASS_TO_IDX["ITSC"]] - probs[i, CLASS_TO_IDX["OPF"]]),
                        "freq_itsc_prob": float(probs_freq[i, CLASS_TO_IDX["ITSC"]]),
                        "freq_opf_prob": float(probs_freq[i, CLASS_TO_IDX["OPF"]]),
                        "freq_tuici_prob": float(probs_freq[i, CLASS_TO_IDX["tuici"]]),
                        "freq_itsc_margin_over_opf": float(probs_freq[i, CLASS_TO_IDX["ITSC"]] - probs_freq[i, CLASS_TO_IDX["OPF"]]),
                        "freq_itsc_margin_over_tuici": float(probs_freq[i, CLASS_TO_IDX["ITSC"]] - probs_freq[i, CLASS_TO_IDX["tuici"]]),
                        "freq_pred_is_itsc": float(int(int(pred_freq[i]) == CLASS_TO_IDX["ITSC"])),
                    }

    for source, indices in sources.items():
        selected = _take_indices(indices, max_samples_per_source)
        logger.info("[physics_reference] source=%s, windows=%d", source, len(selected))
        for record_idx, window_idx in selected:
            record = all_records[int(record_idx)]
            start = int(window_idx) * stride
            end = start + window_size
            if end > int(record.num_steps):
                continue
            row = {
                "source": source,
                "domain_name": str(record.domain_name),
                "label_name": str(record.label_name),
            }
            validate_no_real_unknown_for_selection([row])
            x_raw = record.feature_matrix[start:end].T.astype(np.float32)
            features = compute_window_physics_features(
                x_raw=x_raw,
                speed=float(record.speed),
                load=float(record.load),
                config=config,
            )
            neural = model_lookup.get((int(record_idx), int(window_idx)), {})
            samples.append({
                **row,
                "record_idx": int(record_idx),
                "record_id": int(record_idx),
                "window_idx": int(window_idx),
                "file_path": str(record.file_path),
                "filename": str(record.filename),
                "speed": float(record.speed),
                "load": float(record.load),
                "features": features,
                # Rule B/C thresholds stay conservative until model-output based
                # calibration is explicitly enabled. No real unknown data is used.
                "known_expert_conf": float(neural.get("known_expert_conf", 1.0 if record.label_name in known_set else 0.0)),
                "known_expert_margin": float(neural.get("known_expert_margin", 1.0 if record.label_name in known_set else 0.0)),
                "known_expert_pred": int(record.label),
                "base_pred_idx": int(neural.get("base_pred_idx", record.label)),
                "neural_freq": neural,
            })
    validate_no_real_unknown_for_selection(samples)
    return samples


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    set_random_seed(int(config["random_seed"]))
    paths_cfg = config["paths"]
    ensure_dir(paths_cfg["checkpoint_dir"])
    ensure_dir(paths_cfg["log_dir"])
    logger = setup_logger("fit_physics_reference", paths_cfg["log_dir"], "fit_physics_reference.log", config["logging"]["level"])
    device = get_device(config)

    ckpt_path = args.ckpt or os.path.join(paths_cfg["checkpoint_dir"], "stage2_best.pth")
    scaler_path = args.scaler or os.path.join(paths_cfg["checkpoint_dir"], "scaler_stage2.json")
    output_path = args.output or config.get("physics_fusion", {}).get("reference_path", "checkpoints/physics_reference_stage2.json")
    if not os.path.isabs(output_path):
        output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_path)

    split_pack = get_or_create_split_records(config=config, logger=logger, rebuild=False)
    split_records = split_pack["split_records"]
    scaler = load_scaler(scaler_path)
    model = build_model(config).to(device)
    load_model_weights(model, ckpt_path, map_location="cpu", strict=True)

    samples = collect_samples(
        config=config,
        split_records=split_records,
        logger=logger,
        max_samples_per_source=int(args.max_samples_per_source),
        model=model,
        device=device,
        scaler=scaler,
    )
    ref = fit_physics_reference(samples, config)
    summary = {
        "num_samples": len(samples),
        "by_source_label": {},
    }
    for sample in samples:
        key = f"{sample['source']}::{sample['domain_name']}::{sample['label_name']}"
        summary["by_source_label"][key] = summary["by_source_label"].get(key, 0) + 1
    ref["audit"]["selection_summary"] = summary
    ensure_dir(os.path.dirname(output_path))
    save_json(ref, output_path)
    logger.info("physics reference saved: %s", output_path)
    print(json.dumps({
        "output": output_path,
        "audit": ref["audit"],
        "thresholds": ref["thresholds"],
        "reference_keys": list(ref["reference"].keys()),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
