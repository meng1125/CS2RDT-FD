"""Evaluate the selected model on the independent speed and load combinations."""

import argparse
import hashlib
from io import BytesIO
from itertools import product
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from dataset import (
    CLASS_TO_IDX, FEATURE_CHANNELS, IDX_TO_CLASS, KNOWN_REAL_CLASSES, RAW_CSV_COLUMNS,
    FileRecord, WindowedFaultDataset, build_feature_matrix, compute_num_windows,
)
from evaluate import (
    CLASSES, add_model_arguments, load_student, read_evaluation_config,
    refinement_config, set_physics_reference, summarize,
)
from test import apply_physics_postprocess_to_eval, evaluate_loader
from utils import build_dataloader


LOADS = ("0.69Nm", "0.91Nm", "1.21Nm")
SPEEDS = (672, 718, 785)
MODES = ("student", "with_physics")
LABELS = dict(enumerate(CLASSES))


def load_records(config, data_root):
    expected = {
        data_root / label / load / f"{speed}.csv"
        for label, load, speed in product(CLASSES, LOADS, SPEEDS)
    }
    actual = set(data_root.rglob("*.csv"))
    if actual != expected:
        raise ValueError(f"Unexpected CSV set: missing={expected - actual}, extra={actual - expected}")

    data = config["data"]
    if data["raw_columns"] != RAW_CSV_COLUMNS or data["feature_channels"] != FEATURE_CHANNELS:
        raise ValueError("Locked input channels do not match the dataset implementation")
    records, manifest = [], []
    for path in sorted(expected):
        content = path.read_bytes()
        table = pd.read_csv(BytesIO(content), dtype=np.float64, float_precision="round_trip")
        if list(table.columns) != [f"I{i}" for i in range(len(RAW_CSV_COLUMNS))]:
            raise ValueError(f"Unexpected positional channel names: {path}")
        if not np.isfinite(table.to_numpy()).all():
            raise ValueError(f"Missing or nonfinite samples: {path}")
        table.columns = RAW_CSV_COLUMNS
        label, torque, filename = path.relative_to(data_root).parts
        label_idx = CLASSES.index(label)
        label_name = IDX_TO_CLASS[label_idx]
        speed, load = int(path.stem), float(torque.removesuffix("Nm"))
        median_speed = float(table["v"].median())
        if abs(median_speed - speed) > 2:
            raise ValueError(f"Speed disagrees with filename: {path} ({median_speed} rpm)")
        matrix, channels = build_feature_matrix(table, {name: name for name in FEATURE_CHANNELS})
        steps = len(matrix)
        windows = compute_num_windows(steps, data["window_size"], data["stride"])
        if windows == 0 or channels != FEATURE_CHANNELS or not np.isfinite(matrix).all():
            raise ValueError(f"Invalid input for the locked model: {path}")
        records.append(FileRecord(
            file_path=str(path), filename=filename, load=load, speed=speed,
            domain_name="real", domain=1, label_name=label_name, label=CLASS_TO_IDX[label_name],
            known_real=int(label_name in KNOWN_REAL_CLASSES), trainable_in_real=0,
            num_steps=steps, num_windows=windows, feature_matrix=matrix, available_signals=channels,
        ))
        manifest.append({
            "file": path.relative_to(data_root).as_posix(), "sha256": hashlib.sha256(content).hexdigest(),
            "samples": steps, "windows": windows, "median_speed_rpm": median_speed,
        })
    return records, manifest


def remove_class_condition(_model, _args, kwargs):
    kwargs["class_condition"] = None


def collect_predictions(records, dataset, model, config, device, data_root):
    data = config["data"]
    loader = build_dataloader(dataset, data["batch_size"], 0, pin_memory=device.type == "cuda")
    with model.register_forward_pre_hook(remove_class_condition, with_kwargs=True):
        result = evaluate_loader(model, loader, device, len(CLASSES))
    if len(result["y_true"]) != len(dataset) or not np.isfinite(result["logits"]).all():
        raise ValueError("Incomplete or nonfinite inference output")
    print(f"Student inference complete for {len(dataset)} windows. Applying frozen physics rules.", flush=True)

    # The legacy physics evaluator includes the label in its audit rows. Supply a
    # placeholder there so the postprocessor can run without any ground truth.
    physics = apply_physics_postprocess_to_eval(
        {**result, "y_true": np.zeros_like(result["y_true"])}, config, LABELS,
    )
    files = {record.file_path: record for record in records}
    rows = []
    for i, meta in enumerate(result["meta"]):
        record = files[meta["file_path"]]
        if record.label != result["y_true"][i] or record.speed != result["speed_rpm"][i]:
            raise ValueError(f"Window metadata mismatch: {meta}")
        rows.append({
            "file": Path(record.file_path).relative_to(data_root).as_posix(),
            "load_nm": record.load, "speed_rpm": record.speed, "true_label": record.label,
            "start_sample": meta["window_start"], "end_sample_exclusive": meta["window_end"],
            "student": int(result["y_pred"][i]), "with_physics": int(physics["physics_y_pred"][i]),
            "physics_rules": physics["physics_rows"][i]["applied_rules"],
            **{f"p_{name}": float(result["probs"][i, k]) for k, name in LABELS.items()},
        })
    predictions = pd.DataFrame(rows)
    if predictions.duplicated(["file", "start_sample"]).any():
        raise ValueError("Duplicate window identities")
    return predictions


def metrics(rows):
    target = rows["true_label"].to_numpy()
    return {mode: summarize(target, rows[mode].to_numpy()) for mode in MODES}


def file_votes(windows):
    rows = []
    for file, group in windows.groupby("file", sort=False):
        first = group.iloc[0]
        mean_probs = group[[f"p_{name}" for name in CLASSES]].mean().to_numpy()
        row = {"file": file, "true_label": int(first["true_label"]), "windows": len(group)}
        for mode in MODES:
            counts = np.bincount(group[mode], minlength=len(CLASSES))
            tied = np.flatnonzero(counts == counts.max())
            row[mode] = int(tied[mean_probs[tied].argmax()])
            row[f"{mode}_correct_windows"] = int((group[mode] == row["true_label"]).sum())
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_model_arguments(parser)
    parser.add_argument("--data-root", type=Path, required=True,
                        help="Supplemental CSVs organized as class/load/speed.csv")
    parser.add_argument("--physics-reference", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/unseen"))
    args = parser.parse_args()

    torch.set_num_threads(4)
    config = read_evaluation_config(args)
    reference = set_physics_reference(config, args.physics_reference)
    model, scaler, device, model_info = load_student(config, args.ckpt, args.scaler)
    data_root = args.data_root.resolve(strict=True)
    records, manifest = load_records(config, data_root)
    data = config["data"]
    if not data["standardize"]:
        raise ValueError("The independent test uses the fitted Stage 2 scaler")
    dataset = WindowedFaultDataset(
        records, data["window_size"], data["stride"], scaler=scaler,
        standardize=True, is_train=False, stage_name="stage2",
    )
    print(f"Loaded {len(records)} records and {len(dataset)} complete windows on {device}.", flush=True)
    physics_config = refinement_config(config, True, True)
    windows = collect_predictions(records, dataset, model, physics_config, device, data_root)
    files = file_votes(windows)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    label_columns = ["true_label", *MODES]
    for filename, frame in (("window_predictions.csv", windows), ("file_predictions.csv", files)):
        frame.assign(**{column: frame[column].map(LABELS) for column in label_columns}).to_csv(
            args.output_dir / filename, index=False, encoding="utf-8-sig",
        )
    summary = {
        "model": model_info,
        "physics_reference": str(reference),
        "class_order": CLASSES,
        "window_size": data["window_size"],
        "stride": data["stride"],
        "number_of_files": len(files),
        "number_of_windows": len(windows),
        "window_results": metrics(windows),
        "file_results": metrics(files),
        "condition_results": [
            {"load_nm": float(load), "speed_rpm": int(speed), "windows": len(group), "results": metrics(group)}
            for (load, speed), group in windows.groupby(["load_nm", "speed_rpm"], sort=True)
        ],
        "file_decision_rule": "Majority vote with ties broken by mean Student probability and then class order.",
        "physics_changes": int((windows["student"] != windows["with_physics"]).sum()),
        "input_manifest": manifest,
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8",
    )
    for level in ("window_results", "file_results"):
        for mode, scores in summary[level].items():
            print(f"{level} {mode} {scores['metrics']['Overall Acc.']:.2%}")


if __name__ == "__main__":
    main()
