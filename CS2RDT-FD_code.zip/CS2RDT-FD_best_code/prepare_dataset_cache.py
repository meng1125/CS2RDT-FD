# prepare_dataset_cache.py
# -*- coding: utf-8 -*-

"""一次性扫描原始 CSV 并保存统一数据划分缓存。"""

import argparse

from utils import (
    ensure_dir,
    get_dataset_cache_paths,
    get_or_create_split_records,
    load_config,
    setup_logger,
)


def parse_args():
    parser = argparse.ArgumentParser(description="准备统一数据划分缓存")
    parser.add_argument("--config", type=str, default="config.yaml", help="配置文件路径")
    parser.add_argument("--rebuild", action="store_true", help="强制重新扫描数据并覆盖缓存")
    return parser.parse_args()


def main():
    args = parse_args()
    config = load_config(args.config)
    paths_cfg = config["paths"]
    ensure_dir(paths_cfg["log_dir"])

    logger = setup_logger(
        name="prepare_dataset_cache",
        log_dir=paths_cfg["log_dir"],
        log_filename="prepare_dataset_cache.log",
        level=config["logging"]["level"],
    )

    cache_paths = get_dataset_cache_paths(config)
    logger.info("========== 准备统一数据划分缓存 ==========")
    logger.info(f"cache_dir={cache_paths['cache_dir']}")
    logger.info(f"split_cache={cache_paths['split_cache']}")
    logger.info(f"split_meta={cache_paths['split_meta']}")
    logger.info(f"rebuild={bool(args.rebuild)}")

    split_pack = get_or_create_split_records(config=config, logger=logger, rebuild=bool(args.rebuild))
    split_records = split_pack["split_records"]
    logger.info(
        f"缓存准备完成 | train={len(split_records['train'])}, "
        f"val={len(split_records['val'])}, test={len(split_records['test'])}, "
        f"unknown_test={len(split_records.get('unknown_test', []))}"
    )


if __name__ == "__main__":
    main()
