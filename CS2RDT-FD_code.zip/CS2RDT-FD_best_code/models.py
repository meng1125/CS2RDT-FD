# models.py
# -*- coding: utf-8 -*-

"""
模型模块：
1. Gradient Reversal Layer (GRL)
2. 多尺度 1D CNN 分支
3. TCN 分支
4. 频域分支占位
5. 特征提取器
6. 故障-工况解耦模块
7. FC 分类器
8. Prototype 分类器
9. 条件域判别器
10. 工况预测器
11. FullModel：统一封装前向输出
"""

from typing import Dict, Optional, Sequence, Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function


# =========================
# 1. Gradient Reversal Layer
# =========================
class GradientReversalFunction(Function):
    """
    GRL 的核心思想：
    - 前向传播时恒等映射
    - 反向传播时将梯度乘上 -lambda
    用于域对齐或对抗去条件信息
    """

    @staticmethod
    def forward(ctx, x: torch.Tensor, lambda_: float) -> torch.Tensor:
        ctx.lambda_ = lambda_
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        return -ctx.lambda_ * grad_output, None


class GradientReversalLayer(nn.Module):
    """GRL 的模块封装"""

    def __init__(self, lambda_: float = 1.0):
        super().__init__()
        self.lambda_ = lambda_

    def forward(self, x: torch.Tensor, lambda_: Optional[float] = None) -> torch.Tensor:
        lambda_ = self.lambda_ if lambda_ is None else lambda_
        return GradientReversalFunction.apply(x, float(lambda_))


# =========================
# 2. 基础卷积块
# =========================
class ConvBNAct1d(nn.Module):
    """基础的 1D Conv + BN + GELU + Dropout"""

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        stride: int = 1,
        dilation: int = 1,
        dropout: float = 0.0,
    ):
        super().__init__()
        padding = ((kernel_size - 1) // 2) * dilation
        self.block = nn.Sequential(
            nn.Conv1d(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=False
            ),
            nn.BatchNorm1d(out_channels),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


# =========================
# 3. MultiScale CNN Branch
# =========================
class MultiScaleCNN1D(nn.Module):
    """
    多尺度 1D CNN 分支：
    使用多个不同卷积核大小的并行卷积分支提取时域局部模式，
    对电机故障瞬态、周期纹波、谐波变化更友好。
    """

    def __init__(
        self,
        in_channels: int,
        branch_channels: int = 64,
        kernel_sizes: Sequence[int] = (3, 5, 7),
        dropout: float = 0.1,
    ):
        super().__init__()

        self.branches = nn.ModuleList([
            nn.Sequential(
                ConvBNAct1d(in_channels, branch_channels, kernel_size=k, dropout=dropout),
                ConvBNAct1d(branch_channels, branch_channels, kernel_size=k, dropout=dropout),
            )
            for k in kernel_sizes
        ])

        fused_channels = branch_channels * len(kernel_sizes)
        self.fuse = nn.Sequential(
            nn.Conv1d(fused_channels, fused_channels, kernel_size=1, bias=False),
            nn.BatchNorm1d(fused_channels),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.out_channels = fused_channels

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        输入:
            x: [B, C, T]
        输出:
            feat_map: [B, C_out, T]
        """
        outs = [branch(x) for branch in self.branches]
        x = torch.cat(outs, dim=1)
        x = self.fuse(x)
        return x


# =========================
# 4. TCN Block / Branch
# =========================
class TCNBlock(nn.Module):
    """
    标准残差 TCN block
    使用膨胀卷积扩大感受野，适合时序故障模式建模
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        dilation: int = 1,
        dropout: float = 0.1,
    ):
        super().__init__()
        padding = ((kernel_size - 1) // 2) * dilation

        self.conv1 = nn.Conv1d(
            in_channels, out_channels, kernel_size,
            padding=padding, dilation=dilation, bias=False
        )
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.conv2 = nn.Conv1d(
            out_channels, out_channels, kernel_size,
            padding=padding, dilation=dilation, bias=False
        )
        self.bn2 = nn.BatchNorm1d(out_channels)

        self.dropout = nn.Dropout(dropout)
        self.act = nn.GELU()

        if in_channels != out_channels:
            self.residual = nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False)
        else:
            self.residual = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.residual(x)

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.act(out)
        out = self.dropout(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.dropout(out)

        out = out + identity
        out = self.act(out)
        return out


class TCNBranch(nn.Module):
    """
    TCN 分支：串联多个 TCNBlock
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: Sequence[int] = (64, 128),
        kernel_size: int = 3,
        dropout: float = 0.1,
    ):
        super().__init__()

        blocks = []
        prev_c = in_channels
        for i, out_c in enumerate(hidden_channels):
            dilation = 2 ** i
            blocks.append(
                TCNBlock(
                    in_channels=prev_c,
                    out_channels=out_c,
                    kernel_size=kernel_size,
                    dilation=dilation,
                    dropout=dropout,
                )
            )
            prev_c = out_c

        self.blocks = nn.ModuleList(blocks)
        self.out_channels = prev_c

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for block in self.blocks:
            x = block(x)
        return x


# =========================
# 5. Optional Frequency Branch
# =========================
class OptionalFreqBranch(nn.Module):
    """
    预留的频域分支：
    当前给出一个可运行的占位版本，
    后续可替换为 STFT / CWT / learnable spectral encoder 等更强实现。
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int = 64,
        out_dim: int = 64,
        enabled: bool = False,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.enabled = enabled

        if self.enabled:
            self.net = nn.Sequential(
                nn.Conv1d(in_channels, hidden_channels, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm1d(hidden_channels),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Conv1d(hidden_channels, hidden_channels, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm1d(hidden_channels),
                nn.GELU(),
                nn.AdaptiveAvgPool1d(1),
            )
            self.fc = nn.Sequential(
                nn.Flatten(),
                nn.Linear(hidden_channels, out_dim),
                nn.GELU(),
                nn.Dropout(dropout),
            )
            self.out_dim = out_dim
        else:
            self.net = None
            self.fc = None
            self.out_dim = 0

    def forward(self, x: torch.Tensor) -> Optional[torch.Tensor]:
        """
        输入 x: [B, C, T]
        输出:
            freq_vec: [B, out_dim] 或 None
        """
        if not self.enabled:
            return None

        # rFFT 幅值谱，保留非负频率部分
        x_freq = torch.fft.rfft(x, dim=-1)
        x_mag = torch.abs(x_freq)

        feat = self.net(x_mag)
        feat = self.fc(feat)
        return feat


def softplus_inverse(value: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """Numerically stable inverse of softplus for positive initialization values."""
    value = torch.as_tensor(value).clamp_min(eps)
    return value + torch.log(-torch.expm1(-value))


class ElectricalFrequencyAdaptiveOrderSampler(nn.Module):
    """
    电频率驱动的可学习 soft order-band sampler。

    与参考文件 classifier_0526_v1(1).py 中机械频率 mask 的关键差异：
    - 这里使用电频率 f_e = rpm / 60 * pole_pairs；
    - 当前 pole_pairs=5，因此 f_e = rpm / 12；
    - 默认只学习 5 个单调递增阶次中心，初始化为 [1, 2, 3, 4, 5]。
    """

    def __init__(
        self,
        sample_rate_hz: float = 1000.0,
        window_size: int = 2000,
        pole_pairs: int = 5,
        num_centers: int = 5,
        half_width_fe_ratio: float = 0.5,
        min_sigma_hz: float = 0.5,
        eps: float = 1e-6,
    ):
        super().__init__()
        if num_centers <= 0:
            raise ValueError("num_centers 必须为正整数")
        if sample_rate_hz <= 0:
            raise ValueError("sample_rate_hz 必须为正数")
        if window_size <= 0:
            raise ValueError("window_size 必须为正整数")

        self.sample_rate_hz = float(sample_rate_hz)
        self.window_size = int(window_size)
        self.pole_pairs = int(pole_pairs)
        self.num_centers = int(num_centers)
        self.half_width_fe_ratio = float(half_width_fe_ratio)
        self.min_sigma_hz = float(min_sigma_hz)
        self.eps = float(eps)

        init_k = torch.arange(1, self.num_centers + 1, dtype=torch.float32)
        first = init_k[:1]
        deltas = torch.diff(init_k, prepend=torch.zeros(1, dtype=torch.float32))
        self.raw_first_order = nn.Parameter(softplus_inverse(first))
        self.raw_order_deltas = nn.Parameter(softplus_inverse(deltas))

        freq_axis = torch.linspace(
            0.0,
            self.sample_rate_hz / 2.0,
            self.window_size // 2 + 1,
            dtype=torch.float32,
        )
        self.register_buffer("freq_axis_hz", freq_axis, persistent=False)

    def get_order_k(self) -> torch.Tensor:
        first = F.softplus(self.raw_first_order).view(1)
        deltas = F.softplus(self.raw_order_deltas).view(-1)
        if deltas.numel() > 0:
            deltas = deltas.clone()
            deltas[0] = first[0]
        order_k = torch.cumsum(deltas, dim=0)
        return order_k

    def forward(self, x_freq_mag: torch.Tensor, speed_rpm: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            x_freq_mag: [B, C_freq, F] rFFT magnitude/log magnitude spectrum.
            speed_rpm: [B] or [B, 1] speed in rpm.
        Returns:
            dict with x_order [B, C_freq, K] and diagnostics.
        """
        if speed_rpm is None:
            raise ValueError("启用频域分支时必须提供 speed_rpm")
        if speed_rpm.dim() > 1:
            speed_rpm = speed_rpm.view(speed_rpm.size(0), -1)[:, 0]
        speed_rpm = speed_rpm.to(device=x_freq_mag.device, dtype=x_freq_mag.dtype)
        if torch.isnan(speed_rpm).any():
            raise ValueError("启用频域分支时 batch['speed'] 中存在 NaN，无法计算电频率 mask")

        freq_axis = self.freq_axis_hz.to(device=x_freq_mag.device, dtype=x_freq_mag.dtype)
        if x_freq_mag.size(-1) != freq_axis.numel():
            freq_axis = torch.linspace(
                0.0,
                self.sample_rate_hz / 2.0,
                x_freq_mag.size(-1),
                device=x_freq_mag.device,
                dtype=x_freq_mag.dtype,
            )

        electrical_frequency_hz = speed_rpm * float(self.pole_pairs) / 60.0  # [B]
        electrical_frequency_hz = electrical_frequency_hz.clamp_min(self.eps)

        order_k = self.get_order_k().to(device=x_freq_mag.device, dtype=x_freq_mag.dtype)  # [K]
        target_freq_hz = electrical_frequency_hz.unsqueeze(1) * order_k.unsqueeze(0)  # [B, K]

        sigma_hz = torch.clamp(
            electrical_frequency_hz.unsqueeze(1) * self.half_width_fe_ratio,
            min=self.min_sigma_hz,
        )
        diff = freq_axis.view(1, 1, -1) - target_freq_hz.unsqueeze(-1)  # [B, K, F]
        mask = torch.exp(-0.5 * (diff / sigma_hz.unsqueeze(-1)).pow(2))

        nyquist = self.sample_rate_hz / 2.0
        gate = ((target_freq_hz > 0.0) & (target_freq_hz <= nyquist)).to(x_freq_mag.dtype)
        mask = mask * gate.unsqueeze(-1)
        mask_sum = mask.sum(dim=-1, keepdim=True).clamp_min(self.eps)
        mask = mask / mask_sum

        x_order = torch.einsum("bcf,bkf->bck", x_freq_mag, mask)
        return {
            "x_order": x_order,
            "freq_mask": mask,
            "freq_order_k": order_k,
            "freq_order_centers_hz": target_freq_hz,
            "freq_gate": gate,
            "electrical_frequency_hz": electrical_frequency_hz,
        }


class FrequencyBranch(nn.Module):
    """ia/id2 电频率自适应频域分支。"""

    def __init__(
        self,
        input_indices: Sequence[int] = (5, 7),
        sample_rate_hz: float = 1000.0,
        window_size: int = 2000,
        pole_pairs: int = 5,
        num_centers: int = 5,
        hidden_channels: int = 32,
        out_dim: int = 64,
        half_width_fe_ratio: float = 0.5,
        log_scale: float = 100.0,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.input_indices = tuple(int(i) for i in input_indices)
        self.sample_rate_hz = float(sample_rate_hz)
        self.window_size = int(window_size)
        self.log_scale = float(log_scale)
        self.out_dim = int(out_dim)

        self.sampler = ElectricalFrequencyAdaptiveOrderSampler(
            sample_rate_hz=sample_rate_hz,
            window_size=window_size,
            pole_pairs=pole_pairs,
            num_centers=num_centers,
            half_width_fe_ratio=half_width_fe_ratio,
        )
        self.net = nn.Sequential(
            nn.Conv1d(len(self.input_indices), hidden_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm1d(hidden_channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(hidden_channels, hidden_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm1d(hidden_channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Flatten(),
            nn.Linear(hidden_channels * num_centers, out_dim),
            nn.LayerNorm(out_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.register_buffer("hann_window", torch.hann_window(self.window_size), persistent=False)

    def forward(self, x: torch.Tensor, speed_rpm: torch.Tensor) -> Dict[str, torch.Tensor]:
        if x.dim() != 3:
            raise ValueError(f"FrequencyBranch 期望 x 为 [B,C,T]，实际 shape={tuple(x.shape)}")
        if max(self.input_indices) >= x.size(1):
            raise ValueError(f"频域输入通道索引 {self.input_indices} 超出输入通道数 {x.size(1)}")

        x_freq_time = x[:, self.input_indices, :]
        if x_freq_time.size(-1) == self.window_size:
            window = self.hann_window.to(device=x.device, dtype=x.dtype).view(1, 1, -1)
            x_freq_time = x_freq_time * window

        x_fft = torch.fft.rfft(x_freq_time, dim=-1)
        x_mag = torch.abs(x_fft)
        x_mag = torch.log1p(torch.clamp(x_mag, min=0.0) * self.log_scale)

        sampler_out = self.sampler(x_mag, speed_rpm)
        x_order = sampler_out["x_order"]
        freq_vec = self.net(x_order)
        sampler_out["freq_order_features"] = x_order
        sampler_out["freq_vec"] = freq_vec
        return sampler_out


class ClassAdaptiveLogitFusion(nn.Module):
    """
    Learnable class-adaptive time-frequency logit fusion.

    Class order is fixed by dataset.IDX_TO_CLASS:
        0 health, 1 OPF, 2 ITSC, 3 Sensor, 4 tuici

    For each class c:
        final_logits_c = (1 - alpha_c) * logits_time_c + alpha_c * logits_freq_c
    """

    def __init__(
        self,
        num_classes: int = 5,
        init_alpha: Optional[Sequence[float]] = None,
        alpha_min: float = 0.1,
        alpha_max: float = 0.9,
    ):
        super().__init__()
        self.num_classes = int(num_classes)
        self.alpha_min = float(alpha_min)
        self.alpha_max = float(alpha_max)

        if not (0.0 <= self.alpha_min < self.alpha_max <= 1.0):
            raise ValueError(
                f"alpha_min/alpha_max 必须满足 0 <= min < max <= 1，"
                f"当前 min={self.alpha_min}, max={self.alpha_max}"
            )

        if init_alpha is None:
            init_alpha_tensor = torch.tensor(
                [0.25, 0.40, 0.75, 0.30, 0.40],
                dtype=torch.float32,
            )
        else:
            init_alpha_tensor = torch.tensor(list(init_alpha), dtype=torch.float32)

        if init_alpha_tensor.numel() != self.num_classes:
            raise ValueError(
                f"init_alpha 长度必须等于 num_classes={self.num_classes}，"
                f"当前长度={init_alpha_tensor.numel()}"
            )
        if torch.any(init_alpha_tensor < self.alpha_min) or torch.any(init_alpha_tensor > self.alpha_max):
            raise ValueError(
                f"init_alpha 必须位于 [{self.alpha_min}, {self.alpha_max}] 内，"
                f"当前 init_alpha={init_alpha_tensor.tolist()}"
            )

        self.register_buffer("alpha_prior", init_alpha_tensor.clone())

        init_alpha_norm = (init_alpha_tensor - self.alpha_min) / (self.alpha_max - self.alpha_min)
        init_alpha_norm = torch.clamp(init_alpha_norm, 1e-4, 1.0 - 1e-4)
        self.alpha_logit = nn.Parameter(torch.logit(init_alpha_norm))

    def get_alpha(self) -> torch.Tensor:
        """Return class-wise frequency fusion weights with shape [num_classes]."""
        alpha_norm = torch.sigmoid(self.alpha_logit)
        alpha = self.alpha_min + (self.alpha_max - self.alpha_min) * alpha_norm
        return alpha

    def forward(self, logits_time: torch.Tensor, logits_freq: torch.Tensor):
        if logits_time.shape != logits_freq.shape:
            raise ValueError(
                f"logits_time shape {tuple(logits_time.shape)} and "
                f"logits_freq shape {tuple(logits_freq.shape)} must be the same."
            )
        if logits_time.dim() != 2 or logits_time.size(1) != self.num_classes:
            raise ValueError(
                f"logits_time/logits_freq 必须为 [B, {self.num_classes}]，"
                f"当前 shape={tuple(logits_time.shape)}"
            )

        alpha = self.get_alpha().to(device=logits_time.device, dtype=logits_time.dtype)
        alpha_view = alpha.view(1, -1)
        final_logits = (1.0 - alpha_view) * logits_time + alpha_view * logits_freq
        return final_logits, alpha


# =========================
# 6. Feature Extractor
# =========================
class FeatureExtractor(nn.Module):
    """
    特征提取器：
    - MultiScaleCNN1D 分支
    - TCN 分支
    - 可选频域分支
    最终融合成 shared feature
    """

    def __init__(
        self,
        in_channels: int,
        shared_dim: int = 256,
        mscnn_branch_channels: int = 64,
        mscnn_kernel_sizes: Sequence[int] = (3, 5, 7),
        tcn_hidden_channels: Sequence[int] = (64, 128),
        tcn_kernel_size: int = 3,
        tcn_dropout: float = 0.1,
        use_freq_branch: bool = False,
        freq_branch_channels: int = 64,
        freq_out_dim: int = 64,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.mscnn = MultiScaleCNN1D(
            in_channels=in_channels,
            branch_channels=mscnn_branch_channels,
            kernel_sizes=mscnn_kernel_sizes,
            dropout=dropout,
        )

        self.tcn = TCNBranch(
            in_channels=in_channels,
            hidden_channels=tcn_hidden_channels,
            kernel_size=tcn_kernel_size,
            dropout=tcn_dropout,
        )

        self.freq_branch = OptionalFreqBranch(
            in_channels=in_channels,
            hidden_channels=freq_branch_channels,
            out_dim=freq_out_dim,
            enabled=use_freq_branch,
            dropout=dropout,
        )

        temporal_fusion_dim = 2 * self.mscnn.out_channels + 2 * self.tcn.out_channels
        total_fusion_dim = temporal_fusion_dim + self.freq_branch.out_dim

        self.proj = nn.Sequential(
            nn.Linear(total_fusion_dim, shared_dim),
            nn.LayerNorm(shared_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(shared_dim, shared_dim),
            nn.LayerNorm(shared_dim),
            nn.GELU(),
        )

        self.shared_dim = shared_dim

    @staticmethod
    def temporal_pool(feat_map: torch.Tensor) -> torch.Tensor:
        """
        将 [B, C, T] 特征图做 avg + max pooling 后拼接为 [B, 2C]
        """
        avg_pool = F.adaptive_avg_pool1d(feat_map, 1).squeeze(-1)
        max_pool = F.adaptive_max_pool1d(feat_map, 1).squeeze(-1)
        return torch.cat([avg_pool, max_pool], dim=1)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        输入:
            x: [B, C, T]
        输出:
            dict:
            {
              "mscnn_map": ...,
              "tcn_map": ...,
              "freq_vec": ...,
              "shared": ...
            }
        """
        mscnn_map = self.mscnn(x)
        tcn_map = self.tcn(x)

        mscnn_vec = self.temporal_pool(mscnn_map)
        tcn_vec = self.temporal_pool(tcn_map)

        fusion_parts = [mscnn_vec, tcn_vec]

        freq_vec = self.freq_branch(x)
        if freq_vec is not None:
            fusion_parts.append(freq_vec)

        fusion_vec = torch.cat(fusion_parts, dim=1)
        shared = self.proj(fusion_vec)

        return {
            "mscnn_map": mscnn_map,
            "tcn_map": tcn_map,
            "freq_vec": freq_vec,
            "shared": shared,
        }

    def freeze_low_level(self, freeze_cnn: bool = True, freeze_tcn_blocks: int = 1) -> None:
        """
        Stage3 中用于冻结部分低层特征提取层
        """
        if freeze_cnn:
            for p in self.mscnn.parameters():
                p.requires_grad = False

        for idx, block in enumerate(self.tcn.blocks):
            if idx < freeze_tcn_blocks:
                for p in block.parameters():
                    p.requires_grad = False


# =========================
# 7. Fault Feature Head
# =========================
class FaultFeatureHead(nn.Module):
    """将 shared feature 投影为故障特征 z_fault。"""

    def __init__(
        self,
        shared_dim: int,
        feature_dim: int = 128,
        hidden_dim: int = 256,
        dropout: float = 0.1,
        normalize_fault: bool = True,
    ):
        super().__init__()
        self.normalize_fault = normalize_fault

        self.trunk = nn.Sequential(
            nn.Linear(shared_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.fault_head = nn.Sequential(
            nn.Linear(hidden_dim, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.GELU(),
        )

        self.feature_dim = feature_dim

    def forward(self, shared: torch.Tensor) -> Dict[str, torch.Tensor]:
        h = self.trunk(shared)
        z_fault = self.fault_head(h)

        # 原型分类通常更适合使用归一化的故障特征
        if self.normalize_fault:
            z_fault = F.normalize(z_fault, dim=1)

        return {
            "z_fault": z_fault,
        }


# =========================
# 8. FC Classifier
# =========================
class FCClassifier(nn.Module):
    """普通全连接分类头"""

    def __init__(
        self,
        in_dim: int,
        num_classes: int = 5,
        hidden_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, z_fault: torch.Tensor) -> torch.Tensor:
        return self.net(z_fault)


# =========================
# 9. Prototype Classifier
# =========================
class PrototypeClassifier(nn.Module):
    """
    原型分类器：
    维护 5 类原型，支持：
    - cosine similarity 分类
    - euclidean distance 分类
    """

    def __init__(
        self,
        num_classes: int,
        feat_dim: int,
        metric: str = "cosine",
        temperature: float = 0.1,
    ):
        super().__init__()
        assert metric in ["cosine", "euclidean"], "metric 必须为 cosine 或 euclidean"

        self.num_classes = num_classes
        self.feat_dim = feat_dim
        self.metric = metric
        self.temperature = temperature

        self.prototypes = nn.Parameter(torch.randn(num_classes, feat_dim))
        nn.init.xavier_uniform_(self.prototypes)

    def get_normalized_prototypes(self) -> torch.Tensor:
        return F.normalize(self.prototypes, dim=1)

    def compute_distances(self, z_fault: torch.Tensor) -> torch.Tensor:
        """
        计算样本到各类原型的距离
        返回:
            distances: [B, num_classes]
        """
        if self.metric == "cosine":
            z = F.normalize(z_fault, dim=1)
            p = self.get_normalized_prototypes()
            sim = torch.matmul(z, p.t())     # [B, K]
            dist = 1.0 - sim
        else:
            dist = torch.cdist(z_fault, self.prototypes, p=2)  # [B, K]
        return dist

    def forward(self, z_fault: torch.Tensor) -> torch.Tensor:
        """
        输出 proto_logits
        - cosine: 相似度 / temperature
        - euclidean: 负距离 / temperature
        """
        if self.metric == "cosine":
            z = F.normalize(z_fault, dim=1)
            p = self.get_normalized_prototypes()
            logits = torch.matmul(z, p.t()) / self.temperature
        else:
            distances = torch.cdist(z_fault, self.prototypes, p=2)
            logits = -distances / self.temperature
        return logits

    @torch.no_grad()
    def momentum_update(
        self,
        features: torch.Tensor,
        labels: torch.Tensor,
        momentum: float = 0.9
    ) -> None:
        """
        可选：使用当前 batch 的特征对原型做动量更新
        后续 trainer 中若需要可调用
        """
        for cls in labels.unique():
            cls_idx = int(cls.item())
            mask = (labels == cls)
            if mask.sum() == 0:
                continue
            batch_center = features[mask].mean(dim=0)
            old_proto = self.prototypes[cls_idx]
            new_proto = momentum * old_proto + (1.0 - momentum) * batch_center
            self.prototypes[cls_idx].copy_(new_proto)


# =========================
# 10. Conditional Domain Discriminator
# =========================
class ConditionalDomainDiscriminator(nn.Module):
    """
    条件域判别器：
    输入为 z_fault 与 class condition（one-hot 或 soft probability）
    用于实现“条件域对齐”，避免对所有类别做粗暴全局对齐。
    """

    def __init__(
        self,
        feat_dim: int,
        num_classes: int,
        hidden_dim: int = 128,
        cond_embed_dim: int = 64,
        num_domains: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_classes = num_classes
        self.grl = GradientReversalLayer(lambda_=1.0)

        self.cond_proj = nn.Sequential(
            nn.Linear(num_classes, cond_embed_dim),
            nn.LayerNorm(cond_embed_dim),
            nn.GELU(),
        )

        self.net = nn.Sequential(
            nn.Linear(feat_dim + cond_embed_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_domains),
        )

    def _to_condition_tensor(self, class_condition: torch.Tensor) -> torch.Tensor:
        """
        支持两种输入：
        1. [B] 的类别 id
        2. [B, num_classes] 的 one-hot / soft label
        """
        if class_condition.dim() == 1:
            class_condition = F.one_hot(class_condition.long(), num_classes=self.num_classes).float()
        else:
            class_condition = class_condition.float()
        return class_condition

    def forward(
        self,
        z_fault: torch.Tensor,
        class_condition: torch.Tensor,
        grl_lambda: float = 1.0
    ) -> torch.Tensor:
        """
        输出:
            domain_logits: [B, 2]
        """
        z_adv = self.grl(z_fault, lambda_=grl_lambda)
        cond = self._to_condition_tensor(class_condition)
        cond_feat = self.cond_proj(cond)
        x = torch.cat([z_adv, cond_feat], dim=1)
        domain_logits = self.net(x)
        return domain_logits


# =========================
# 11. Global Domain Discriminator
# =========================
class GlobalDomainDiscriminator(nn.Module):
    """
    全局域判别器：
    仅输入 z_fault，不使用类别条件。

    用于 DANN 风格的全局域对齐：
    - 仿真域真实已知类
    - 真实域真实已知类
    通过 GRL 让 z_fault 的已知类整体域信息减少。
    """

    def __init__(
        self,
        feat_dim: int,
        hidden_dim: int = 128,
        num_domains: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.grl = GradientReversalLayer(lambda_=1.0)
        self.net = nn.Sequential(
            nn.Linear(feat_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_domains),
        )

    def forward(self, z_fault: torch.Tensor, grl_lambda: float = 1.0) -> torch.Tensor:
        z_adv = self.grl(z_fault, lambda_=grl_lambda)
        return self.net(z_adv)



# =========================
# 12. Full Model
# =========================
class FullModel(nn.Module):
    """
    总模型：
    forward 输出：
    {
      "z_fault": ...,
      "fc_logits": ...,
      "proto_logits": ...,
      "logits": ...,
      "domain_logits": ...
    }
    """

    def __init__(
        self,
        in_channels: int,
        num_classes: int = 5,
        num_domains: int = 2,
        shared_dim: int = 256,
        feature_dim: int = 128,
        mscnn_branch_channels: int = 64,
        mscnn_kernel_sizes: Sequence[int] = (3, 5, 7),
        tcn_hidden_channels: Sequence[int] = (64, 128),
        tcn_kernel_size: int = 3,
        tcn_dropout: float = 0.1,
        use_freq_branch: bool = False,
        freq_branch_channels: int = 64,
        freq_out_dim: int = 64,
        sample_rate_hz: float = 1000.0,
        window_size: int = 2000,
        pole_pairs: int = 5,
        freq_input_indices: Sequence[int] = (5, 7),
        freq_num_centers: int = 5,
        freq_half_width_fe_ratio: float = 0.5,
        freq_log_scale: float = 100.0,
        fusion_alpha_init: Optional[Sequence[float]] = None,
        fusion_alpha_min: float = 0.1,
        fusion_alpha_max: float = 0.9,
        classifier_hidden_dim: int = 128,
        domain_hidden_dim: int = 128,
        proto_metric: str = "cosine",
        proto_temperature: float = 0.1,
        proto_alpha: float = 0.1,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_classes = num_classes
        self.num_domains = num_domains
        self.proto_alpha = proto_alpha
        self.use_freq_branch = bool(use_freq_branch)

        self.feature_extractor = FeatureExtractor(
            in_channels=in_channels,
            shared_dim=shared_dim,
            mscnn_branch_channels=mscnn_branch_channels,
            mscnn_kernel_sizes=mscnn_kernel_sizes,
            tcn_hidden_channels=tcn_hidden_channels,
            tcn_kernel_size=tcn_kernel_size,
            tcn_dropout=tcn_dropout,
            use_freq_branch=False,
            freq_branch_channels=freq_branch_channels,
            freq_out_dim=freq_out_dim,
            dropout=dropout,
        )

        self.frequency_branch = None
        self.freq_classifier = None
        if self.use_freq_branch:
            self.frequency_branch = FrequencyBranch(
                input_indices=freq_input_indices,
                sample_rate_hz=sample_rate_hz,
                window_size=window_size,
                pole_pairs=pole_pairs,
                num_centers=freq_num_centers,
                hidden_channels=freq_branch_channels,
                out_dim=freq_out_dim,
                half_width_fe_ratio=freq_half_width_fe_ratio,
                log_scale=freq_log_scale,
                dropout=dropout,
            )
            self.freq_classifier = FCClassifier(
                in_dim=freq_out_dim,
                num_classes=num_classes,
                hidden_dim=classifier_hidden_dim,
                dropout=dropout,
            )

        self.logit_fusion = ClassAdaptiveLogitFusion(
            num_classes=num_classes,
            init_alpha=fusion_alpha_init,
            alpha_min=fusion_alpha_min,
            alpha_max=fusion_alpha_max,
        )

        self.disentangler = FaultFeatureHead(
            shared_dim=shared_dim,
            feature_dim=feature_dim,
            hidden_dim=shared_dim,
            dropout=dropout,
            normalize_fault=True,
        )

        self.fc_classifier = FCClassifier(
            in_dim=feature_dim,
            num_classes=num_classes,
            hidden_dim=classifier_hidden_dim,
            dropout=dropout,
        )

        self.prototype_classifier = PrototypeClassifier(
            num_classes=num_classes,
            feat_dim=feature_dim,
            metric=proto_metric,
            temperature=proto_temperature,
        )

        self.domain_discriminator = ConditionalDomainDiscriminator(
            feat_dim=feature_dim,
            num_classes=num_classes,
            hidden_dim=domain_hidden_dim,
            cond_embed_dim=max(32, feature_dim // 2),
            num_domains=num_domains,
            dropout=dropout,
        )

        self.global_domain_discriminator = GlobalDomainDiscriminator(
            feat_dim=feature_dim,
            hidden_dim=domain_hidden_dim,
            num_domains=num_domains,
            dropout=dropout,
        )

    @staticmethod
    def _logit_margin(logits: torch.Tensor) -> torch.Tensor:
        if logits.size(1) < 2:
            return torch.zeros(logits.size(0), device=logits.device, dtype=logits.dtype)
        top2 = torch.topk(logits, k=2, dim=1).values
        return top2[:, 0] - top2[:, 1]

    @staticmethod
    def _normalized_entropy(logits: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
        probs = F.softmax(logits, dim=1)
        entropy = -(probs * torch.log(probs.clamp_min(eps))).sum(dim=1)
        norm = torch.log(torch.tensor(float(logits.size(1)), device=logits.device, dtype=logits.dtype)).clamp_min(eps)
        return entropy / norm

    def _compute_reliability(
        self,
        logits: torch.Tensor,
        prototype_distances: torch.Tensor,
        eps: float = 1e-8,
    ) -> Dict[str, torch.Tensor]:
        logit_margin = self._logit_margin(logits)
        predictive_entropy = self._normalized_entropy(logits, eps=eps)
        sorted_distances = torch.sort(prototype_distances, dim=1).values
        prototype_min_distance = sorted_distances[:, 0]
        if sorted_distances.size(1) >= 2:
            prototype_distance_margin = sorted_distances[:, 1] - sorted_distances[:, 0]
        else:
            prototype_distance_margin = torch.zeros_like(prototype_min_distance)

        margin_score = torch.sigmoid(logit_margin)
        entropy_score = 1.0 - predictive_entropy.clamp(0.0, 1.0)
        proto_score = torch.sigmoid(prototype_distance_margin - prototype_min_distance)
        reliability_score = (margin_score + entropy_score + proto_score) / 3.0
        return {
            "logit_margin": logit_margin,
            "predictive_entropy": predictive_entropy,
            "prototype_min_distance": prototype_min_distance,
            "prototype_distance_margin": prototype_distance_margin,
            "reliability_score": reliability_score,
        }

    def forward(
        self,
        x: torch.Tensor,
        x_raw: Optional[torch.Tensor] = None,
        speed_rpm: Optional[torch.Tensor] = None,
        class_condition: Optional[torch.Tensor] = None,
        grl_lambda_domain: float = 1.0,
        grl_lambda_domain_global: float = 1.0,
    ) -> Dict[str, torch.Tensor]:
        """
        输入:
            x: [B, C, T]
            class_condition:
                可选。
                - 若为 None，则使用当前模型 logits 的 softmax 作为条件信息
                - 若给定，可传类别 id 或 one-hot / soft label
        """
        feat_dict = self.feature_extractor(x)
        disentangled = self.disentangler(feat_dict["shared"])

        z_fault = disentangled["z_fault"]

        fc_logits = self.fc_classifier(z_fault)
        proto_logits = self.prototype_classifier(z_fault)

        # 时域分支：沿用原型 logits 与 FC logits 的融合方式。
        logits_time = self.proto_alpha * proto_logits + (1.0 - self.proto_alpha) * fc_logits

        freq_vec = None
        logits_freq = torch.zeros_like(logits_time)
        freq_diag: Dict[str, torch.Tensor] = {}
        alpha = self.logit_fusion.get_alpha().to(device=logits_time.device, dtype=logits_time.dtype)
        freq_input_source = "x"
        if self.use_freq_branch:
            if self.frequency_branch is None or self.freq_classifier is None:
                raise RuntimeError("use_freq_branch=True 但 frequency_branch/freq_classifier 未初始化")
            freq_in = x if x_raw is None else x_raw
            freq_input_source = "x" if x_raw is None else "x_raw"
            freq_diag = self.frequency_branch(freq_in, speed_rpm)
            freq_vec = freq_diag["freq_vec"]
            logits_freq = self.freq_classifier(freq_vec)
            logits, alpha = self.logit_fusion(logits_time, logits_freq)
        else:
            logits = logits_time

        prototype_distances = self.prototype_classifier.compute_distances(z_fault)
        reliability = self._compute_reliability(logits, prototype_distances)
        pred_time = torch.argmax(logits_time, dim=1)
        pred_freq = torch.argmax(logits_freq, dim=1)
        time_freq_prediction_agreement = (pred_time == pred_freq).to(logits.dtype) if self.use_freq_branch else torch.ones_like(pred_time, dtype=logits.dtype)

        # 条件域判别器的条件输入
        if class_condition is None:
            class_condition = F.softmax(logits.detach(), dim=1)

        domain_logits = self.domain_discriminator(
            z_fault=z_fault,
            class_condition=class_condition,
            grl_lambda=grl_lambda_domain,
        )

        global_domain_logits = self.global_domain_discriminator(
            z_fault=z_fault,
            grl_lambda=grl_lambda_domain_global,
        )

        return {
            "mscnn_map": feat_dict["mscnn_map"],
            "tcn_map": feat_dict["tcn_map"],
            "freq_vec": freq_vec,
            "shared": feat_dict["shared"],
            "z_fault": z_fault,
            "fc_logits": fc_logits,
            "proto_logits": proto_logits,
            "logits_time": logits_time,
            "logits_freq": logits_freq,
            "logits": logits,
            "final_logits": logits,
            "domain_logits": domain_logits,
            "global_domain_logits": global_domain_logits,
            "freq_order_features": freq_diag.get("freq_order_features"),
            "freq_order_k": freq_diag.get("freq_order_k"),
            "freq_order_centers_hz": freq_diag.get("freq_order_centers_hz"),
            "freq_gate": freq_diag.get("freq_gate"),
            "electrical_frequency_hz": freq_diag.get("electrical_frequency_hz"),
            "freq_input_source": freq_input_source,
            "alpha": alpha,
            "fusion_alpha": alpha,
            "alpha_prior": self.logit_fusion.alpha_prior.to(device=logits.device, dtype=logits.dtype),
            "time_freq_prediction_agreement": time_freq_prediction_agreement,
            **reliability,
        }

    @torch.no_grad()
    def compute_prototype_distances(
        self,
        x: torch.Tensor,
        x_raw: Optional[torch.Tensor] = None,
        speed_rpm: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        计算输入样本到 5 类原型的距离
        用于 test.py 中做原型分析
        """
        outputs = self.forward(x=x, x_raw=x_raw, speed_rpm=speed_rpm)
        z_fault = outputs["z_fault"]
        distances = self.prototype_classifier.compute_distances(z_fault)
        return distances

    def freeze_low_level(self, freeze_cnn: bool = True, freeze_tcn_blocks: int = 1) -> None:
        """
        Stage3 用于冻结底层特征提取层
        """
        self.feature_extractor.freeze_low_level(
            freeze_cnn=freeze_cnn,
            freeze_tcn_blocks=freeze_tcn_blocks,
        )

    def unfreeze_all(self) -> None:
        """解冻全部参数"""
        for p in self.parameters():
            p.requires_grad = True


if __name__ == "__main__":
    """
    本地快速自检：
    python models.py
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"

    model = FullModel(
        in_channels=13,
        num_classes=5,
        num_domains=2,
        shared_dim=256,
        feature_dim=128,
        mscnn_branch_channels=64,
        mscnn_kernel_sizes=(3, 5, 7),
        tcn_hidden_channels=(64, 128),
        tcn_kernel_size=3,
        tcn_dropout=0.1,
        use_freq_branch=False,
        proto_metric="cosine",
        proto_temperature=0.1,
        proto_alpha=0.6,
    ).to(device)

    x = torch.randn(8, 13, 2000).to(device)
    y = torch.randint(0, 5, (8,)).to(device)
    speed = torch.tensor([500, 600, 700, 800, 900, 1000, 750, 650], dtype=torch.float32).to(device)

    outputs = model(x, speed_rpm=speed, class_condition=y)

    print("==== FullModel 自检 ====")
    for k, v in outputs.items():
        if v is None:
            print(f"{k}: None")
        else:
            print(f"{k}: {tuple(v.shape)}")
