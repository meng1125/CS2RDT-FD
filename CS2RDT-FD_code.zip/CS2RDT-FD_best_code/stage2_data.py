"""Training and validation views for the selected Stage 2 protocol."""

from collections import Counter, defaultdict
from dataclasses import replace

import numpy as np

from dataset import ChannelWiseScaler, IndexedWindowFaultDataset
from utils import build_augmentor_for_stage, build_balanced_condition_dataloader, build_dataloader


REAL_OBSERVED = ("health", "OPF", "Sensor")


def fit_training_window_scaler(config, records, train_indices):
    """Fit the original per-channel z-score on unique raw training points."""
    data = config["data"]
    scaler = ChannelWiseScaler(eps=float(data["scaler_eps"]))
    if not data["standardize"]:
        return scaler
    window_size = int(data["window_size"])
    stride = int(data["stride"])
    known_real = set(data["known_real_classes"])
    by_record = defaultdict(list)
    for record_idx, window_idx in train_indices:
        record = records[record_idx]
        if record.domain_name == "real" and (
            record.label_name not in known_real or not record.trainable_in_real
        ):
            raise ValueError(f"Real class outside the scaler fit policy: {record.label_name}")
        start = int(window_idx) * stride
        end = start + window_size
        if start < 0 or end > len(record.feature_matrix):
            raise ValueError(f"Scaler window outside record bounds: {(record_idx, window_idx)}")
        by_record[record_idx].append((start, end))

    # Clip the record views to merged train intervals, then reuse the original estimator.
    fragments = []
    for record_idx, spans in by_record.items():
        merged = []
        for start, end in sorted(spans):
            if merged and start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        record = records[record_idx]
        fragments.extend(
            replace(record, feature_matrix=record.feature_matrix[start:end])
            for start, end in merged
        )
    scaler.fit(fragments)
    if not np.isfinite(scaler.mean).all() or not np.isfinite(scaler.std).all():
        raise FloatingPointError("Stage 2 scaler contains nonfinite channel statistics")
    return scaler


def _dataset(config, records, indices, scaler, *, augmentor=None, is_train=False):
    local_records = []
    remap = {}
    local_indices = []
    for record_idx, window_idx in indices:
        if record_idx not in remap:
            record = records[record_idx]
            remap[record_idx] = len(local_records)
            local_records.append(record)
        local_indices.append((remap[record_idx], window_idx))
    data = config["data"]
    return IndexedWindowFaultDataset(
        file_records=local_records,
        window_indices=local_indices,
        window_size=data["window_size"],
        stride=data["stride"],
        scaler=scaler,
        standardize=data["standardize"],
        augmentor=augmentor,
        is_train=is_train,
        stage_name="stage2",
    )


def _ordered_loader(config, dataset):
    data = config["data"]
    return build_dataloader(
        dataset=dataset,
        batch_size=data.get("validation_batch_size", data["batch_size"]),
        num_workers=data["num_workers"],
        pin_memory=data["pin_memory"],
        shuffle=False,
        drop_last=False,
    )


def _summarize_windows(records, indices):
    return dict(sorted(Counter(
        f"{records[record_idx].domain_name}::{records[record_idx].label_name}"
        for record_idx, _ in indices
    ).items()))


def _active_windows(config, split_records):
    if split_records["split_unit"] != "window":
        raise ValueError("The Stage 2 development protocol requires the existing window split")
    records = split_records["all_records"]
    active = set(config["data"]["known_real_classes"])

    def allowed(record):
        return record.domain_name == "sim" or (
            record.domain_name == "real" and record.label_name in active and record.trainable_in_real
        )

    return {
        part: [pair for pair in split_records[part] if allowed(records[pair[0]])]
        for part in ("train", "val")
    }


def _fit_views(config, records, indices, logger):
    data = config["data"]
    if not indices["train"] or not indices["val"]:
        raise ValueError("The frozen split lacks an active train or validation set")
    scaler = fit_training_window_scaler(config, records, indices["train"])
    train_set = _dataset(
        config, records, indices["train"], scaler,
        augmentor=build_augmentor_for_stage(config, "stage2", logger), is_train=True,
    )
    val_set = _dataset(config, records, indices["val"], scaler)
    train_loader = build_balanced_condition_dataloader(
        dataset=train_set,
        batch_size=data["batch_size"],
        num_workers=data["num_workers"],
        pin_memory=data["pin_memory"],
        drop_last=data["drop_last"],
        sampler_cfg=data["balanced_condition_sampler"],
        seed=config["random_seed"],
        logger=logger,
    )
    audit = {
        "observed_real_labels": data["known_real_classes"],
        "train_windows": _summarize_windows(records, indices["train"]),
        "active_val_windows": _summarize_windows(records, indices["val"]),
        "scaler_fit_unit": "unique raw points covered by allowed training windows",
        "stage2_train_batch_size": data["batch_size"],
        "stage2_train_steps_per_epoch": len(train_loader),
        "val_batch_size": data.get("validation_batch_size", data["batch_size"]),
    }
    return {
        "config": config,
        "train_loader": train_loader,
        "val_loader": _ordered_loader(config, val_set),
        "scaler": scaler,
        "audit": audit,
    }


def build_formal(config, split_records, logger):
    """Build the three-observed-class Stage 2 fit views from the frozen split."""
    if set(config["data"]["known_real_classes"]) != set(REAL_OBSERVED):
        raise ValueError("Formal Stage 2 requires the three observed real classes")
    records = split_records["all_records"]
    indices = _active_windows(config, split_records)
    return _fit_views(config, records, indices, logger)
