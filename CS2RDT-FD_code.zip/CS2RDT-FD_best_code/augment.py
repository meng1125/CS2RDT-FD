# augment.py
# -*- coding: utf-8 -*-

"""
双三相永磁同步电机故障诊断时序数据增强模块。

设计原则：
1. 只在 Dataset 的 train split 中调用；val/test 不调用。
2. sim 域是主要增强对象；real 域只做弱增强。
3. real 域未知类（例如 ITSC / tuici）即使误传进来，也会被运行时保护跳过。
4. 不假设完整三相 abc；默认使用两相 current pair 分组。
"""

import copy
import math
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import torch
import torch.nn.functional as F


TensorLikeLabel = Union[int, str, torch.Tensor]
TensorLikeDomain = Union[int, str, torch.Tensor]
TensorLikeStage = Union[int, str]


DEFAULT_CLASS_NAMES = ["health", "OPF", "ITSC", "Sensor", "tuici"]
DEFAULT_CHANNEL_NAMES = [
    "v",
    "id",
    "iq",
    "ix",
    "iy",
    "ia",
    "ib",
    "id2",
    "ie",
    "ud",
    "uq",
    "ux",
    "uy",
]


DEFAULT_AUGMENTATION_CONFIG: Dict[str, Any] = {
    "enabled": False,
    "fs": 10000,
    "window_size": 2000,
    "pole_pairs": 5,
    "use_basic_aug": True,
    "use_sim2real_aug": True,
    "use_class_specific_aug": True,
    "unknown_real_classes": ["ITSC", "tuici"],
    "channel_mapping": {
        "current_pair_1": ["ia", "ib"],
        "current_pair_2": ["id2", "ie"],
        "dq_channels": ["id", "iq", "ix", "iy"],
        "freq_channels": ["ia", "id2"],
        "voltages": ["ud", "uq", "ux", "uy"],
    },
    "stage_policy": {
        "stage1": {
            "sim": {
                "weak_aug_prob": 0.7,
                "strong_aug_prob": 0.5,
                "sim2real_aug_prob": 0.3,
                "class_specific_aug_prob": 0.7,
            },
            "real": {
                "weak_aug_prob": 0.0,
                "strong_aug_prob": 0.0,
                "sim2real_aug_prob": 0.0,
                "class_specific_aug_prob": 0.0,
            },
        },
        "stage2": {
            "sim": {
                "weak_aug_prob": 0.5,
                "strong_aug_prob": 0.8,
                "sim2real_aug_prob": 0.7,
                "class_specific_aug_prob": 0.8,
            },
            "real": {
                "weak_aug_prob": 0.4,
                "strong_aug_prob": 0.0,
                "sim2real_aug_prob": 0.0,
                "class_specific_aug_prob": 0.0,
            },
        },
        "stage3": {
            "sim": {
                "weak_aug_prob": 0.3,
                "strong_aug_prob": 0.15,
                "sim2real_aug_prob": 0.2,
                "class_specific_aug_prob": 0.4,
            },
            "real": {
                "weak_aug_prob": 0.25,
                "strong_aug_prob": 0.0,
                "sim2real_aug_prob": 0.0,
                "class_specific_aug_prob": 0.0,
            },
        },
    },
    "weak": {
        "max_shift": 50,
        "snr_range": [30.0, 40.0],
        "scale_range": [0.95, 1.05],
        "channel_gain_range": [0.95, 1.05],
        "channel_bias_ratio": [0.01, 0.03],
        "mask_len_range": [20, 80],
        "rpm_jitter_range": [0.98, 1.02],
        "time_mask_prob": 0.20,
        "filter_prob": 0.25,
    },
    "strong": {
        "max_shift": 150,
        "snr_range": [18.0, 30.0],
        "scale_range": [0.85, 1.15],
        "channel_gain_range": [0.85, 1.15],
        "channel_bias_ratio": [0.03, 0.08],
        "mask_len_range": [80, 250],
        "rpm_jitter_range": [0.95, 1.05],
        "time_mask_prob": 0.35,
        "filter_prob": 0.35,
    },
    "sim2real": {
        "filter_prob": 0.5,
        "quantization_prob": 0.35,
        "low_freq_drift_prob": 0.35,
        "channel_gain_prob": 0.35,
        "channel_bias_prob": 0.25,
        "quantization_levels": 512,
        "drift_ratio": [0.01, 0.04],
        "channel_gain_range": [0.90, 1.10],
        "channel_bias_ratio": [0.01, 0.05],
    },
    "class_specific": {
        "health": {"prob_multiplier": 0.4},
        "OPF": {
            "prob_multiplier": 1.0,
            "phase_imbalance_range": [0.85, 1.15],
            "normal_phase_scale_range": [0.90, 1.10],
            "harmonic_amp_range": [0.80, 1.20],
        },
        "Sensor": {
            "prob_multiplier": 1.0,
            "sensor_bias_ratio": [0.05, 0.30],
            "sensor_gain_range": [0.80, 1.20],
            "drift_ratio": [0.05, 0.20],
            "spike_ratio": [3.0, 6.0],
            "delay_points": [5, 30],
            "spike_prob": 0.15,
            "saturation_prob": 0.10,
            "delay_prob": 0.20,
        },
        "ITSC": {
            "prob_multiplier": 1.25,
            "phase_imbalance_range": [0.85, 1.15],
            "harmonic_amp_range": [0.70, 1.30],
            "harmonic_center_jitter": [0.03, 0.05],
            "rpm_jitter_range": [0.95, 1.05],
            "snr_range": [20.0, 35.0],
        },
        "tuici": {
            "prob_multiplier": 1.25,
            "global_scale_range": [0.85, 1.15],
            "current_pair_scale_range": [0.90, 1.10],
            "harmonic_amp_range": [0.75, 1.25],
            "low_freq_drift_ratio": [0.01, 0.05],
            "rpm_jitter_range": [0.95, 1.05],
        },
    },
}


def _recursive_update(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _recursive_update(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _as_range(value: Union[float, int, Sequence[float]], default: Tuple[float, float]) -> Tuple[float, float]:
    if value is None:
        return default
    if isinstance(value, (int, float)):
        v = float(value)
        return v, v
    if len(value) == 0:
        return default
    if len(value) == 1:
        v = float(value[0])
        return v, v
    lo, hi = float(value[0]), float(value[1])
    return (lo, hi) if lo <= hi else (hi, lo)


def _rand_uniform(range_value: Union[float, int, Sequence[float]], device: torch.device, default: Tuple[float, float]) -> torch.Tensor:
    lo, hi = _as_range(range_value, default)
    if abs(hi - lo) < 1e-12:
        return torch.tensor(lo, device=device, dtype=torch.float32)
    return torch.empty((), device=device, dtype=torch.float32).uniform_(lo, hi)


def _rand_int(inclusive_range: Sequence[int], device: torch.device, default: Tuple[int, int]) -> int:
    if inclusive_range is None or len(inclusive_range) < 2:
        lo, hi = default
    else:
        lo, hi = int(inclusive_range[0]), int(inclusive_range[1])
    if hi < lo:
        lo, hi = hi, lo
    if hi <= lo:
        return int(lo)
    return int(torch.randint(lo, hi + 1, (1,), device=device).item())


def _channel_std(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    return x.std(dim=-1, keepdim=True).clamp_min(eps)


def _safe_clone(x: torch.Tensor) -> torch.Tensor:
    if not torch.is_floating_point(x):
        x = x.float()
    return x.clone()


def random_shift(x: torch.Tensor, max_shift: int) -> torch.Tensor:
    """对所有通道同步时间平移，保持物理同步性。"""
    x = _safe_clone(x)
    max_shift = int(max_shift)
    if max_shift <= 0 or x.size(-1) <= 1:
        return x
    shift = int(torch.randint(-max_shift, max_shift + 1, (1,), device=x.device).item())
    if shift == 0:
        return x
    return torch.roll(x, shifts=shift, dims=-1)


def add_gaussian_noise(x: torch.Tensor, snr_range: Sequence[float]) -> torch.Tensor:
    """按指定 SNR(dB) 加高斯噪声。"""
    x = _safe_clone(x)
    snr_db = _rand_uniform(snr_range, x.device, (30.0, 40.0)).to(dtype=x.dtype)
    signal_power = x.pow(2).mean(dim=-1, keepdim=True).clamp_min(1e-12)
    noise_power = signal_power / torch.pow(torch.tensor(10.0, device=x.device, dtype=x.dtype), snr_db.to(dtype=x.dtype) / 10.0)
    noise = torch.randn_like(x) * torch.sqrt(noise_power)
    return x + noise


def random_scaling(x: torch.Tensor, scale_range: Sequence[float]) -> torch.Tensor:
    """所有通道同步整体幅值缩放。"""
    x = _safe_clone(x)
    scale = _rand_uniform(scale_range, x.device, (0.95, 1.05)).to(dtype=x.dtype)
    return x * scale


def channel_gain(x: torch.Tensor, gain_range: Sequence[float], channels: Optional[Sequence[int]] = None) -> torch.Tensor:
    """逐通道增益扰动；可限制在指定通道。"""
    x = _safe_clone(x)
    target_channels = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not target_channels:
        return x
    lo, hi = _as_range(gain_range, (0.95, 1.05))
    gains = torch.empty((len(target_channels), 1), device=x.device, dtype=x.dtype).uniform_(lo, hi)
    x[target_channels, :] = x[target_channels, :] * gains
    return x


def channel_bias(x: torch.Tensor, bias_ratio: Union[float, Sequence[float]], channels: Optional[Sequence[int]] = None) -> torch.Tensor:
    """逐通道偏置扰动，偏置幅值按各通道 std 的比例采样。"""
    x = _safe_clone(x)
    target_channels = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not target_channels:
        return x
    lo, hi = _as_range(bias_ratio, (0.01, 0.03))
    std = _channel_std(x[target_channels, :]).to(dtype=x.dtype)
    ratios = torch.empty((len(target_channels), 1), device=x.device, dtype=x.dtype).uniform_(lo, hi)
    signs = torch.where(torch.rand((len(target_channels), 1), device=x.device) < 0.5, -1.0, 1.0).to(dtype=x.dtype)
    x[target_channels, :] = x[target_channels, :] + signs * ratios * std
    return x


def time_mask(x: torch.Tensor, mask_len_range: Sequence[int]) -> torch.Tensor:
    """对所有通道同步遮挡同一时间段，用通道均值填充，避免引入强单通道异常。"""
    x = _safe_clone(x)
    t = x.size(-1)
    if t <= 1:
        return x
    mask_len = min(_rand_int(mask_len_range, x.device, (20, 80)), t)
    if mask_len <= 0:
        return x
    start = int(torch.randint(0, max(t - mask_len + 1, 1), (1,), device=x.device).item())
    fill = x.mean(dim=-1, keepdim=True)
    x[:, start:start + mask_len] = fill
    return x


def low_freq_drift(x: torch.Tensor, drift_ratio: Union[float, Sequence[float]]) -> torch.Tensor:
    """添加低频缓慢漂移，幅值按通道 std 比例控制。"""
    x = _safe_clone(x)
    t = x.size(-1)
    if t <= 1:
        return x
    ratio = _rand_uniform(drift_ratio, x.device, (0.01, 0.05)).to(dtype=x.dtype)
    time = torch.linspace(0.0, 1.0, t, device=x.device, dtype=x.dtype).view(1, -1)
    phase = _rand_uniform((0.0, 2.0 * math.pi), x.device, (0.0, 2.0 * math.pi)).to(dtype=x.dtype)
    freq = _rand_uniform((0.5, 2.0), x.device, (0.5, 2.0)).to(dtype=x.dtype)
    wave = torch.sin(2.0 * math.pi * freq * time + phase)
    linear = 2.0 * (time - 0.5)
    mix = _rand_uniform((0.3, 0.7), x.device, (0.3, 0.7)).to(dtype=x.dtype)
    drift_shape = mix * wave + (1.0 - mix) * linear
    std = _channel_std(x).to(dtype=x.dtype)
    signs = torch.where(torch.rand((x.size(0), 1), device=x.device) < 0.5, -1.0, 1.0).to(dtype=x.dtype)
    return x + signs * ratio * std * drift_shape


def random_filter(x: torch.Tensor, fs: float = 10000.0) -> torch.Tensor:
    """轻量随机滤波：同步选择低通平滑或轻微高频增强，不依赖 scipy。"""
    del fs  # 当前实现不需要 fs，保留接口便于后续替换为物理带宽滤波。
    x = _safe_clone(x)
    if x.size(-1) < 3:
        return x
    c = x.size(0)
    kernel = torch.tensor([0.25, 0.50, 0.25], device=x.device, dtype=x.dtype).view(1, 1, 3).repeat(c, 1, 1)
    padded = F.pad(x.unsqueeze(0), (1, 1), mode="reflect")
    smooth = F.conv1d(padded, kernel, groups=c).squeeze(0)
    if torch.rand((), device=x.device).item() < 0.7:
        alpha = _rand_uniform((0.25, 0.75), x.device, (0.25, 0.75)).to(dtype=x.dtype)
        return alpha * smooth + (1.0 - alpha) * x
    high = x - smooth
    beta = _rand_uniform((0.05, 0.20), x.device, (0.05, 0.20)).to(dtype=x.dtype)
    return x + beta * high


def quantization_noise(x: torch.Tensor, num_levels: int = 512) -> torch.Tensor:
    """模拟 ADC 量化误差。"""
    x = _safe_clone(x)
    num_levels = int(num_levels)
    if num_levels <= 1:
        return x
    xmin = x.amin(dim=-1, keepdim=True)
    xmax = x.amax(dim=-1, keepdim=True)
    span = (xmax - xmin).clamp_min(1e-8)
    step = span / float(num_levels - 1)
    return torch.round((x - xmin) / step) * step + xmin


def sensor_bias_aug(x: torch.Tensor, channels: Optional[Sequence[int]] = None, bias_ratio: Sequence[float] = (0.05, 0.30)) -> torch.Tensor:
    """Sensor 类：单通道偏置故障增强。"""
    x = _safe_clone(x)
    candidates = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not candidates:
        return x
    ch = candidates[int(torch.randint(0, len(candidates), (1,), device=x.device).item())]
    return channel_bias(x, bias_ratio=bias_ratio, channels=[ch])


def sensor_drift_aug(x: torch.Tensor, channels: Optional[Sequence[int]] = None, drift_ratio: Sequence[float] = (0.05, 0.20)) -> torch.Tensor:
    """Sensor 类：单通道漂移增强。"""
    x = _safe_clone(x)
    candidates = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not candidates:
        return x
    ch = candidates[int(torch.randint(0, len(candidates), (1,), device=x.device).item())]
    x_ch = low_freq_drift(x[ch:ch + 1, :], drift_ratio=drift_ratio)
    x[ch:ch + 1, :] = x_ch
    return x


def sensor_gain_aug(x: torch.Tensor, channels: Optional[Sequence[int]] = None, gain_range: Sequence[float] = (0.80, 1.20)) -> torch.Tensor:
    """Sensor 类：单通道增益误差增强。"""
    x = _safe_clone(x)
    candidates = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not candidates:
        return x
    ch = candidates[int(torch.randint(0, len(candidates), (1,), device=x.device).item())]
    return channel_gain(x, gain_range=gain_range, channels=[ch])


def sensor_spike_aug(
    x: torch.Tensor,
    channels: Optional[Sequence[int]] = None,
    spike_ratio: Sequence[float] = (3.0, 6.0),
    max_spikes: int = 5,
) -> torch.Tensor:
    """Sensor 类：少量尖峰噪声增强。"""
    x = _safe_clone(x)
    candidates = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not candidates or x.size(-1) <= 0:
        return x
    ch = candidates[int(torch.randint(0, len(candidates), (1,), device=x.device).item())]
    n_spikes = int(torch.randint(1, max(int(max_spikes), 1) + 1, (1,), device=x.device).item())
    idx = torch.randint(0, x.size(-1), (n_spikes,), device=x.device)
    ratio = _rand_uniform(spike_ratio, x.device, (3.0, 6.0)).to(dtype=x.dtype)
    std = x[ch].std().clamp_min(1e-6)
    signs = torch.where(torch.rand((n_spikes,), device=x.device) < 0.5, -1.0, 1.0).to(dtype=x.dtype)
    x[ch, idx] = x[ch, idx] + signs * ratio * std
    return x


def sensor_delay_aug(x: torch.Tensor, channels: Optional[Sequence[int]] = None, delay_points: Sequence[int] = (5, 30)) -> torch.Tensor:
    """Sensor 类：单通道小延迟增强。"""
    x = _safe_clone(x)
    candidates = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not candidates or x.size(-1) <= 1:
        return x
    ch = candidates[int(torch.randint(0, len(candidates), (1,), device=x.device).item())]
    delay = _rand_int(delay_points, x.device, (5, 30))
    if delay <= 0:
        return x
    delayed = torch.roll(x[ch], shifts=delay, dims=-1)
    delayed[:delay] = x[ch, 0]
    x[ch, :] = delayed
    return x


def light_saturation_aug(x: torch.Tensor, channels: Optional[Sequence[int]] = None, ratio_range: Sequence[float] = (2.0, 3.0)) -> torch.Tensor:
    """Sensor 类：轻微限幅，避免大量 flat-line。"""
    x = _safe_clone(x)
    candidates = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not candidates:
        return x
    ch = candidates[int(torch.randint(0, len(candidates), (1,), device=x.device).item())]
    mean = x[ch].mean()
    std = x[ch].std().clamp_min(1e-6)
    ratio = _rand_uniform(ratio_range, x.device, (2.0, 3.0)).to(dtype=x.dtype)
    lo = mean - ratio * std
    hi = mean + ratio * std
    x[ch, :] = torch.clamp(x[ch, :], lo, hi)
    return x


def phase_imbalance_aug(
    x: torch.Tensor,
    current_pairs: Optional[Sequence[Sequence[int]]] = None,
    phase_imbalance_range: Sequence[float] = (0.85, 1.15),
    normal_phase_scale_range: Sequence[float] = (0.90, 1.10),
) -> torch.Tensor:
    """两相 current pair 幅值不平衡增强；不假设 ic 或完整三相 abc。"""
    x = _safe_clone(x)
    if not current_pairs:
        return x
    for pair in current_pairs:
        pair = [int(c) for c in pair if 0 <= int(c) < x.size(0)]
        if len(pair) < 2:
            continue
        base = _rand_uniform(normal_phase_scale_range, x.device, (0.90, 1.10)).to(dtype=x.dtype)
        imbalance = _rand_uniform(phase_imbalance_range, x.device, (0.85, 1.15)).to(dtype=x.dtype)
        if torch.rand((), device=x.device).item() < 0.5:
            gains = [base * imbalance, base / imbalance.clamp_min(1e-6)]
        else:
            gains = [base / imbalance.clamp_min(1e-6), base * imbalance]
        for ch, gain in zip(pair[:2], gains):
            x[ch, :] = x[ch, :] * gain
    return x


def global_amplitude_aug(
    x: torch.Tensor,
    global_scale_range: Sequence[float] = (0.85, 1.15),
    current_pairs: Optional[Sequence[Sequence[int]]] = None,
    current_pair_scale_range: Sequence[float] = (0.90, 1.10),
) -> torch.Tensor:
    """tuici 类：整体幅值扰动 + current pair 组内一致缩放。"""
    x = random_scaling(x, global_scale_range)
    if not current_pairs:
        return x
    for pair in current_pairs:
        pair = [int(c) for c in pair if 0 <= int(c) < x.size(0)]
        if not pair:
            continue
        scale = _rand_uniform(current_pair_scale_range, x.device, (0.90, 1.10)).to(dtype=x.dtype)
        x[pair, :] = x[pair, :] * scale
    return x


def harmonic_amp_jitter(
    x: torch.Tensor,
    fs: float,
    rpm: Optional[float],
    channels: Optional[Sequence[int]] = None,
    pole_pairs: int = 5,
    harmonic_amp_range: Sequence[float] = (0.75, 1.25),
    num_harmonics: int = 5,
    half_width_hz: float = 8.0,
) -> torch.Tensor:
    """对电频率谐波附近频带做幅值扰动。rpm 缺失时退化为恒等映射。"""
    x = _safe_clone(x)
    if rpm is None or not math.isfinite(float(rpm)) or float(rpm) <= 0 or x.size(-1) < 4:
        return x
    target_channels = list(range(x.size(0))) if channels is None else [int(c) for c in channels if 0 <= int(c) < x.size(0)]
    if not target_channels:
        return x

    t = x.size(-1)
    freq = torch.fft.rfftfreq(t, d=1.0 / float(fs)).to(device=x.device, dtype=x.dtype)
    spec = torch.fft.rfft(x[target_channels, :], dim=-1)
    fe = float(rpm) * float(pole_pairs) / 60.0
    for k in range(1, int(num_harmonics) + 1):
        center = fe * k
        if center <= 0 or center >= float(fs) / 2.0:
            continue
        mask = (freq >= center - half_width_hz) & (freq <= center + half_width_hz)
        if mask.sum().item() <= 0:
            continue
        amp = _rand_uniform(harmonic_amp_range, x.device, (0.75, 1.25)).to(dtype=x.dtype)
        spec[:, mask] = spec[:, mask] * amp
    x[target_channels, :] = torch.fft.irfft(spec, n=t, dim=-1).to(dtype=x.dtype)
    return x


def harmonic_center_jitter(
    x: torch.Tensor,
    fs: float,
    rpm: Optional[float],
    channels: Optional[Sequence[int]] = None,
    pole_pairs: int = 5,
    center_jitter: Sequence[float] = (0.03, 0.05),
) -> torch.Tensor:
    """近似电频率中心扰动：用 jitter 后的 rpm 对谐波带做轻微幅值扰动。"""
    if rpm is None or not math.isfinite(float(rpm)) or float(rpm) <= 0:
        return _safe_clone(x)
    lo, hi = _as_range(center_jitter, (0.03, 0.05))
    jitter_abs = float(_rand_uniform((lo, hi), x.device, (0.03, 0.05)).item())
    sign = -1.0 if torch.rand((), device=x.device).item() < 0.5 else 1.0
    jittered_rpm = float(rpm) * (1.0 + sign * jitter_abs)
    return harmonic_amp_jitter(
        x=x,
        fs=fs,
        rpm=jittered_rpm,
        channels=channels,
        pole_pairs=pole_pairs,
        harmonic_amp_range=(0.90, 1.10),
        half_width_hz=max(4.0, float(rpm) * float(pole_pairs) / 60.0 * jitter_abs),
    )


def rpm_jitter(x: torch.Tensor, jitter_range: Sequence[float]) -> torch.Tensor:
    """通过轻微重采样近似转速扰动，输出长度保持不变。"""
    x = _safe_clone(x)
    t = x.size(-1)
    if t <= 4:
        return x
    factor = float(_rand_uniform(jitter_range, x.device, (0.98, 1.02)).item())
    if abs(factor - 1.0) < 1e-4:
        return x
    new_t = max(4, int(round(t / factor)))
    y = F.interpolate(x.unsqueeze(0), size=new_t, mode="linear", align_corners=False).squeeze(0)
    if new_t > t:
        start = (new_t - t) // 2
        y = y[:, start:start + t]
    elif new_t < t:
        pad_left = (t - new_t) // 2
        pad_right = t - new_t - pad_left
        left = y[:, :1].expand(-1, pad_left) if pad_left > 0 else y[:, :0]
        right = y[:, -1:].expand(-1, pad_right) if pad_right > 0 else y[:, :0]
        y = torch.cat([left, y, right], dim=-1)
    return y


class TimeSeriesAugment:
    """训练集单窗口数据增强器。

    对外常用接口：
        x_aug = augment(x, label=label, domain=domain, stage=stage, rpm=rpm)

    Dataset 内部使用 augment_with_meta 以便记录增强调用统计。
    """

    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        channel_names: Optional[Sequence[str]] = None,
        class_names: Optional[Sequence[str]] = None,
    ):
        root_cfg = config or {}
        aug_override = root_cfg.get("augmentation", root_cfg)
        self.cfg = _recursive_update(DEFAULT_AUGMENTATION_CONFIG, aug_override or {})
        self.channel_names = list(channel_names or root_cfg.get("data", {}).get("feature_channels", DEFAULT_CHANNEL_NAMES) or DEFAULT_CHANNEL_NAMES)
        self.class_names = list(class_names or root_cfg.get("data", {}).get("class_names", DEFAULT_CLASS_NAMES) or DEFAULT_CLASS_NAMES)
        self.class_to_idx = {name: idx for idx, name in enumerate(self.class_names)}
        self.idx_to_class = {idx: name for idx, name in enumerate(self.class_names)}
        data_unknown = root_cfg.get("data", {}).get("unknown_real_classes", self.cfg.get("unknown_real_classes", ["ITSC", "tuici"]))
        self.unknown_real_classes = {str(name) for name in data_unknown}
        self.unknown_real_indices = {self.class_to_idx[name] for name in self.unknown_real_classes if name in self.class_to_idx}
        self.channel_mapping = self._build_channel_mapping(self.cfg.get("channel_mapping", {}))
        self.current_pairs = [
            self.channel_mapping.get("current_pair_1", []),
            self.channel_mapping.get("current_pair_2", []),
        ]
        self.current_pairs = [pair for pair in self.current_pairs if len(pair) >= 2]
        self.freq_channels = self.channel_mapping.get("freq_channels", [])
        self.counters: Dict[str, Any] = {}

    @property
    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled", False))

    def __call__(
        self,
        x: torch.Tensor,
        label: TensorLikeLabel,
        domain: TensorLikeDomain,
        stage: TensorLikeStage,
        rpm: Optional[Union[float, torch.Tensor]] = None,
    ) -> torch.Tensor:
        return self.augment(x=x, label=label, domain=domain, stage=stage, rpm=rpm)

    def augment(
        self,
        x: torch.Tensor,
        label: TensorLikeLabel,
        domain: TensorLikeDomain,
        stage: TensorLikeStage,
        rpm: Optional[Union[float, torch.Tensor]] = None,
    ) -> torch.Tensor:
        x_aug, _ = self.augment_with_meta(x=x, label=label, domain=domain, stage=stage, rpm=rpm)
        return x_aug

    def augment_with_meta(
        self,
        x: torch.Tensor,
        label: TensorLikeLabel,
        domain: TensorLikeDomain,
        stage: TensorLikeStage,
        rpm: Optional[Union[float, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        x_aug = _safe_clone(x)
        label_idx, class_name = self._normalize_label(label)
        domain_name = self._normalize_domain(domain)
        stage_name = self._normalize_stage(stage)
        rpm_value = self._normalize_rpm(rpm)
        meta = {
            "enabled": self.enabled,
            "stage": stage_name,
            "domain": domain_name,
            "class": class_name,
            "applied": [],
            "skipped_reason": None,
        }

        self._count(stage_name, domain_name, class_name, "samples")

        if not self.enabled:
            meta["skipped_reason"] = "augmentation_disabled"
            self._count(stage_name, domain_name, class_name, "skipped_disabled")
            return x_aug, meta

        if domain_name == "real" and (label_idx in self.unknown_real_indices or class_name in self.unknown_real_classes):
            meta["skipped_reason"] = "real_unknown_class"
            self._count(stage_name, domain_name, class_name, "skipped_real_unknown")
            return x_aug, meta

        policy = self._get_stage_policy(stage_name, domain_name)
        if not policy:
            meta["skipped_reason"] = "no_stage_policy"
            self._count(stage_name, domain_name, class_name, "skipped_no_policy")
            return x_aug, meta

        if domain_name == "real":
            # real 训练数据只做弱增强，不做强增强、sim2real 或类别定向增强。
            if self._bernoulli(policy.get("weak_aug_prob", 0.0)) and bool(self.cfg.get("use_basic_aug", True)):
                x_aug = self._apply_weak(x_aug, meta)
            return x_aug, meta

        # sim 域：基础弱/强 + sim2real + 类别定向。health 不做强类别异常。
        if bool(self.cfg.get("use_basic_aug", True)):
            if self._bernoulli(policy.get("weak_aug_prob", 0.0)):
                x_aug = self._apply_weak(x_aug, meta)
            if class_name != "health" and self._bernoulli(policy.get("strong_aug_prob", 0.0)):
                x_aug = self._apply_strong(x_aug, meta)

        if bool(self.cfg.get("use_sim2real_aug", True)) and self._bernoulli(policy.get("sim2real_aug_prob", 0.0)):
            x_aug = self._apply_sim2real(x_aug, meta)

        if bool(self.cfg.get("use_class_specific_aug", True)):
            class_cfg = self.cfg.get("class_specific", {}).get(class_name, {})
            class_prob = float(policy.get("class_specific_aug_prob", 0.0)) * float(class_cfg.get("prob_multiplier", 1.0))
            if self._bernoulli(min(class_prob, 1.0)):
                x_aug = self._apply_class_specific(x_aug, class_name, class_cfg, rpm_value, meta)

        if not meta["applied"]:
            self._count(stage_name, domain_name, class_name, "identity")
        return x_aug, meta

    def get_counters(self) -> Dict[str, Any]:
        return copy.deepcopy(self.counters)

    def describe_stage(self, stage: TensorLikeStage) -> Dict[str, Any]:
        stage_name = self._normalize_stage(stage)
        return {
            "enabled": self.enabled,
            "stage": stage_name,
            "use_basic_aug": bool(self.cfg.get("use_basic_aug", True)),
            "use_sim2real_aug": bool(self.cfg.get("use_sim2real_aug", True)),
            "use_class_specific_aug": bool(self.cfg.get("use_class_specific_aug", True)),
            "stage_policy": copy.deepcopy(self.cfg.get("stage_policy", {}).get(stage_name, {})),
            "channel_mapping": copy.deepcopy(self.cfg.get("channel_mapping", {})),
            "unknown_real_classes": sorted(self.unknown_real_classes),
        }

    def _build_channel_mapping(self, mapping: Dict[str, Sequence[Union[int, str]]]) -> Dict[str, List[int]]:
        name_to_idx = {name: idx for idx, name in enumerate(self.channel_names)}
        resolved: Dict[str, List[int]] = {}
        for group_name, channels in (mapping or {}).items():
            idxs: List[int] = []
            for ch in channels or []:
                if isinstance(ch, int):
                    idx = int(ch)
                else:
                    if str(ch) not in name_to_idx:
                        continue
                    idx = name_to_idx[str(ch)]
                if 0 <= idx < len(self.channel_names) and idx not in idxs:
                    idxs.append(idx)
            resolved[str(group_name)] = idxs
        return resolved

    def _normalize_label(self, label: TensorLikeLabel) -> Tuple[int, str]:
        if torch.is_tensor(label):
            label = int(label.detach().cpu().item())
        if isinstance(label, str):
            if label not in self.class_to_idx:
                return -1, label
            return int(self.class_to_idx[label]), label
        label_idx = int(label)
        return label_idx, self.idx_to_class.get(label_idx, str(label_idx))

    @staticmethod
    def _normalize_domain(domain: TensorLikeDomain) -> str:
        if torch.is_tensor(domain):
            domain = int(domain.detach().cpu().item())
        if isinstance(domain, str):
            domain_lower = domain.lower()
            if domain_lower in {"sim", "real"}:
                return domain_lower
            return domain_lower
        return "sim" if int(domain) == 0 else "real"

    @staticmethod
    def _normalize_stage(stage: TensorLikeStage) -> str:
        if isinstance(stage, int):
            return f"stage{stage}"
        stage_str = str(stage)
        if stage_str in {"1", "2", "3"}:
            return f"stage{stage_str}"
        return stage_str

    @staticmethod
    def _normalize_rpm(rpm: Optional[Union[float, torch.Tensor]]) -> Optional[float]:
        if rpm is None:
            return None
        if torch.is_tensor(rpm):
            rpm = float(rpm.detach().cpu().view(-1)[0].item())
        rpm = float(rpm)
        if not math.isfinite(rpm):
            return None
        return rpm

    def _get_stage_policy(self, stage_name: str, domain_name: str) -> Dict[str, Any]:
        return dict(self.cfg.get("stage_policy", {}).get(stage_name, {}).get(domain_name, {}))

    @staticmethod
    def _bernoulli(prob: float) -> bool:
        prob = max(0.0, min(float(prob), 1.0))
        if prob <= 0.0:
            return False
        if prob >= 1.0:
            return True
        return torch.rand(()).item() < prob

    def _append_op(self, meta: Dict[str, Any], name: str) -> None:
        meta["applied"].append(name)
        self._count(meta["stage"], meta["domain"], meta["class"], name)

    def _count(self, stage: str, domain: str, class_name: str, key: str) -> None:
        stage_dict = self.counters.setdefault(stage, {})
        domain_dict = stage_dict.setdefault(domain, {})
        class_dict = domain_dict.setdefault(class_name, {})
        class_dict[key] = int(class_dict.get(key, 0)) + 1

    def _apply_weak(self, x: torch.Tensor, meta: Dict[str, Any]) -> torch.Tensor:
        cfg = self.cfg.get("weak", {})
        x = random_shift(x, cfg.get("max_shift", 50))
        self._append_op(meta, "weak_random_shift")
        x = add_gaussian_noise(x, cfg.get("snr_range", [30.0, 40.0]))
        self._append_op(meta, "weak_gaussian_noise")
        x = random_scaling(x, cfg.get("scale_range", [0.95, 1.05]))
        self._append_op(meta, "weak_random_scaling")
        x = channel_gain(x, cfg.get("channel_gain_range", [0.95, 1.05]))
        self._append_op(meta, "weak_channel_gain")
        x = channel_bias(x, cfg.get("channel_bias_ratio", [0.01, 0.03]))
        self._append_op(meta, "weak_channel_bias")
        if self._bernoulli(cfg.get("time_mask_prob", 0.20)):
            x = time_mask(x, cfg.get("mask_len_range", [20, 80]))
            self._append_op(meta, "weak_time_mask")
        if self._bernoulli(cfg.get("filter_prob", 0.25)):
            x = random_filter(x, fs=float(self.cfg.get("fs", 10000)))
            self._append_op(meta, "weak_random_filter")
        if self._bernoulli(cfg.get("rpm_jitter_prob", 0.15)):
            x = rpm_jitter(x, cfg.get("rpm_jitter_range", [0.98, 1.02]))
            self._append_op(meta, "weak_rpm_jitter")
        return x

    def _apply_strong(self, x: torch.Tensor, meta: Dict[str, Any]) -> torch.Tensor:
        cfg = self.cfg.get("strong", {})
        x = random_shift(x, cfg.get("max_shift", 150))
        self._append_op(meta, "strong_random_shift")
        x = add_gaussian_noise(x, cfg.get("snr_range", [18.0, 30.0]))
        self._append_op(meta, "strong_gaussian_noise")
        x = random_scaling(x, cfg.get("scale_range", [0.85, 1.15]))
        self._append_op(meta, "strong_random_scaling")
        x = channel_gain(x, cfg.get("channel_gain_range", [0.85, 1.15]))
        self._append_op(meta, "strong_channel_gain")
        x = channel_bias(x, cfg.get("channel_bias_ratio", [0.03, 0.08]))
        self._append_op(meta, "strong_channel_bias")
        if self._bernoulli(cfg.get("time_mask_prob", 0.35)):
            x = time_mask(x, cfg.get("mask_len_range", [80, 250]))
            self._append_op(meta, "strong_time_mask")
        if self._bernoulli(cfg.get("filter_prob", 0.35)):
            x = random_filter(x, fs=float(self.cfg.get("fs", 10000)))
            self._append_op(meta, "strong_random_filter")
        if self._bernoulli(cfg.get("rpm_jitter_prob", 0.25)):
            x = rpm_jitter(x, cfg.get("rpm_jitter_range", [0.95, 1.05]))
            self._append_op(meta, "strong_rpm_jitter")
        return x

    def _apply_sim2real(self, x: torch.Tensor, meta: Dict[str, Any]) -> torch.Tensor:
        cfg = self.cfg.get("sim2real", {})
        if self._bernoulli(cfg.get("filter_prob", 0.5)):
            x = random_filter(x, fs=float(self.cfg.get("fs", 10000)))
            self._append_op(meta, "sim2real_random_filter")
        if self._bernoulli(cfg.get("quantization_prob", 0.35)):
            x = quantization_noise(x, num_levels=int(cfg.get("quantization_levels", 512)))
            self._append_op(meta, "sim2real_quantization")
        if self._bernoulli(cfg.get("low_freq_drift_prob", 0.35)):
            x = low_freq_drift(x, drift_ratio=cfg.get("drift_ratio", [0.01, 0.04]))
            self._append_op(meta, "sim2real_low_freq_drift")
        if self._bernoulli(cfg.get("channel_gain_prob", 0.35)):
            x = channel_gain(x, gain_range=cfg.get("channel_gain_range", [0.90, 1.10]))
            self._append_op(meta, "sim2real_channel_gain")
        if self._bernoulli(cfg.get("channel_bias_prob", 0.25)):
            x = channel_bias(x, bias_ratio=cfg.get("channel_bias_ratio", [0.01, 0.05]))
            self._append_op(meta, "sim2real_channel_bias")
        return x

    def _apply_class_specific(
        self,
        x: torch.Tensor,
        class_name: str,
        class_cfg: Dict[str, Any],
        rpm_value: Optional[float],
        meta: Dict[str, Any],
    ) -> torch.Tensor:
        fs = float(self.cfg.get("fs", 10000))
        pole_pairs = int(self.cfg.get("pole_pairs", 5))

        if class_name == "health":
            # health 只补充轻微滤波/整体幅值，不做强单通道异常或相间不平衡。
            if self._bernoulli(0.5):
                x = random_filter(x, fs=fs)
                self._append_op(meta, "class_health_light_filter")
            return x

        if class_name == "OPF":
            x = phase_imbalance_aug(
                x,
                current_pairs=self.current_pairs,
                phase_imbalance_range=class_cfg.get("phase_imbalance_range", [0.85, 1.15]),
                normal_phase_scale_range=class_cfg.get("normal_phase_scale_range", [0.90, 1.10]),
            )
            self._append_op(meta, "class_OPF_current_pair_imbalance")
            x = harmonic_amp_jitter(
                x,
                fs=fs,
                rpm=rpm_value,
                channels=self.freq_channels,
                pole_pairs=pole_pairs,
                harmonic_amp_range=class_cfg.get("harmonic_amp_range", [0.80, 1.20]),
            )
            self._append_op(meta, "class_OPF_harmonic_amp_jitter")
            if self._bernoulli(0.4):
                x = random_filter(x, fs=fs)
                self._append_op(meta, "class_OPF_random_filter")
            return x

        if class_name == "Sensor":
            sensor_channels = list(range(x.size(0)))
            x = sensor_bias_aug(x, channels=sensor_channels, bias_ratio=class_cfg.get("sensor_bias_ratio", [0.05, 0.30]))
            self._append_op(meta, "class_Sensor_single_channel_bias")
            x = sensor_gain_aug(x, channels=sensor_channels, gain_range=class_cfg.get("sensor_gain_range", [0.80, 1.20]))
            self._append_op(meta, "class_Sensor_single_channel_gain")
            x = sensor_drift_aug(x, channels=sensor_channels, drift_ratio=class_cfg.get("drift_ratio", [0.05, 0.20]))
            self._append_op(meta, "class_Sensor_single_channel_drift")
            if self._bernoulli(class_cfg.get("spike_prob", 0.15)):
                x = sensor_spike_aug(x, channels=sensor_channels, spike_ratio=class_cfg.get("spike_ratio", [3.0, 6.0]))
                self._append_op(meta, "class_Sensor_spike")
            if self._bernoulli(class_cfg.get("saturation_prob", 0.10)):
                x = light_saturation_aug(x, channels=sensor_channels)
                self._append_op(meta, "class_Sensor_light_saturation")
            if self._bernoulli(class_cfg.get("delay_prob", 0.20)):
                x = sensor_delay_aug(x, channels=sensor_channels, delay_points=class_cfg.get("delay_points", [5, 30]))
                self._append_op(meta, "class_Sensor_small_delay")
            return x

        if class_name == "ITSC":
            x = phase_imbalance_aug(
                x,
                current_pairs=self.current_pairs,
                phase_imbalance_range=class_cfg.get("phase_imbalance_range", [0.85, 1.15]),
            )
            self._append_op(meta, "class_ITSC_current_pair_imbalance")
            x = harmonic_amp_jitter(
                x,
                fs=fs,
                rpm=rpm_value,
                channels=self.freq_channels,
                pole_pairs=pole_pairs,
                harmonic_amp_range=class_cfg.get("harmonic_amp_range", [0.70, 1.30]),
            )
            self._append_op(meta, "class_ITSC_harmonic_amp_jitter")
            x = harmonic_center_jitter(
                x,
                fs=fs,
                rpm=rpm_value,
                channels=self.freq_channels,
                pole_pairs=pole_pairs,
                center_jitter=class_cfg.get("harmonic_center_jitter", [0.03, 0.05]),
            )
            self._append_op(meta, "class_ITSC_harmonic_center_jitter")
            if self._bernoulli(0.5):
                x = add_gaussian_noise(x, snr_range=class_cfg.get("snr_range", [20.0, 35.0]))
                self._append_op(meta, "class_ITSC_medium_noise")
            if self._bernoulli(0.4):
                x = random_filter(x, fs=fs)
                self._append_op(meta, "class_ITSC_random_filter")
            return x

        if class_name == "tuici":
            x = global_amplitude_aug(
                x,
                global_scale_range=class_cfg.get("global_scale_range", [0.85, 1.15]),
                current_pairs=self.current_pairs,
                current_pair_scale_range=class_cfg.get("current_pair_scale_range", [0.90, 1.10]),
            )
            self._append_op(meta, "class_tuici_global_current_pair_amplitude")
            x = low_freq_drift(x, drift_ratio=class_cfg.get("low_freq_drift_ratio", [0.01, 0.05]))
            self._append_op(meta, "class_tuici_low_freq_drift")
            x = harmonic_amp_jitter(
                x,
                fs=fs,
                rpm=rpm_value,
                channels=self.freq_channels,
                pole_pairs=pole_pairs,
                harmonic_amp_range=class_cfg.get("harmonic_amp_range", [0.75, 1.25]),
            )
            self._append_op(meta, "class_tuici_harmonic_amp_jitter")
            if self._bernoulli(0.35):
                x = random_filter(x, fs=fs)
                self._append_op(meta, "class_tuici_random_filter")
            return x

        return x
