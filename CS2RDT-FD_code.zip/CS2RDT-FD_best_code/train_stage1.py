# train_stage1.py
# -*- coding: utf-8 -*-

"""
Stage 1 训练脚本：
- 只使用仿真五类数据
- 学习完整 5 类故障知识
- 保存 best teacher checkpoint
"""

import os
import argparse
from collections import defaultdict, Counter

import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt

from utils import (
    load_config,
    ensure_dir,
    setup_logger,
    set_random_seed,
    get_device,
    build_model,
    build_optimizer,
    build_dataloader,
    get_or_create_split_records,
    build_stage_datasets_from_splits,
    save_scaler,
    get_dataset_augmentation_counters,
    count_trainable_parameters,
    save_json,
)
from trainer import Stage1Trainer


def parse_args():
    parser = argparse.ArgumentParser(description="Stage1: 仿真预训练")
    parser.add_argument("--config", type=str, default="config_stage1.yaml", help="配置文件路径")
    parser.add_argument("--resume", type=str, default=None, help="恢复训练的 checkpoint 路径")
    return parser.parse_args()

def get_class_names(config):
    """优先从配置读取类别名；若没有，则使用当前5类顺序"""
    class_names = config.get("data", {}).get("class_names", None)  # 可选配置
    if class_names is None:
        class_names = ["health", "OPF", "ITSC", "Sensor", "tuici"]  # 当前5类任务
    return list(class_names)


def compute_confusion_matrix(y_true, y_pred, num_classes):
    """不依赖 sklearn 的混淆矩阵实现"""
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)  # 行是真实类，列是预测类
    for t, p in zip(y_true, y_pred):
        t = int(t)
        p = int(p)
        if 0 <= t < num_classes and 0 <= p < num_classes:
            cm[t, p] += 1
    return cm


def build_classification_report(cm, class_names):
    """根据混淆矩阵计算每类 precision / recall / f1"""
    rows = []
    total_correct = int(np.trace(cm))
    total = int(cm.sum())

    for i, name in enumerate(class_names):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        support = cm[i, :].sum()

        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-12)

        rows.append({
            "class": name,
            "precision": float(precision),
            "recall": float(recall),
            "f1": float(f1),
            "support": int(support),
        })

    accuracy = total_correct / max(total, 1)
    rows.append({
        "class": "accuracy",
        "precision": float("nan"),
        "recall": float("nan"),
        "f1": float(accuracy),
        "support": int(total),
    })

    return pd.DataFrame(rows)


def save_confusion_outputs(y_true, y_pred, class_names, save_dir, prefix, logger=None):
    """保存混淆矩阵csv、归一化csv、分类报告csv和图片"""
    os.makedirs(save_dir, exist_ok=True)

    num_classes = len(class_names)
    cm = compute_confusion_matrix(y_true, y_pred, num_classes)

    cm_df = pd.DataFrame(cm, index=class_names, columns=class_names)
    counts_path = os.path.join(save_dir, f"{prefix}_confusion_counts.csv")
    cm_df.to_csv(counts_path, encoding="utf-8-sig")

    row_sum = cm.sum(axis=1, keepdims=True)
    cm_norm = cm / np.maximum(row_sum, 1)
    cm_norm_df = pd.DataFrame(cm_norm, index=class_names, columns=class_names)
    norm_path = os.path.join(save_dir, f"{prefix}_confusion_norm.csv")
    cm_norm_df.to_csv(norm_path, encoding="utf-8-sig")

    report_df = build_classification_report(cm, class_names)
    report_path = os.path.join(save_dir, f"{prefix}_classification_report.csv")
    report_df.to_csv(report_path, index=False, encoding="utf-8-sig")

    fig_path = os.path.join(save_dir, f"{prefix}_confusion_matrix.png")
    plt.figure(figsize=(7, 6))
    plt.imshow(cm_norm, interpolation="nearest")
    plt.title(prefix)
    plt.colorbar()

    ticks = np.arange(num_classes)
    plt.xticks(ticks, class_names, rotation=45, ha="right")
    plt.yticks(ticks, class_names)

    for i in range(num_classes):
        for j in range(num_classes):
            text = f"{cm[i, j]}\n{cm_norm[i, j]:.2f}"
            plt.text(j, i, text, ha="center", va="center", fontsize=8)

    plt.xlabel("Predicted label")
    plt.ylabel("True label")
    plt.tight_layout()
    plt.savefig(fig_path, dpi=300)
    plt.close()

    if logger is not None:
        logger.info(f"{prefix} 混淆矩阵计数已保存: {counts_path}")
        logger.info(f"{prefix} 混淆矩阵归一化已保存: {norm_path}")
        logger.info(f"{prefix} 分类报告已保存: {report_path}")
        logger.info(f"{prefix} 混淆矩阵图片已保存: {fig_path}")

    return {
        "counts_csv": counts_path,
        "norm_csv": norm_path,
        "report_csv": report_path,
        "figure": fig_path,
    }


def extract_filenames_from_batch(batch, batch_size):
    """兼容不同 DataLoader collate 后的 meta 结构"""
    meta = batch.get("meta", None)

    if meta is None:
        return [f"sample_{i}" for i in range(batch_size)]

    if isinstance(meta, dict):
        filenames = meta.get("filename", None)
        if filenames is None:
            return [f"sample_{i}" for i in range(batch_size)]
        if isinstance(filenames, (list, tuple)):
            return list(filenames)
        return [str(filenames)] * batch_size

    if isinstance(meta, (list, tuple)):
        filenames = []
        for item in meta:
            if isinstance(item, dict):
                filenames.append(str(item.get("filename", "unknown")))
            else:
                filenames.append("unknown")
        return filenames

    return [f"sample_{i}" for i in range(batch_size)]


@torch.no_grad()
def collect_val_predictions(model, val_loader, device):
    """收集验证集窗口级预测，同时保留文件名以便做文件级投票"""
    model.eval()

    y_true_window = []
    y_pred_window = []
    filenames_window = []

    for batch in val_loader:
        x = batch["x"].to(device)
        y = batch["y"].to(device)

        speed = batch.get("speed", None)
        if speed is not None:
            speed = speed.to(device)

        outputs = model(
            x,
            speed_rpm=speed,
            class_condition=y,
            grl_lambda_domain=0.0,
            grl_lambda_domain_global=0.0,
        )

        logits = outputs["logits"]
        pred = torch.argmax(logits, dim=1)

        y_cpu = y.detach().cpu().numpy().tolist()
        pred_cpu = pred.detach().cpu().numpy().tolist()

        y_true_window.extend(y_cpu)
        y_pred_window.extend(pred_cpu)

        filenames = extract_filenames_from_batch(batch, batch_size=len(y_cpu))
        filenames_window.extend(filenames)

    return y_true_window, y_pred_window, filenames_window


def window_to_file_level(y_true_window, y_pred_window, filenames_window):
    """把窗口级预测聚合成文件级多数投票预测"""
    file_pred_votes = defaultdict(list)
    file_true_votes = defaultdict(list)

    for fname, y_true, y_pred in zip(filenames_window, y_true_window, y_pred_window):
        file_pred_votes[fname].append(int(y_pred))
        file_true_votes[fname].append(int(y_true))

    y_true_file = []
    y_pred_file = []

    for fname in sorted(file_pred_votes.keys()):
        true_label = Counter(file_true_votes[fname]).most_common(1)[0][0]
        pred_label = Counter(file_pred_votes[fname]).most_common(1)[0][0]

        y_true_file.append(true_label)
        y_pred_file.append(pred_label)

    return y_true_file, y_pred_file


def evaluate_best_checkpoint_confusion(trainer, model, val_loader, device, config, result, logger):
    """加载best checkpoint并保存窗口级/文件级验证集混淆矩阵"""
    output_dir = config["paths"]["output_dir"]
    class_names = get_class_names(config)

    best_ckpt_path = result["best_ckpt_path"]
    trainer.load_checkpoint(best_ckpt_path, load_optimizer=False, strict=True)
    logger.info(f"已加载 best checkpoint 用于混淆矩阵评估: {best_ckpt_path}")

    y_true_w, y_pred_w, filenames_w = collect_val_predictions(
        model=model,
        val_loader=val_loader,
        device=device,
    )

    window_acc = np.mean(np.array(y_true_w) == np.array(y_pred_w))
    logger.info(f"[stage1 best] window-level val_acc={window_acc:.4f}")

    window_paths = save_confusion_outputs(
        y_true=y_true_w,
        y_pred=y_pred_w,
        class_names=class_names,
        save_dir=output_dir,
        prefix="stage1_best_val_window",
        logger=logger,
    )

    y_true_f, y_pred_f = window_to_file_level(
        y_true_window=y_true_w,
        y_pred_window=y_pred_w,
        filenames_window=filenames_w,
    )

    file_acc = np.mean(np.array(y_true_f) == np.array(y_pred_f))
    logger.info(f"[stage1 best] file-level val_acc={file_acc:.4f}")

    file_paths = save_confusion_outputs(
        y_true=y_true_f,
        y_pred=y_pred_f,
        class_names=class_names,
        save_dir=output_dir,
        prefix="stage1_best_val_file",
        logger=logger,
    )

    return {
        "window_level_acc": float(window_acc),
        "file_level_acc": float(file_acc),
        "window_level_outputs": window_paths,
        "file_level_outputs": file_paths,
    }

def main():
    args = parse_args()
    config = load_config(args.config)

    # 准备目录
    paths_cfg = config["paths"]
    ensure_dir(paths_cfg["checkpoint_dir"])
    ensure_dir(paths_cfg["log_dir"])
    ensure_dir(paths_cfg["output_dir"])

    logger = setup_logger(
        name="train_stage1",
        log_dir=paths_cfg["log_dir"],
        log_filename="train_stage1.log",
        level=config["logging"]["level"]
    )

    set_random_seed(int(config["random_seed"]))
    device = get_device(config)

    logger.info("========== Stage1: 仿真预训练 ==========")
    logger.info(f"使用设备: {device}")

    # 数据准备：直接扫描当前数据，避免旧缓存掩盖数据布局或真实 tuici holdout 变化
    data_cfg = config["data"]
    split_pack = get_or_create_split_records(config=config, logger=logger)
    split_records = split_pack["split_records"]

    dataset_pack = build_stage_datasets_from_splits(
        config=config,
        split_records=split_records,
        stage_name="stage1",
        logger=logger,
        scaler=None,
        fit_scaler=True,
    )

    scaler = dataset_pack["scaler"]
    train_dataset = dataset_pack["train_dataset"]
    val_dataset = dataset_pack["val_dataset"]

    # 保存 scaler，供后续复现实验或测试使用
    scaler_path = os.path.join(paths_cfg["checkpoint_dir"], "scaler_stage1.json")
    save_scaler(scaler, scaler_path)
    logger.info(f"Stage1 scaler 已保存: {scaler_path}")


    train_loader = build_dataloader(
        dataset=train_dataset,
        batch_size=int(data_cfg["batch_size"]),
        num_workers=int(data_cfg["num_workers"]),
        pin_memory=bool(data_cfg["pin_memory"]),
        shuffle=True,
        drop_last=bool(data_cfg["drop_last"]),
    )
    val_loader = build_dataloader(
        dataset=val_dataset,
        batch_size=int(data_cfg["batch_size"]),
        num_workers=int(data_cfg["num_workers"]),
        pin_memory=bool(data_cfg["pin_memory"]),
        shuffle=False,
        drop_last=False,
    )

    # 模型与优化器
    model = build_model(config).to(device)
    logger.info(f"模型可训练参数量: {count_trainable_parameters(model):,}")

    train_cfg = config["train"]["stage1"]
    optimizer = build_optimizer(
        model=model,
        lr=float(train_cfg["lr"]),
        weight_decay=float(config["train"]["weight_decay"]),
    )

    trainer = Stage1Trainer(
        model=model,
        optimizer=optimizer,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        config=config,
        logger=logger,
        checkpoint_dir=paths_cfg["checkpoint_dir"],
        teacher_model=None,
    )

    # 恢复训练
    resume_path = args.resume if args.resume is not None else train_cfg.get("resume", None)
    if resume_path:
        trainer.load_checkpoint(resume_path, load_optimizer=True, strict=True)

    result = trainer.fit(
        num_epochs=int(train_cfg["epochs"]),
        save_name=str(train_cfg["save_name"]),
    )

    aug_counters = get_dataset_augmentation_counters(train_dataset)
    result["augmentation_counters"] = aug_counters
    save_json(
        aug_counters,
        os.path.join(paths_cfg["output_dir"], "stage1_augmentation_counters.json")
    )
    logger.info(f"Stage1 数据增强统计: {aug_counters}")

    confusion_result = evaluate_best_checkpoint_confusion(
        trainer=trainer,
        model=model,
        val_loader=val_loader,
        device=device,
        config=config,
        result=result,
        logger=logger,
    )

    result["confusion_result"] = confusion_result

    save_json(
        result,
        os.path.join(paths_cfg["output_dir"], "stage1_train_result.json")
    )

    logger.info("========== Stage1 训练完成 ==========")
    logger.info(f"best_val_acc={result['best_val_acc']:.4f}")
    logger.info(f"best_ckpt_path={result['best_ckpt_path']}")


if __name__ == "__main__":
    main()
